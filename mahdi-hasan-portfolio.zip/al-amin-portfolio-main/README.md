# Mahdi Hasan | Portfolio

Single-page portfolio for Mahdi Hasan, Media Buyer & Paid Advertising Consultant.
Built with Next.js, Tailwind CSS v4 and Framer Motion,.

## Run

```bash
npm install
npm run dev      # http://localhost:3000
npm run build
```

The public site renders from static content in `src/data/` and needs no database.
To enable the admin panel, contact form storage/email and visitor analytics, copy `.env.example`
to `.env.local` and fill in MongoDB, SMTP, Cloudinary and Upstash values.

## Brand (Brand Design Kit, Edition 01)

| Token | Hex | Use |
|---|---|---|
| Primary Blue | `#002E9F` | dominant colour, buttons, wordmark |
| Bright Blue | `#0080FF` | accents, dark-mode primary |
| Accent Cyan | `#00AADA` | rules, small highlights |
| Deep Navy | `#001A5E` | dark sections, footer |
| Ink | `#0A0E1A` | text, dark-mode background |
| Panel White / White | `#F3F5FB` / `#FFFFFF` | neutrals |

Tokens live in `src/app/globals.css`. Fonts: Lora (display/wordmark), Space Grotesk (headings, labels), Poppins (body).

## Where to edit content

| What | File |
|---|---|
| Name, email, LinkedIn, nav | `src/config/site.ts`, `src/data/social.ts` |
| Hero | `src/data/hero.ts` |
| About + portrait | `src/data/about.ts`, `src/constants/images.ts` (add image to `public/images`) |
| Services | `src/data/skills.ts` |
| Selected work (placeholders now) | `src/data/portfolio.ts` |
| Process, FAQ, contact | `src/data/process.ts`, `src/data/faq.ts`, `src/data/contact.ts` |
| Testimonials (section hidden while empty) | `src/data/testimonials.ts` |
| Section headings | `src/services/*-section.service.ts` |

## Placeholders to replace

- Portrait photo (About section)
- Selected Work cards (no real results were provided, so none are invented)
- Testimonials (hidden until real ones are added)
- Confirm `hello@mahdihasan.co` and the `https://mahdihasan.co` domain
- Add further social links only once verified
