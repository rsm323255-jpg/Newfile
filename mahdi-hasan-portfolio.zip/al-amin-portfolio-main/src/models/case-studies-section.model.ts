import mongoose, { Schema, Document, Model } from "mongoose";

export interface ICaseStudiesSection extends Document {
  eyebrow: string;
  title: string;
  subtitle: string;
  isPublished: boolean;
  createdAt: Date;
  updatedAt: Date;
}

const CaseStudiesSectionSchema = new Schema<ICaseStudiesSection>(
  {
    eyebrow: { type: String, required: true },
    title: { type: String, required: true },
    subtitle: { type: String, required: true },
    isPublished: { type: Boolean, default: true },
  },
  { timestamps: true }
);

export const CaseStudiesSectionModel: Model<ICaseStudiesSection> =
  mongoose.models.CaseStudiesSection ||
  mongoose.model<ICaseStudiesSection>("CaseStudiesSection", CaseStudiesSectionSchema);
