import mongoose, { Schema, Document, Model } from "mongoose";

export interface IStatistic extends Document {
  value: string;
  label: string;
  suffix?: string;
  isPublished: boolean;
  order: number;
  createdAt: Date;
  updatedAt: Date;
}

const StatisticSchema = new Schema<IStatistic>(
  {
    value: { type: String, required: true, trim: true },
    label: { type: String, required: true, trim: true },
    suffix: { type: String, default: "" },
    isPublished: { type: Boolean, default: true },
    order: { type: Number, default: 0 },
  },
  { timestamps: true }
);

export const StatisticModel: Model<IStatistic> =
  mongoose.models.Statistic || mongoose.model<IStatistic>("Statistic", StatisticSchema);
