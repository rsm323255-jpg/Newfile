import mongoose, { Schema, Document, Model } from "mongoose";

export interface ICaseStudyResult {
  before: string;
  after: string;
  metric: string;
}

export interface ICaseStudy extends Document {
  title: string;
  slug: string;
  client: string;
  challenge: string;
  solution: string;
  results: ICaseStudyResult[];
  image: string;
  tags: string[];
  isPublished: boolean;
  order: number;
  createdAt: Date;
  updatedAt: Date;
}

const CaseStudyResultSchema = new Schema<ICaseStudyResult>(
  { before: { type: String, required: true }, after: { type: String, required: true }, metric: { type: String, required: true } },
  { _id: false }
);

const CaseStudySchema = new Schema<ICaseStudy>(
  {
    title: { type: String, required: true, trim: true },
    slug: { type: String, required: true, unique: true, lowercase: true, trim: true },
    client: { type: String, required: true, trim: true },
    challenge: { type: String, required: true },
    solution: { type: String, required: true },
    results: { type: [CaseStudyResultSchema], default: [] },
    image: { type: String, default: "" },
    tags: { type: [String], default: [] },
    isPublished: { type: Boolean, default: true },
    order: { type: Number, default: 0 },
  },
  { timestamps: true }
);

export const CaseStudyModel: Model<ICaseStudy> =
  mongoose.models.CaseStudy || mongoose.model<ICaseStudy>("CaseStudy", CaseStudySchema);
