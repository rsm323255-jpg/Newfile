import mongoose, { Schema, Document, Model } from "mongoose";

export interface ITerms extends Document {
  title: string;
  content: string;
  lastUpdated: string;
  isPublished: boolean;
  createdAt: Date;
  updatedAt: Date;
}

const TermsSchema = new Schema<ITerms>(
  {
    title: { type: String, required: true },
    content: { type: String, required: true },
    lastUpdated: { type: String, default: "" },
    isPublished: { type: Boolean, default: true },
  },
  { timestamps: true }
);

export const TermsModel: Model<ITerms> =
  mongoose.models.Terms ||
  mongoose.model<ITerms>("Terms", TermsSchema);
