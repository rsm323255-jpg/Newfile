import mongoose, { Schema, Document, Model } from "mongoose";

export interface INewsletter extends Document {
  title: string;
  description: string;
  button: string;
  isPublished: boolean;
  createdAt: Date;
  updatedAt: Date;
}

const NewsletterSchema = new Schema<INewsletter>(
  {
    title: { type: String, required: true },
    description: { type: String, required: true },
    button: { type: String, default: "Subscribe" },
    isPublished: { type: Boolean, default: true },
  },
  { timestamps: true }
);

export const NewsletterModel: Model<INewsletter> =
  mongoose.models.Newsletter ||
  mongoose.model<INewsletter>("Newsletter", NewsletterSchema);
