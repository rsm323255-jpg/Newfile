import mongoose, { Schema, Document, Model } from "mongoose";

export interface ITeamSection extends Document {
  eyebrow: string;
  title: string;
  subtitle: string;
  isPublished: boolean;
  createdAt: Date;
  updatedAt: Date;
}

const TeamSectionSchema = new Schema<ITeamSection>(
  {
    eyebrow: { type: String, required: true },
    title: { type: String, required: true },
    subtitle: { type: String, required: true },
    isPublished: { type: Boolean, default: true },
  },
  { timestamps: true }
);

export const TeamSectionModel: Model<ITeamSection> =
  mongoose.models.TeamSection ||
  mongoose.model<ITeamSection>("TeamSection", TeamSectionSchema);
