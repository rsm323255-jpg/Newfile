import mongoose, { Schema, Document, Model } from "mongoose";

export interface IPrivacyPolicy extends Document {
  title: string;
  content: string;
  lastUpdated: string;
  isPublished: boolean;
  createdAt: Date;
  updatedAt: Date;
}

const PrivacyPolicySchema = new Schema<IPrivacyPolicy>(
  {
    title: { type: String, required: true },
    content: { type: String, required: true },
    lastUpdated: { type: String, default: "" },
    isPublished: { type: Boolean, default: true },
  },
  { timestamps: true }
);

export const PrivacyPolicyModel: Model<IPrivacyPolicy> =
  mongoose.models.PrivacyPolicy ||
  mongoose.model<IPrivacyPolicy>("PrivacyPolicy", PrivacyPolicySchema);
