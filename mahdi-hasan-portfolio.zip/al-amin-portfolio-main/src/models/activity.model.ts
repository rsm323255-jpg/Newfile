import mongoose, { Schema, Document, Model } from "mongoose";

export interface IActivity extends Document {
  action: string;
  entity: string;
  entityId?: string;
  entityTitle?: string;
  userId: string;
  userName: string;
  details?: string;
  createdAt: Date;
}

const ActivitySchema = new Schema<IActivity>(
  {
    action: { type: String, required: true, index: true },
    entity: { type: String, required: true, index: true },
    entityId: { type: String },
    entityTitle: { type: String },
    userId: { type: String, required: true },
    userName: { type: String, required: true },
    details: { type: String },
  },
  { timestamps: true }
);

ActivitySchema.index({ createdAt: -1 });

export const ActivityModel: Model<IActivity> =
  mongoose.models.Activity || mongoose.model<IActivity>("Activity", ActivitySchema);
