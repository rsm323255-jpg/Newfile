import mongoose, { Schema, Document, Model } from "mongoose";

export interface IFAQSection extends Document {
  eyebrow: string;
  title: string;
  subtitle: string;
  isPublished: boolean;
  createdAt: Date;
  updatedAt: Date;
}

const FAQSectionSchema = new Schema<IFAQSection>(
  {
    eyebrow: { type: String, required: true },
    title: { type: String, required: true },
    subtitle: { type: String, required: true },
    isPublished: { type: Boolean, default: true },
  },
  { timestamps: true }
);

export const FAQSectionModel: Model<IFAQSection> =
  mongoose.models.FAQSection ||
  mongoose.model<IFAQSection>("FAQSection", FAQSectionSchema);
