import mongoose, { Schema, Document, Model } from "mongoose";

export interface IContact extends Document {
  eyebrow: string;
  title: string;
  subtitle: string;
  email: string;
  phone: string;
  address: string;
  workingHours: string;
  isPublished: boolean;
  createdAt: Date;
  updatedAt: Date;
}

const ContactSchema = new Schema<IContact>(
  {
    eyebrow: { type: String, required: true, default: "Contact" },
    title: { type: String, required: true, default: "Let's Build Your Growth Story" },
    subtitle: { type: String, required: true, default: "Tell me where you are and where you want to be. I'll map the fastest route between the two." },
    email: { type: String, required: true },
    phone: { type: String, required: true },
    address: { type: String, required: true },
    workingHours: { type: String, default: "" },
    isPublished: { type: Boolean, default: true },
  },
  { timestamps: true }
);

export const ContactModel: Model<IContact> =
  mongoose.models.Contact || mongoose.model<IContact>("Contact", ContactSchema);
