import mongoose, { Schema, Document, Model } from "mongoose";

export interface IHeroStat {
  id: string;
  value: string;
  label: string;
  suffix?: string;
}

export interface IHero extends Document {
  title: string;
  subtitle: string;
  description: string;
  ctaPrimary: string;
  ctaSecondary: string;
  image: string;
  stats: IHeroStat[];
  isPublished: boolean;
  createdAt: Date;
  updatedAt: Date;
}

const HeroStatSchema = new Schema<IHeroStat>(
  {
    id: { type: String, required: true },
    value: { type: String, required: true },
    label: { type: String, required: true },
    suffix: { type: String, default: "" },
  },
  { _id: false }
);

const HeroSchema = new Schema<IHero>(
  {
    title: { type: String, required: true, trim: true },
    subtitle: { type: String, required: true, trim: true },
    description: { type: String, required: true },
    ctaPrimary: { type: String, default: "" },
    ctaSecondary: { type: String, default: "" },
    image: { type: String, default: "" },
    stats: { type: [HeroStatSchema], default: [] },
    isPublished: { type: Boolean, default: true },
  },
  { timestamps: true }
);

export const HeroModel: Model<IHero> =
  mongoose.models.Hero || mongoose.model<IHero>("Hero", HeroSchema);
