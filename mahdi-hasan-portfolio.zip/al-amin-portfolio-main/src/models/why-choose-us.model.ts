import mongoose, { Schema, Document, Model } from "mongoose";

export interface IWhyChooseUs extends Document {
  title: string;
  description: string;
  icon: string;
  isPublished: boolean;
  order: number;
  createdAt: Date;
  updatedAt: Date;
}

const WhyChooseUsSchema = new Schema<IWhyChooseUs>(
  {
    title: { type: String, required: true, trim: true },
    description: { type: String, required: true },
    icon: { type: String, default: "BarChart3" },
    isPublished: { type: Boolean, default: true },
    order: { type: Number, default: 0 },
  },
  { timestamps: true }
);

export const WhyChooseUsModel: Model<IWhyChooseUs> =
  mongoose.models.WhyChooseUs || mongoose.model<IWhyChooseUs>("WhyChooseUs", WhyChooseUsSchema);
