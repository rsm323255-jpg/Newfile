import mongoose, { Schema, Document, Model } from "mongoose";

export interface IProcessSection extends Document {
  eyebrow: string;
  title: string;
  subtitle: string;
  isPublished: boolean;
  createdAt: Date;
  updatedAt: Date;
}

const ProcessSectionSchema = new Schema<IProcessSection>(
  {
    eyebrow: { type: String, required: true },
    title: { type: String, required: true },
    subtitle: { type: String, required: true },
    isPublished: { type: Boolean, default: true },
  },
  { timestamps: true }
);

export const ProcessSectionModel: Model<IProcessSection> =
  mongoose.models.ProcessSection ||
  mongoose.model<IProcessSection>("ProcessSection", ProcessSectionSchema);
