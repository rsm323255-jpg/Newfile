import mongoose, { Schema, Document, Model } from "mongoose";

export interface IClientsSection extends Document {
  eyebrow: string;
  title: string;
  subtitle: string;
  isPublished: boolean;
  createdAt: Date;
  updatedAt: Date;
}

const ClientsSectionSchema = new Schema<IClientsSection>(
  {
    eyebrow: { type: String, required: true },
    title: { type: String, required: true },
    subtitle: { type: String, required: true },
    isPublished: { type: Boolean, default: true },
  },
  { timestamps: true }
);

export const ClientsSectionModel: Model<IClientsSection> =
  mongoose.models.ClientsSection ||
  mongoose.model<IClientsSection>("ClientsSection", ClientsSectionSchema);
