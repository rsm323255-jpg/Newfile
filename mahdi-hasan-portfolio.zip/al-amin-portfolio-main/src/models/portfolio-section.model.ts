import mongoose, { Schema, Document, Model } from "mongoose";

export interface IPortfolioSection extends Document {
  eyebrow: string;
  title: string;
  subtitle: string;
  isPublished: boolean;
  createdAt: Date;
  updatedAt: Date;
}

const PortfolioSectionSchema = new Schema<IPortfolioSection>(
  {
    eyebrow: { type: String, required: true },
    title: { type: String, required: true },
    subtitle: { type: String, required: true },
    isPublished: { type: Boolean, default: true },
  },
  { timestamps: true }
);

export const PortfolioSectionModel: Model<IPortfolioSection> =
  mongoose.models.PortfolioSection ||
  mongoose.model<IPortfolioSection>("PortfolioSection", PortfolioSectionSchema);
