import mongoose, { Schema, Document, Model } from "mongoose";

export interface ISkillsSection extends Document {
  eyebrow: string;
  title: string;
  subtitle: string;
  isPublished: boolean;
  createdAt: Date;
  updatedAt: Date;
}

const SkillsSectionSchema = new Schema<ISkillsSection>(
  {
    eyebrow: { type: String, required: true },
    title: { type: String, required: true },
    subtitle: { type: String, required: true },
    isPublished: { type: Boolean, default: true },
  },
  { timestamps: true }
);

export const SkillsSectionModel: Model<ISkillsSection> =
  mongoose.models.SkillsSection ||
  mongoose.model<ISkillsSection>("SkillsSection", SkillsSectionSchema);
