import mongoose, { Schema, Document, Model } from "mongoose";

export interface IAboutStat {
  id: string;
  value: string;
  label: string;
  suffix?: string;
}

export interface IAbout extends Document {
  title: string;
  description: string;
  mission: string;
  missionContent: string;
  vision: string;
  visionContent: string;
  experience: string;
  image: string;
  achievements: IAboutStat[];
  isPublished: boolean;
  createdAt: Date;
  updatedAt: Date;
}

const AboutStatSchema = new Schema<IAboutStat>(
  {
    id: { type: String, required: true },
    value: { type: String, required: true },
    label: { type: String, required: true },
    suffix: { type: String, default: "" },
  },
  { _id: false }
);

const AboutSchema = new Schema<IAbout>(
  {
    title: { type: String, required: true, trim: true },
    description: { type: String, required: true },
    mission: { type: String, required: true },
    missionContent: { type: String, default: "" },
    vision: { type: String, required: true },
    visionContent: { type: String, default: "" },
    experience: { type: String, default: "" },
    image: { type: String, default: "" },
    achievements: { type: [AboutStatSchema], default: [] },
    isPublished: { type: Boolean, default: true },
  },
  { timestamps: true }
);

export const AboutModel: Model<IAbout> =
  mongoose.models.About || mongoose.model<IAbout>("About", AboutSchema);
