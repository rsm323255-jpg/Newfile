import mongoose, { Schema, Document, Model } from "mongoose";

export interface ISocialLinks extends Document {
  linkedin: string;
  instagram: string;
  facebook: string;
  tiktok: string;
  twitter: string;
  youtube: string;
  isPublished: boolean;
  createdAt: Date;
  updatedAt: Date;
}

const SocialLinksSchema = new Schema<ISocialLinks>(
  {
    linkedin: { type: String, default: "" },
    instagram: { type: String, default: "" },
    facebook: { type: String, default: "" },
    tiktok: { type: String, default: "" },
    twitter: { type: String, default: "" },
    youtube: { type: String, default: "" },
    isPublished: { type: Boolean, default: true },
  },
  { timestamps: true }
);

export const SocialLinksModel: Model<ISocialLinks> =
  mongoose.models.SocialLinks ||
  mongoose.model<ISocialLinks>("SocialLinks", SocialLinksSchema);
