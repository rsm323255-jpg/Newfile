import mongoose, { Schema, Document, Model } from "mongoose";

export interface IVisitor extends Document {
  ip: string;
  userAgent: string;
  referrer: string;
  path: string;
  country?: string;
  createdAt: Date;
}

const VisitorSchema = new Schema<IVisitor>(
  {
    ip: { type: String, required: true, index: true },
    userAgent: { type: String, default: "" },
    referrer: { type: String, default: "" },
    path: { type: String, required: true, index: true },
    country: { type: String, default: "" },
  },
  { timestamps: true }
);

VisitorSchema.index({ createdAt: -1 });

export const VisitorModel: Model<IVisitor> =
  mongoose.models.Visitor || mongoose.model<IVisitor>("Visitor", VisitorSchema);
