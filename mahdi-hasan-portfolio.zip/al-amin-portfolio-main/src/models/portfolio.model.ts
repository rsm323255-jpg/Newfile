import mongoose, { Schema, Document, Model } from "mongoose";

export interface IPortfolioResult {
  metric: string;
  value: string;
}

export interface IPortfolio extends Document {
  title: string;
  slug: string;
  category: string;
  image: string;
  description: string;
  tags: string[];
  results: IPortfolioResult[];
  isPublished: boolean;
  order: number;
  createdAt: Date;
  updatedAt: Date;
}

const PortfolioResultSchema = new Schema<IPortfolioResult>(
  { metric: { type: String, required: true }, value: { type: String, required: true } },
  { _id: false }
);

const PortfolioSchema = new Schema<IPortfolio>(
  {
    title: { type: String, required: true, trim: true },
    slug: { type: String, required: true, unique: true, lowercase: true, trim: true },
    category: { type: String, required: true, trim: true },
    image: { type: String, default: "" },
    description: { type: String, required: true },
    tags: { type: [String], default: [] },
    results: { type: [PortfolioResultSchema], default: [] },
    isPublished: { type: Boolean, default: true },
    order: { type: Number, default: 0 },
  },
  { timestamps: true }
);

export const PortfolioModel: Model<IPortfolio> =
  mongoose.models.Portfolio || mongoose.model<IPortfolio>("Portfolio", PortfolioSchema);
