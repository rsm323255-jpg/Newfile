import mongoose, { Schema, Document, Model } from "mongoose";

export interface IStatisticsSection extends Document {
  eyebrow: string;
  title: string;
  subtitle: string;
  isPublished: boolean;
  createdAt: Date;
  updatedAt: Date;
}

const StatisticsSectionSchema = new Schema<IStatisticsSection>(
  {
    eyebrow: { type: String, required: true },
    title: { type: String, required: true },
    subtitle: { type: String, required: true },
    isPublished: { type: Boolean, default: true },
  },
  { timestamps: true }
);

export const StatisticsSectionModel: Model<IStatisticsSection> =
  mongoose.models.StatisticsSection ||
  mongoose.model<IStatisticsSection>("StatisticsSection", StatisticsSectionSchema);
