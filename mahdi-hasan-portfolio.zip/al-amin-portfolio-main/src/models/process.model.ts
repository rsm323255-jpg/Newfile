import mongoose, { Schema, Document, Model } from "mongoose";

export interface IProcessStep extends Document {
  title: string;
  description: string;
  icon: string;
  isPublished: boolean;
  order: number;
  createdAt: Date;
  updatedAt: Date;
}

const ProcessStepSchema = new Schema<IProcessStep>(
  {
    title: { type: String, required: true, trim: true },
    description: { type: String, required: true },
    icon: { type: String, default: "" },
    isPublished: { type: Boolean, default: true },
    order: { type: Number, default: 0 },
  },
  { timestamps: true }
);

export const ProcessStepModel: Model<IProcessStep> =
  mongoose.models.ProcessStep || mongoose.model<IProcessStep>("ProcessStep", ProcessStepSchema);
