import mongoose, { Schema, Document, Model } from "mongoose";

export interface ITestimonialsSection extends Document {
  eyebrow: string;
  title: string;
  subtitle: string;
  isPublished: boolean;
  createdAt: Date;
  updatedAt: Date;
}

const TestimonialsSectionSchema = new Schema<ITestimonialsSection>(
  {
    eyebrow: { type: String, required: true },
    title: { type: String, required: true },
    subtitle: { type: String, required: true },
    isPublished: { type: Boolean, default: true },
  },
  { timestamps: true }
);

export const TestimonialsSectionModel: Model<ITestimonialsSection> =
  mongoose.models.TestimonialsSection ||
  mongoose.model<ITestimonialsSection>("TestimonialsSection", TestimonialsSectionSchema);
