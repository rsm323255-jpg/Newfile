import mongoose, { Schema, Document, Model } from "mongoose";

export interface IWhyChooseUsSection extends Document {
  eyebrow: string;
  title: string;
  subtitle: string;
  isPublished: boolean;
  createdAt: Date;
  updatedAt: Date;
}

const WhyChooseUsSectionSchema = new Schema<IWhyChooseUsSection>(
  {
    eyebrow: { type: String, required: true },
    title: { type: String, required: true },
    subtitle: { type: String, required: true },
    isPublished: { type: Boolean, default: true },
  },
  { timestamps: true }
);

export const WhyChooseUsSectionModel: Model<IWhyChooseUsSection> =
  mongoose.models.WhyChooseUsSection ||
  mongoose.model<IWhyChooseUsSection>("WhyChooseUsSection", WhyChooseUsSectionSchema);
