import Link from "next/link";

export default function NotFound() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center px-6">
      <div className="flex flex-col items-center text-center">
        <p className="font-mono text-sm font-medium uppercase tracking-[0.3em] text-primary">
          Error 404
        </p>
        <h1 className="mt-4 text-6xl font-bold tracking-tight sm:text-8xl">
          Page not found
        </h1>
        <p className="mt-6 max-w-md text-lg text-muted-foreground">
          The page you&apos;re looking for doesn&apos;t exist, was moved, or
          never existed in the first place.
        </p>
        <Link
          href="/"
          className="mt-10 inline-flex h-12 items-center gap-2 rounded-xl bg-primary px-7 text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/25 transition-all hover:-translate-y-0.5 hover:bg-primary/90"
        >
          Back to Home
        </Link>
      </div>
    </main>
  );
}
