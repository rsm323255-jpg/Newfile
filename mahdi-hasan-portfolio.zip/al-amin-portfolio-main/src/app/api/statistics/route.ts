import { NextRequest } from "next/server";
import { connectToDatabase } from "@/lib/mongodb";
import { StatisticModel } from "@/models";
import { verifyAdminAuth, successResponse, errorResponse } from "@/lib/api-utils";

export async function GET() {
  await connectToDatabase();
  const stats = await StatisticModel.find({}).sort({ order: 1, createdAt: -1 }).lean();
  return successResponse(
    stats.map((s) => ({
      id: String(s._id),
      value: s.value,
      label: s.label,
      suffix: s.suffix,
    }))
  );
}

export async function POST(request: NextRequest) {
  const auth = await verifyAdminAuth(request);
  if ("error" in auth) return auth.error;

  try {
    const body = await request.json();
    await connectToDatabase();
    const created = await StatisticModel.create(body);
    return successResponse(
      {
        id: String(created._id),
        value: created.value,
        label: created.label,
        suffix: created.suffix,
      },
      201
    );
  } catch {
    return errorResponse("Invalid request body");
  }
}
