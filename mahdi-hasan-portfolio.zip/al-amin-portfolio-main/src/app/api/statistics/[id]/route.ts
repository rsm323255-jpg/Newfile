import { NextRequest } from "next/server";
import { connectToDatabase } from "@/lib/mongodb";
import { StatisticModel } from "@/models";
import { verifyAdminAuth, successResponse, errorResponse } from "@/lib/api-utils";

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  await connectToDatabase();
  const item = await StatisticModel.findById(id).lean();
  if (!item) return errorResponse("Not found", 404);
  return successResponse({
    id: String(item._id),
    value: item.value,
    label: item.label,
    suffix: item.suffix,
  });
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const auth = await verifyAdminAuth(request);
  if ("error" in auth) return auth.error;

  const { id } = await params;
  try {
    const body = await request.json();
    await connectToDatabase();
    const updated = await StatisticModel.findByIdAndUpdate(id, body, { new: true }).lean();
    if (!updated) return errorResponse("Not found", 404);
    return successResponse({
      id: String(updated._id),
      value: updated.value,
      label: updated.label,
      suffix: updated.suffix,
    });
  } catch {
    return errorResponse("Invalid request body");
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const auth = await verifyAdminAuth(request);
  if ("error" in auth) return auth.error;

  const { id } = await params;
  await connectToDatabase();
  const deleted = await StatisticModel.findByIdAndDelete(id);
  if (!deleted) return errorResponse("Not found", 404);
  return successResponse(null);
}
