import { NextRequest } from "next/server";
import { connectToDatabase } from "@/lib/mongodb";
import { VisitorModel } from "@/models";
import { verifyAdminAuth, successResponse, errorResponse } from "@/lib/api-utils";
import { rateLimit, rateLimitHeaders } from "@/lib/rate-limit";

export async function POST(request: NextRequest) {
  // Analytics need the database; without one, skip quietly instead of logging a failed request.
  if (!process.env.MONGODB_URI) {
    return new Response(null, { status: 204 });
  }

  // ─── Rate limit: 30 visitor tracking requests per minute per IP ──
  const rl = await rateLimit(request, "visitors", 30, 60_000);
  if (!rl.allowed) {
    return errorResponse("Too many requests", 429);
  }

  try {
    const body = await request.json();
    const forwarded = request.headers.get("x-forwarded-for");
    const ip = (forwarded?.split(",")[0] || body.ip || "unknown").trim();
    const userAgent = (request.headers.get("user-agent") || body.userAgent || "").slice(0, 500);
    const referrer = (body.referrer || "").slice(0, 2048);
    const path = (body.path || "/").slice(0, 2048);

    await connectToDatabase();
    await VisitorModel.create({ ip, userAgent, referrer, path });
    return successResponse({ recorded: true }, 201);
  } catch {
    return errorResponse("Failed to record visit");
  }
}

export async function GET(request: NextRequest) {
  const auth = await verifyAdminAuth(request);
  if ("error" in auth) return auth.error;

  try {
    await connectToDatabase();

    const { searchParams } = new URL(request.url);
    const limit = Math.min(parseInt(searchParams.get("limit") || "20", 10), 200);
    const cursor = searchParams.get("cursor");
    const days = parseInt(searchParams.get("days") || "30", 10);
    const since = new Date();
    since.setDate(since.getDate() - days);

    const baseFilter: Record<string, unknown> = { createdAt: { $gte: since } };
    const listFilter: Record<string, unknown> = { ...baseFilter };
    if (cursor) {
      listFilter._id = { $lt: cursor };
    }

    const [items, totalVisits, uniqueIps, topPages, dailyVisits] = await Promise.all([
      VisitorModel.find(listFilter)
        .sort({ _id: -1 })
        .limit(limit + 1)
        .lean()
        .select({ ip: 1, path: 1, referrer: 1, userAgent: 1, createdAt: 1 }),
      VisitorModel.countDocuments(baseFilter),
      VisitorModel.distinct("ip", baseFilter).then((ips) => ips.length),
      VisitorModel.aggregate([
        { $match: baseFilter },
        { $group: { _id: "$path", count: { $sum: 1 } } },
        { $sort: { count: -1 } },
        { $limit: 10 },
      ]),
      VisitorModel.aggregate([
        { $match: baseFilter },
        {
          $group: {
            _id: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } },
            visits: { $sum: 1 },
          },
        },
        { $sort: { _id: 1 } },
      ]),
    ]);

    const hasMore = items.length > limit;
    const sliced = hasMore ? items.slice(0, limit) : items;
    const nextCursor = hasMore ? String(sliced[sliced.length - 1]._id) : null;

    return successResponse({
      visitors: sliced.map((v) => ({
        id: String(v._id),
        ip: v.ip,
        path: v.path,
        referrer: v.referrer,
        userAgent: v.userAgent,
        createdAt: v.createdAt,
      })),
      nextCursor,
      stats: {
        totalVisits,
        uniqueVisitors: uniqueIps,
        topPages: topPages.map((p) => ({ path: p._id, count: p.count })),
        dailyVisits: dailyVisits.map((d) => ({ date: d._id, visits: d.visits })),
      },
    });
  } catch {
    return errorResponse("Failed to fetch visitors");
  }
}
