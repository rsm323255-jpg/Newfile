import { NextRequest } from "next/server";
import { verifyAdminAuth, successResponse, errorResponse } from "@/lib/api-utils";
import { connectToDatabase } from "@/lib/mongodb";
import { MediaModel } from "@/models";
import { cloudinary } from "@/lib/cloudinary";

export async function GET(request: NextRequest) {
  const auth = await verifyAdminAuth(request);
  if ("error" in auth) return auth.error;

  try {
    await connectToDatabase();
    const { searchParams } = new URL(request.url);
    const folder = searchParams.get("folder");
    const page = Math.max(1, parseInt(searchParams.get("page") || "1"));
    const limit = Math.min(50, Math.max(1, parseInt(searchParams.get("limit") || "24")));
    const skip = (page - 1) * limit;

    const query = folder ? { folder } : {};
    const [items, total] = await Promise.all([
      MediaModel.find(query).sort({ createdAt: -1 }).skip(skip).limit(limit).lean(),
      MediaModel.countDocuments(query),
    ]);

    return successResponse({
      items,
      total,
      page,
      totalPages: Math.ceil(total / limit),
    });
  } catch {
    return errorResponse("Failed to fetch media");
  }
}

export async function DELETE(request: NextRequest) {
  const auth = await verifyAdminAuth(request);
  if ("error" in auth) return auth.error;

  try {
    const { id, publicId } = await request.json();
    if (!id && !publicId) return errorResponse("No media ID provided");

    await connectToDatabase();

    const media = id
      ? await MediaModel.findById(id)
      : await MediaModel.findOne({ publicId });

    if (!media) return errorResponse("Media not found", 404);

    try {
      await cloudinary.uploader.destroy(media.publicId);
    } catch {
      // Cloudinary delete failed, still remove from DB
    }

    await MediaModel.findByIdAndDelete(media._id);
    return successResponse({ deleted: true });
  } catch {
    return errorResponse("Failed to delete media");
  }
}
