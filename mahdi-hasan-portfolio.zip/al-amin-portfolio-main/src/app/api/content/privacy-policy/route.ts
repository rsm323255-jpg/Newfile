import { verifyAdminAuth, successResponse, errorResponse } from "@/lib/api-utils";
import { NextRequest } from "next/server";
import { connectToDatabase } from "@/lib/mongodb";
import { PrivacyPolicyModel } from "@/models";

export async function GET() {
  await connectToDatabase();
  const data = await PrivacyPolicyModel.findOne({ isPublished: true }).sort({ updatedAt: -1 });
  return successResponse(data || { title: "Privacy Policy", content: "", lastUpdated: "" });
}

export async function PUT(request: NextRequest) {
  const auth = await verifyAdminAuth(request);
  if ("error" in auth) return auth.error;

  try {
    const body = await request.json();
    await connectToDatabase();

    const existing = await PrivacyPolicyModel.findOne().sort({ updatedAt: -1 });
    if (existing) {
      Object.assign(existing, body);
      await existing.save();
      return successResponse(existing);
    }

    const created = await PrivacyPolicyModel.create(body);
    return successResponse(created, 201);
  } catch {
    return errorResponse("Invalid request body");
  }
}
