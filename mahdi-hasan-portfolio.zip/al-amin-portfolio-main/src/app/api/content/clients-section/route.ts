import { verifyAdminAuth, successResponse, errorResponse } from "@/lib/api-utils";
import { NextRequest } from "next/server";
import { connectToDatabase } from "@/lib/mongodb";
import { ClientsSectionModel } from "@/models";

const defaultData = {
  eyebrow: "Trusted Clients",
  title: "Brands That Trust My Strategy",
  subtitle: "From scrappy startups to category leaders, I help ambitious brands turn attention into revenue.",
};

export async function GET() {
  await connectToDatabase();
  const data = await ClientsSectionModel.findOne({ isPublished: true }).sort({ updatedAt: -1 });
  if (data) {
    return successResponse({
      eyebrow: data.eyebrow || defaultData.eyebrow,
      title: data.title || defaultData.title,
      subtitle: data.subtitle || defaultData.subtitle,
    });
  }
  return successResponse(defaultData);
}

export async function PUT(request: NextRequest) {
  const auth = await verifyAdminAuth(request);
  if ("error" in auth) return auth.error;

  try {
    const body = await request.json();
    await connectToDatabase();

    const existing = await ClientsSectionModel.findOne().sort({ updatedAt: -1 });
    if (existing) {
      Object.assign(existing, body);
      await existing.save();
      return successResponse(existing);
    }

    const created = await ClientsSectionModel.create(body);
    return successResponse(created, 201);
  } catch {
    return errorResponse("Invalid request body");
  }
}
