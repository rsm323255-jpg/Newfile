import { verifyAdminAuth, successResponse, errorResponse } from "@/lib/api-utils";
import { NextRequest } from "next/server";
import { connectToDatabase } from "@/lib/mongodb";
import { WhyChooseUsSectionModel } from "@/models";

const defaultData = {
  eyebrow: "Why Choose Us",
  title: "The Unfair Advantage Behind Every Campaign",
  subtitle: "I combine creative storytelling with data-driven precision to deliver results that actually matter to your bottom line.",
};

export async function GET() {
  await connectToDatabase();
  const data = await WhyChooseUsSectionModel.findOne({ isPublished: true }).sort({ updatedAt: -1 });
  if (data) {
    return successResponse({
      eyebrow: data.eyebrow || defaultData.eyebrow,
      title: data.title || defaultData.title,
      subtitle: data.subtitle || defaultData.subtitle,
    });
  }
  return successResponse(defaultData);
}

export async function PUT(request: NextRequest) {
  const auth = await verifyAdminAuth(request);
  if ("error" in auth) return auth.error;

  try {
    const body = await request.json();
    await connectToDatabase();

    const existing = await WhyChooseUsSectionModel.findOne().sort({ updatedAt: -1 });
    if (existing) {
      Object.assign(existing, body);
      await existing.save();
      return successResponse(existing);
    }

    const created = await WhyChooseUsSectionModel.create(body);
    return successResponse(created, 201);
  } catch {
    return errorResponse("Invalid request body");
  }
}
