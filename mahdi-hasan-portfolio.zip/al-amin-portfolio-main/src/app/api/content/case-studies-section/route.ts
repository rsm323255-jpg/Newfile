import { verifyAdminAuth, successResponse, errorResponse } from "@/lib/api-utils";
import { NextRequest } from "next/server";
import { connectToDatabase } from "@/lib/mongodb";
import { CaseStudiesSectionModel } from "@/models";

const defaultData = {
  eyebrow: "Case Studies",
  title: "Real Growth, Real Numbers",
  subtitle: "Deep dives into campaigns that moved the needle — every metric verified, every result repeatable.",
};

export async function GET() {
  await connectToDatabase();
  const data = await CaseStudiesSectionModel.findOne({ isPublished: true }).sort({ updatedAt: -1 });
  if (data) {
    return successResponse({
      eyebrow: data.eyebrow || defaultData.eyebrow,
      title: data.title || defaultData.title,
      subtitle: data.subtitle || defaultData.subtitle,
    });
  }
  return successResponse(defaultData);
}

export async function PUT(request: NextRequest) {
  const auth = await verifyAdminAuth(request);
  if ("error" in auth) return auth.error;

  try {
    const body = await request.json();
    await connectToDatabase();

    const existing = await CaseStudiesSectionModel.findOne().sort({ updatedAt: -1 });
    if (existing) {
      Object.assign(existing, body);
      await existing.save();
      return successResponse(existing);
    }

    const created = await CaseStudiesSectionModel.create(body);
    return successResponse(created, 201);
  } catch {
    return errorResponse("Invalid request body");
  }
}
