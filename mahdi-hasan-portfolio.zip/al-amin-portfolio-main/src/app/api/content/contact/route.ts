import { verifyAdminAuth, successResponse, errorResponse } from "@/lib/api-utils";
import { NextRequest } from "next/server";
import { connectToDatabase } from "@/lib/mongodb";
import { ContactModel } from "@/models";
import { contactInfo } from "@/data/contact";

export async function GET() {
  await connectToDatabase();
  const data = await ContactModel.findOne({ isPublished: true }).sort({ updatedAt: -1 });
  if (data) {
    return successResponse({
      eyebrow: data.eyebrow || contactInfo.eyebrow,
      title: data.title || contactInfo.title,
      subtitle: data.subtitle || contactInfo.subtitle,
      email: data.email || contactInfo.email,
      phone: data.phone || contactInfo.phone,
      address: data.address || contactInfo.address,
      workingHours: data.workingHours || contactInfo.workingHours,
    });
  }
  return successResponse(contactInfo);
}

export async function PUT(request: NextRequest) {
  const auth = await verifyAdminAuth(request);
  if ("error" in auth) return auth.error;

  try {
    const body = await request.json();
    await connectToDatabase();

    const existing = await ContactModel.findOne().sort({ updatedAt: -1 });
    if (existing) {
      Object.assign(existing, body);
      await existing.save();
      return successResponse(existing);
    }

    const created = await ContactModel.create(body);
    return successResponse(created, 201);
  } catch {
    return errorResponse("Invalid request body");
  }
}
