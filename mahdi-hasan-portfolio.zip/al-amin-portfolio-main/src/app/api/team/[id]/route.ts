import { NextRequest } from "next/server";
import { connectToDatabase } from "@/lib/mongodb";
import { TeamMemberModel } from "@/models";
import { verifyAdminAuth, successResponse, errorResponse } from "@/lib/api-utils";

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  await connectToDatabase();
  const item = await TeamMemberModel.findById(id).lean();
  if (!item) return errorResponse("Not found", 404);
  return successResponse({
    id: String(item._id),
    name: item.name,
    role: item.role,
    bio: item.bio,
    avatar: item.avatar,
    social: item.social,
  });
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const auth = await verifyAdminAuth(request);
  if ("error" in auth) return auth.error;

  const { id } = await params;
  try {
    const body = await request.json();
    await connectToDatabase();
    const updated = await TeamMemberModel.findByIdAndUpdate(id, body, { new: true }).lean();
    if (!updated) return errorResponse("Not found", 404);
    return successResponse({
      id: String(updated._id),
      name: updated.name,
      role: updated.role,
      bio: updated.bio,
      avatar: updated.avatar,
      social: updated.social,
    });
  } catch {
    return errorResponse("Invalid request body");
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const auth = await verifyAdminAuth(request);
  if ("error" in auth) return auth.error;

  const { id } = await params;
  await connectToDatabase();
  const deleted = await TeamMemberModel.findByIdAndDelete(id);
  if (!deleted) return errorResponse("Not found", 404);
  return successResponse(null);
}
