import { NextRequest } from "next/server";
import { connectToDatabase } from "@/lib/mongodb";
import { TeamMemberModel } from "@/models";
import { verifyAdminAuth, successResponse, errorResponse } from "@/lib/api-utils";

export async function GET() {
  await connectToDatabase();
  const members = await TeamMemberModel.find({}).sort({ order: 1, createdAt: -1 }).lean();
  return successResponse(
    members.map((m) => ({
      id: String(m._id),
      name: m.name,
      role: m.role,
      bio: m.bio,
      avatar: m.avatar,
      social: m.social,
    }))
  );
}

export async function POST(request: NextRequest) {
  const auth = await verifyAdminAuth(request);
  if ("error" in auth) return auth.error;

  try {
    const body = await request.json();
    await connectToDatabase();
    const created = await TeamMemberModel.create(body);
    return successResponse(
      {
        id: String(created._id),
        name: created.name,
        role: created.role,
        bio: created.bio,
        avatar: created.avatar,
        social: created.social,
      },
      201
    );
  } catch {
    return errorResponse("Invalid request body");
  }
}
