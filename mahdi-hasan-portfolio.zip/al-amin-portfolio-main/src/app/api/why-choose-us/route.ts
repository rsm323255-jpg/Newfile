import { NextRequest } from "next/server";
import { connectToDatabase } from "@/lib/mongodb";
import { WhyChooseUsModel } from "@/models";
import { verifyAdminAuth, successResponse, errorResponse } from "@/lib/api-utils";

export async function GET() {
  await connectToDatabase();
  const items = await WhyChooseUsModel.find({}).sort({ order: 1, createdAt: -1 }).lean();
  return successResponse(
    items.map((item) => ({
      id: String(item._id),
      title: item.title,
      description: item.description,
      icon: item.icon,
    }))
  );
}

export async function POST(request: NextRequest) {
  const auth = await verifyAdminAuth(request);
  if ("error" in auth) return auth.error;

  try {
    const body = await request.json();
    await connectToDatabase();
    const created = await WhyChooseUsModel.create(body);
    return successResponse(
      {
        id: String(created._id),
        title: created.title,
        description: created.description,
        icon: created.icon,
      },
      201
    );
  } catch {
    return errorResponse("Invalid request body");
  }
}
