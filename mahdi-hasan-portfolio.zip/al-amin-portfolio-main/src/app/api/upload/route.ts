import { NextRequest } from "next/server";
import { verifyAdminAuth, successResponse, errorResponse } from "@/lib/api-utils";
import { cloudinary } from "@/lib/cloudinary";
import { connectToDatabase } from "@/lib/mongodb";
import { MediaModel } from "@/models";
import { rateLimit } from "@/lib/rate-limit";

export async function POST(request: NextRequest) {
  const rl = await rateLimit(request, "upload", 20, 60_000);
  if (!rl.allowed) {
    return errorResponse("Too many requests. Please try again later.", 429);
  }

  const auth = await verifyAdminAuth(request);
  if ("error" in auth) return auth.error;

  try {
    const formData = await request.formData();
    const file = formData.get("file") as File | null;
    const folder = (formData.get("folder") as string) || "gallery";

    if (!file) {
      return errorResponse("No file provided");
    }

    const allowedTypes = ["image/jpeg", "image/png", "image/webp", "image/gif"];
    if (!allowedTypes.includes(file.type)) {
      return errorResponse("Invalid file type. Allowed: JPEG, PNG, WebP, GIF");
    }

    const maxSize = 5 * 1024 * 1024;
    if (file.size > maxSize) {
      return errorResponse("File too large. Maximum size: 5MB");
    }

    const sanitizedFolder = folder.replace(/[^a-zA-Z0-9-_]/g, "").slice(0, 50);

    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);

    const result = await new Promise<{ secure_url: string; public_id: string }>(
      (resolve, reject) => {
        const uploadStream = cloudinary.uploader.upload_stream(
          {
            folder: `mahdi-portfolio/${sanitizedFolder}`,
            resource_type: "image",
            transformation: [{ quality: "auto", fetch_format: "auto" }],
          },
          (error, result) => {
            if (error || !result) return reject(error);
            resolve({ secure_url: result.secure_url, public_id: result.public_id });
          }
        );
        uploadStream.end(buffer);
      }
    );

    await connectToDatabase();
    const media = await MediaModel.create({
      url: result.secure_url,
      publicId: result.public_id,
      filename: result.public_id.split("/").pop() || file.name,
      originalName: file.name,
      mimeType: file.type,
      size: file.size,
      folder: sanitizedFolder,
      uploadedBy: auth.payload.userId,
    });

    return successResponse({
      id: media._id,
      url: result.secure_url,
      publicId: result.public_id,
    }, 201);
  } catch {
    return errorResponse("Failed to upload image", 500);
  }
}
