import { NextRequest } from "next/server";
import { verifyAdminAuth, successResponse, errorResponse } from "@/lib/api-utils";
import { connectToDatabase } from "@/lib/mongodb";
import { PortfolioModel } from "@/models";

export async function GET() {
  await connectToDatabase();
  const items = await PortfolioModel.find({ isPublished: true }).sort({ order: 1, createdAt: -1 }).lean();
  return successResponse(
    items.map((item) => ({
      id: String(item._id),
      title: item.title,
      slug: item.slug,
      category: item.category,
      image: item.image,
      description: item.description,
      tags: item.tags,
      results: item.results,
    }))
  );
}

export async function POST(request: NextRequest) {
  const auth = await verifyAdminAuth(request);
  if ("error" in auth) return auth.error;

  try {
    const body = await request.json();
    await connectToDatabase();

    const slug = body.slug || body.title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
    const created = await PortfolioModel.create({ ...body, slug });
    return successResponse(
      {
        id: String(created._id),
        title: created.title,
        slug: created.slug,
        category: created.category,
        image: created.image,
        description: created.description,
        tags: created.tags,
        results: created.results,
      },
      201
    );
  } catch {
    return errorResponse("Invalid request body");
  }
}
