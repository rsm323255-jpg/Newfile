import { NextRequest } from "next/server";
import { connectToDatabase } from "@/lib/mongodb";
import { ActivityModel } from "@/models";
import { verifyAdminAuth, successResponse, errorResponse } from "@/lib/api-utils";

export async function GET(request: NextRequest) {
  const auth = await verifyAdminAuth(request);
  if ("error" in auth) return auth.error;

  try {
    await connectToDatabase();

    const { searchParams } = new URL(request.url);
    const limit = Math.min(parseInt(searchParams.get("limit") || "20", 10), 100);
    const cursor = searchParams.get("cursor");

    const filter: Record<string, unknown> = {};
    if (cursor) {
      filter._id = { $lt: cursor };
    }

    const [items, total] = await Promise.all([
      ActivityModel.find(filter)
        .sort({ _id: -1 })
        .limit(limit + 1)
        .lean(),
      ActivityModel.countDocuments(),
    ]);

    const hasMore = items.length > limit;
    const sliced = hasMore ? items.slice(0, limit) : items;
    const nextCursor = hasMore ? String(sliced[sliced.length - 1]._id) : null;

    return successResponse({
      data: sliced.map((a) => ({
        id: String(a._id),
        action: a.action,
        entity: a.entity,
        entityId: a.entityId,
        entityTitle: a.entityTitle,
        userId: a.userId,
        userName: a.userName,
        details: a.details,
        createdAt: a.createdAt,
      })),
      nextCursor,
      total,
    });
  } catch {
    return errorResponse("Failed to fetch activities");
  }
}

export async function POST(request: NextRequest) {
  const auth = await verifyAdminAuth(request);
  if ("error" in auth) return auth.error;

  try {
    const body = await request.json();
    await connectToDatabase();
    const created = await ActivityModel.create({
      action: body.action,
      entity: body.entity,
      entityId: body.entityId,
      entityTitle: body.entityTitle,
      userId: auth.payload.userId,
      userName: auth.payload.name,
      details: body.details,
    });
    return successResponse(
      {
        id: String(created._id),
        action: created.action,
        entity: created.entity,
        entityId: created.entityId,
        entityTitle: created.entityTitle,
        userId: created.userId,
        userName: created.userName,
        details: created.details,
        createdAt: created.createdAt,
      },
      201
    );
  } catch {
    return errorResponse("Invalid request body");
  }
}
