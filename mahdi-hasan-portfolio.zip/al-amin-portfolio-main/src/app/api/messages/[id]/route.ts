import { NextRequest } from "next/server";
import { connectToDatabase } from "@/lib/mongodb";
import { MessageModel } from "@/models";
import { verifyAdminAuth, successResponse, errorResponse } from "@/lib/api-utils";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const auth = await verifyAdminAuth(request);
  if ("error" in auth) return auth.error;

  try {
    const { id } = await params;
    await connectToDatabase();
    const message = await MessageModel.findById(id).lean();
    if (!message) return errorResponse("Message not found", 404);
    return successResponse(message);
  } catch {
    return errorResponse("Failed to fetch message", 500);
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const auth = await verifyAdminAuth(request);
  if ("error" in auth) return auth.error;

  try {
    const { id } = await params;
    const body = await request.json();
    await connectToDatabase();
    const message = await MessageModel.findByIdAndUpdate(id, body, { new: true }).lean();
    if (!message) return errorResponse("Message not found", 404);
    return successResponse(message);
  } catch {
    return errorResponse("Failed to update message", 500);
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const auth = await verifyAdminAuth(request);
  if ("error" in auth) return auth.error;

  try {
    const { id } = await params;
    await connectToDatabase();
    const message = await MessageModel.findByIdAndDelete(id).lean();
    if (!message) return errorResponse("Message not found", 404);
    return successResponse({ deleted: true });
  } catch {
    return errorResponse("Failed to delete message", 500);
  }
}
