import { NextRequest } from "next/server";
import { connectToDatabase } from "@/lib/mongodb";
import { MessageModel } from "@/models";
import { verifyAdminAuth, successResponse, errorResponse } from "@/lib/api-utils";

export async function GET(request: NextRequest) {
  const auth = await verifyAdminAuth(request);
  if ("error" in auth) return auth.error;

  try {
    await connectToDatabase();
    const messages = await MessageModel.find().sort({ createdAt: -1 }).lean();
    return successResponse(messages);
  } catch {
    return errorResponse("Failed to fetch messages", 500);
  }
}

export async function DELETE(request: NextRequest) {
  const auth = await verifyAdminAuth(request);
  if ("error" in auth) return auth.error;

  try {
    const { ids } = await request.json();
    await connectToDatabase();

    if (ids && Array.isArray(ids)) {
      await MessageModel.deleteMany({ _id: { $in: ids } });
    } else {
      await MessageModel.deleteMany({});
    }

    return successResponse({ deleted: true });
  } catch {
    return errorResponse("Failed to delete messages", 500);
  }
}
