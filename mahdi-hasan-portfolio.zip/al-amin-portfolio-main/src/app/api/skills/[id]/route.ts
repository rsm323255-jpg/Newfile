import { NextRequest } from "next/server";
import { verifyAdminAuth, successResponse, errorResponse } from "@/lib/api-utils";
import { connectToDatabase } from "@/lib/mongodb";
import { SkillModel } from "@/models";

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  await connectToDatabase();
  const item = await SkillModel.findById(id).lean();
  if (!item) return errorResponse("Not found", 404);
  return successResponse({
    id: String(item._id),
    title: item.title,
    description: item.description,
    icon: item.icon,
    features: item.features,
    order: item.order,
  });
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const auth = await verifyAdminAuth(request);
  if ("error" in auth) return auth.error;

  const { id } = await params;
  try {
    const body = await request.json();
    await connectToDatabase();
    const updated = await SkillModel.findByIdAndUpdate(id, body, { new: true }).lean();
    if (!updated) return errorResponse("Not found", 404);
    return successResponse({
      id: String(updated._id),
      title: updated.title,
      description: updated.description,
      icon: updated.icon,
      features: updated.features,
      order: updated.order,
    });
  } catch {
    return errorResponse("Invalid request body");
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const auth = await verifyAdminAuth(request);
  if ("error" in auth) return auth.error;

  const { id } = await params;
  await connectToDatabase();
  const deleted = await SkillModel.findByIdAndDelete(id);
  if (!deleted) return errorResponse("Not found", 404);
  return successResponse(null);
}
