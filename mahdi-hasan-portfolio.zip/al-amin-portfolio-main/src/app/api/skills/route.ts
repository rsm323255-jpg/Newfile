import { NextRequest } from "next/server";
import { verifyAdminAuth, successResponse, errorResponse } from "@/lib/api-utils";
import { connectToDatabase } from "@/lib/mongodb";
import { SkillModel } from "@/models";

export async function GET() {
  await connectToDatabase();
  const skills = await SkillModel.find({ isPublished: true }).sort({ order: 1, createdAt: -1 }).lean();
  const mapped = skills.map((s) => ({
    id: String(s._id),
    title: s.title,
    description: s.description,
    icon: s.icon,
    features: s.features,
    order: s.order,
  }));
  return successResponse(mapped);
}

export async function POST(request: NextRequest) {
  const auth = await verifyAdminAuth(request);
  if ("error" in auth) return auth.error;

  try {
    const body = await request.json();
    await connectToDatabase();
    const created = await SkillModel.create(body);
    return successResponse(created, 201);
  } catch {
    return errorResponse("Invalid request body");
  }
}
