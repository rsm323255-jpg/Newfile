import { NextRequest, NextResponse } from "next/server";
import { verifyToken, getAccessToken, getRefreshToken, refreshAccessToken, setTokenCookies } from "@/lib/auth";

export async function GET(request: NextRequest) {
  try {
    const accessToken = await getAccessToken();

    if (accessToken) {
      const payload = await verifyToken(accessToken);
      if (payload && payload.type === "access") {
        return NextResponse.json({
          success: true,
          data: {
            userId: payload.userId,
            email: payload.email,
            name: payload.name,
            role: payload.role,
          },
        });
      }
    }

    const refreshToken = await getRefreshToken();
    if (refreshToken) {
      const result = await refreshAccessToken(refreshToken);
      if (!("error" in result)) {
        await setTokenCookies(result.accessToken, result.refreshToken);
        const newPayload = await verifyToken(result.accessToken);
        if (newPayload && newPayload.type === "access") {
          return NextResponse.json({
            success: true,
            data: {
              userId: newPayload.userId,
              email: newPayload.email,
              name: newPayload.name,
              role: newPayload.role,
            },
          });
        }
      }
    }

    return NextResponse.json(
      { success: false, error: "Not authenticated" },
      { status: 401 }
    );
  } catch (error) {
    return NextResponse.json(
      { success: false, error: "Internal server error." },
      { status: 500 }
    );
  }
}
