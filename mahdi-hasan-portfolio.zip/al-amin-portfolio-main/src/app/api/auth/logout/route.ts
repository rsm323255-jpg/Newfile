import { NextResponse } from "next/server";
import { removeTokenCookies } from "@/lib/auth";

export async function POST() {
  try {
    await removeTokenCookies();
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: "Internal server error." },
      { status: 500 }
    );
  }
}
