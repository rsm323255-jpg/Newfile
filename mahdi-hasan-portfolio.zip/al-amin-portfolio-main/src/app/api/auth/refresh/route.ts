import { NextResponse } from "next/server";
import { removeTokenCookies, getRefreshToken, refreshAccessToken, setTokenCookies } from "@/lib/auth";
import { checkRateLimit, rateLimitHeaders } from "@/lib/rate-limit";

export async function POST(request: Request) {
  // ─── Rate limit: 20 refreshes per minute per IP ─────────────
  const ip =
    request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    request.headers.get("x-real-ip") ||
    "127.0.0.1";

  const rl = await checkRateLimit(`refresh:${ip}`, 20, 60_000);
  if (!rl.allowed) {
    return NextResponse.json(
      { success: false, error: "Too many requests." },
      { status: 429, headers: rateLimitHeaders(rl.remaining, rl.resetAt, 20) }
    );
  }

  try {
    const refreshToken = await getRefreshToken();

    if (!refreshToken) {
      return NextResponse.json(
        { success: false, error: "No refresh token found." },
        { status: 401 }
      );
    }

    const result = await refreshAccessToken(refreshToken);

    if ("error" in result) {
      await removeTokenCookies();
      return NextResponse.json(
        { success: false, error: result.error },
        { status: 401 }
      );
    }

    await setTokenCookies(result.accessToken, result.refreshToken);

    return NextResponse.json({
      success: true,
      data: {
        accessToken: result.accessToken,
        refreshToken: result.refreshToken,
      },
    });
  } catch {
    return NextResponse.json(
      { success: false, error: "Internal server error." },
      { status: 500 }
    );
  }
}
