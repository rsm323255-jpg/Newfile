import { NextRequest, NextResponse } from "next/server";
import { authenticateUser, setTokenCookies } from "@/lib/auth";
import {
  checkLoginAllowed,
  recordLoginAttempt,
  rateLimit,
  rateLimitHeaders,
} from "@/lib/rate-limit";

export async function POST(request: NextRequest) {
  // ─── Rate limit: 10 login attempts per minute per IP ─────────
  const rl = await rateLimit(request, "login", 10, 60_000);
  if (!rl.allowed) {
    return NextResponse.json(
      { success: false, error: "Too many requests. Please try again later." },
      { status: 429, headers: rateLimitHeaders(rl.remaining, rl.resetAt, 10) }
    );
  }

  // ─── Brute force protection ──────────────────────────────────
  const ip =
    request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    request.headers.get("x-real-ip") ||
    "127.0.0.1";

  const loginCheck = await checkLoginAllowed(ip);
  if (!loginCheck.allowed) {
    return NextResponse.json(
      {
        success: false,
        error: `Too many failed attempts. Try again in ${loginCheck.retryAfter} seconds.`,
      },
      {
        status: 429,
        headers: {
          "Retry-After": String(loginCheck.retryAfter),
          ...rateLimitHeaders(0, Date.now() + (loginCheck.retryAfter ?? 0) * 1000, 5),
        },
      }
    );
  }

  try {
    const { email, password } = await request.json();

    if (!email || !password) {
      return NextResponse.json(
        { success: false, error: "Email and password are required." },
        { status: 400 }
      );
    }

    // ─── Input length limits ─────────────────────────────────
    if (email.length > 254 || password.length > 128) {
      return NextResponse.json(
        { success: false, error: "Invalid credentials." },
        { status: 400 }
      );
    }

    const result = await authenticateUser(email, password);

    if ("error" in result) {
      await recordLoginAttempt(ip, false);
      return NextResponse.json(
        { success: false, error: result.error },
        { status: 401 }
      );
    }

    await recordLoginAttempt(ip, true);

    await setTokenCookies(result.accessToken, result.refreshToken);

    return NextResponse.json({
      success: true,
      data: {
        user: result.user,
        accessToken: result.accessToken,
        refreshToken: result.refreshToken,
      },
    });
  } catch {
    return NextResponse.json(
      { success: false, error: "Internal server error." },
      { status: 500 }
    );
  }
}
