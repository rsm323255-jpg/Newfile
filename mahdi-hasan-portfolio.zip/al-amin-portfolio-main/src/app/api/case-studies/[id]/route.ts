import { NextRequest } from "next/server";
import { verifyAdminAuth, successResponse, errorResponse } from "@/lib/api-utils";
import { connectToDatabase } from "@/lib/mongodb";
import { CaseStudyModel, type ICaseStudy } from "@/models";

function toCaseStudy(item: ICaseStudy & { _id: unknown }) {
  return {
    id: String(item._id),
    title: item.title,
    slug: item.slug,
    client: item.client,
    challenge: item.challenge,
    solution: item.solution,
    results: item.results,
    image: item.image,
    tags: item.tags,
  };
}

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  await connectToDatabase();
  const item = await CaseStudyModel.findById(id).lean();
  if (!item) return errorResponse("Not found", 404);
  return successResponse(toCaseStudy(item));
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const auth = await verifyAdminAuth(request);
  if ("error" in auth) return auth.error;

  const { id } = await params;
  try {
    const body = await request.json();
    await connectToDatabase();

    if (body.title && !body.slug) {
      body.slug = body.title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
    }

    const updated = await CaseStudyModel.findByIdAndUpdate(id, body, { new: true }).lean();
    if (!updated) return errorResponse("Not found", 404);
    return successResponse(toCaseStudy(updated));
  } catch {
    return errorResponse("Invalid request body");
  }
}

export async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const auth = await verifyAdminAuth(_request);
  if ("error" in auth) return auth.error;

  const { id } = await params;
  await connectToDatabase();
  const deleted = await CaseStudyModel.findByIdAndDelete(id);
  if (!deleted) return errorResponse("Not found", 404);
  return successResponse(null);
}
