import { NextRequest } from "next/server";
import { verifyAdminAuth, successResponse, errorResponse } from "@/lib/api-utils";
import { connectToDatabase } from "@/lib/mongodb";
import { CaseStudyModel } from "@/models";

export async function GET() {
  await connectToDatabase();
  const items = await CaseStudyModel.find({ isPublished: true }).sort({ order: 1, createdAt: -1 }).lean();
  return successResponse(
    items.map((item) => ({
      id: String(item._id),
      title: item.title,
      slug: item.slug,
      client: item.client,
      challenge: item.challenge,
      solution: item.solution,
      results: item.results,
      image: item.image,
      tags: item.tags,
    }))
  );
}

export async function POST(request: NextRequest) {
  const auth = await verifyAdminAuth(request);
  if ("error" in auth) return auth.error;

  try {
    const body = await request.json();
    await connectToDatabase();

    const slug = body.slug || body.title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
    const created = await CaseStudyModel.create({ ...body, slug });
    return successResponse(
      {
        id: String(created._id),
        title: created.title,
        slug: created.slug,
        client: created.client,
        challenge: created.challenge,
        solution: created.solution,
        results: created.results,
        image: created.image,
        tags: created.tags,
      },
      201
    );
  } catch {
    return errorResponse("Invalid request body");
  }
}
