import { NextRequest } from "next/server";
import { verifyAdminAuth, successResponse, errorResponse } from "@/lib/api-utils";
import { connectToDatabase } from "@/lib/mongodb";
import { ClientModel } from "@/models";

export async function GET() {
  await connectToDatabase();
  const items = await ClientModel.find({ isPublished: true }).sort({ order: 1, createdAt: -1 }).lean();
  return successResponse(
    items.map((item) => ({
      id: String(item._id),
      name: item.name,
      logo: item.logo,
      website: item.website,
    }))
  );
}

export async function POST(request: NextRequest) {
  const auth = await verifyAdminAuth(request);
  if ("error" in auth) return auth.error;

  try {
    const body = await request.json();
    await connectToDatabase();
    const created = await ClientModel.create(body);
    return successResponse(
      { id: String(created._id), name: created.name, logo: created.logo, website: created.website },
      201
    );
  } catch {
    return errorResponse("Invalid request body");
  }
}
