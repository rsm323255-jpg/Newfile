import { NextRequest } from "next/server";
import { verifyAdminAuth, successResponse, errorResponse } from "@/lib/api-utils";
import { connectToDatabase } from "@/lib/mongodb";
import { TestimonialModel } from "@/models";

export async function GET() {
  await connectToDatabase();
  const items = await TestimonialModel.find({ isPublished: true }).sort({ order: 1, createdAt: -1 }).lean();
  return successResponse(
    items.map((item) => ({
      id: String(item._id),
      name: item.name,
      role: item.role,
      company: item.company,
      content: item.content,
      avatar: item.avatar,
      rating: item.rating,
    }))
  );
}

export async function POST(request: NextRequest) {
  const auth = await verifyAdminAuth(request);
  if ("error" in auth) return auth.error;

  try {
    const body = await request.json();
    await connectToDatabase();
    const created = await TestimonialModel.create(body);
    return successResponse(
      {
        id: String(created._id),
        name: created.name,
        role: created.role,
        company: created.company,
        content: created.content,
        avatar: created.avatar,
        rating: created.rating,
      },
      201
    );
  } catch {
    return errorResponse("Invalid request body");
  }
}
