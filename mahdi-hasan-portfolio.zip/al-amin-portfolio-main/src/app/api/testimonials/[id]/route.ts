import { NextRequest } from "next/server";
import { verifyAdminAuth, successResponse, errorResponse } from "@/lib/api-utils";
import { connectToDatabase } from "@/lib/mongodb";
import { TestimonialModel, type ITestimonial } from "@/models";

function toTestimonial(item: ITestimonial & { _id: unknown }) {
  return {
    id: String(item._id),
    name: item.name,
    role: item.role,
    company: item.company,
    content: item.content,
    avatar: item.avatar,
    rating: item.rating,
  };
}

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  await connectToDatabase();
  const item = await TestimonialModel.findById(id).lean();
  if (!item) return errorResponse("Not found", 404);
  return successResponse(toTestimonial(item));
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const auth = await verifyAdminAuth(request);
  if ("error" in auth) return auth.error;

  const { id } = await params;
  try {
    const body = await request.json();
    await connectToDatabase();
    const updated = await TestimonialModel.findByIdAndUpdate(id, body, { new: true }).lean();
    if (!updated) return errorResponse("Not found", 404);
    return successResponse(toTestimonial(updated));
  } catch {
    return errorResponse("Invalid request body");
  }
}

export async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const auth = await verifyAdminAuth(_request);
  if ("error" in auth) return auth.error;

  const { id } = await params;
  await connectToDatabase();
  const deleted = await TestimonialModel.findByIdAndDelete(id);
  if (!deleted) return errorResponse("Not found", 404);
  return successResponse(null);
}
