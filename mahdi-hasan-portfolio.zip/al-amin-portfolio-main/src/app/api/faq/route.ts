import { NextRequest } from "next/server";
import { verifyAdminAuth, successResponse, errorResponse } from "@/lib/api-utils";
import { connectToDatabase } from "@/lib/mongodb";
import { FAQModel } from "@/models";

export async function GET() {
  await connectToDatabase();
  const items = await FAQModel.find({ isPublished: true }).sort({ order: 1, createdAt: -1 }).lean();
  return successResponse(
    items.map((item) => ({
      id: String(item._id),
      question: item.question,
      answer: item.answer,
    }))
  );
}

export async function POST(request: NextRequest) {
  const auth = await verifyAdminAuth(request);
  if ("error" in auth) return auth.error;

  try {
    const body = await request.json();
    await connectToDatabase();
    const created = await FAQModel.create(body);
    return successResponse(
      { id: String(created._id), question: created.question, answer: created.answer },
      201
    );
  } catch {
    return errorResponse("Invalid request body");
  }
}
