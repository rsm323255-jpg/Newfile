import { NextRequest } from "next/server";
import { verifyAdminAuth, successResponse, errorResponse } from "@/lib/api-utils";
import { connectToDatabase } from "@/lib/mongodb";
import { ProcessStepModel, type IProcessStep } from "@/models";

function toProcessStep(item: IProcessStep & { _id: unknown }) {
  return { id: String(item._id), title: item.title, description: item.description, icon: item.icon };
}

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  await connectToDatabase();
  const item = await ProcessStepModel.findById(id).lean();
  if (!item) return errorResponse("Not found", 404);
  return successResponse(toProcessStep(item));
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const auth = await verifyAdminAuth(request);
  if ("error" in auth) return auth.error;

  const { id } = await params;
  try {
    const body = await request.json();
    await connectToDatabase();
    const updated = await ProcessStepModel.findByIdAndUpdate(id, body, { new: true }).lean();
    if (!updated) return errorResponse("Not found", 404);
    return successResponse(toProcessStep(updated));
  } catch {
    return errorResponse("Invalid request body");
  }
}

export async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const auth = await verifyAdminAuth(_request);
  if ("error" in auth) return auth.error;

  const { id } = await params;
  await connectToDatabase();
  const deleted = await ProcessStepModel.findByIdAndDelete(id);
  if (!deleted) return errorResponse("Not found", 404);
  return successResponse(null);
}
