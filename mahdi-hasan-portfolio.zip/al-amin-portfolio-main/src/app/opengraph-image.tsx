import { ImageResponse } from "next/og";

export const size = { width: 1200, height: 630 };
export const contentType = "image/png";
export const alt = "Mahdi Hasan | Media Buyer & Paid Advertising Consultant";

export default function OpengraphImage() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          padding: 80,
          background: "linear-gradient(135deg, #002e9f 0%, #001a5e 100%)",
          color: "#ffffff",
        }}
      >
        <div style={{ fontSize: 24, letterSpacing: 6, color: "#00aada", textTransform: "uppercase", display: "flex" }}>
          Media Buyer & Paid Advertising Consultant
        </div>
        <div style={{ fontSize: 112, fontWeight: 600, marginTop: 24, display: "flex" }}>Mahdi Hasan</div>
        <div style={{ fontSize: 36, marginTop: 24, color: "#f3f5fb", display: "flex" }}>
          Strategic vision. Structured growth.
        </div>
      </div>
    ),
    { ...size }
  );
}
