"use client";

import * as React from "react";
import { useRouter, useParams } from "next/navigation";
import { PageHeader } from "@/components/admin/page-header";
import { AdminForm } from "@/components/admin/admin-form";
import { FormField, FormInput } from "@/components/admin/form-field";
import { Skeleton } from "@/components/ui/skeleton";
import { useAdminDetail, useAdminUpdate } from "@/hooks/use-admin";
import type { Statistic } from "@/types";

export default function AdminStatisticsEditPage() {
  const router = useRouter();
  const params = useParams();
  const id = params.id as string;
  const { data: item, isLoading } = useAdminDetail<Statistic>("/statistics", id);
  const updateMutation = useAdminUpdate<Statistic>("/statistics");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget as HTMLFormElement);
    await updateMutation.mutateAsync({
      id,
      data: {
        value: fd.get("value") as string,
        label: fd.get("label") as string,
        suffix: fd.get("suffix") as string,
      },
    });
    router.push("/admin/statistics");
  }

  if (isLoading) return <div className="space-y-6"><Skeleton className="h-10 w-48" /><Skeleton className="h-4 w-72" /><div className="space-y-4"><Skeleton className="h-12 w-full rounded-xl" /><Skeleton className="h-12 w-full rounded-xl" /><Skeleton className="h-12 w-full rounded-xl" /></div></div>;

  return (
    <div className="space-y-6">
      <PageHeader title="Edit Statistic" breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "Statistics", href: "/admin/statistics" }, { label: "Edit", href: `/admin/statistics/${id}` }]} />
      <AdminForm title="Statistic Details" onSubmit={handleSubmit} loading={updateMutation.isPending} backHref="/admin/statistics" submitLabel="Update">
        <FormField label="Value" htmlFor="value" required><FormInput id="value" name="value" required defaultValue={item?.value} /></FormField>
        <FormField label="Label" htmlFor="label" required><FormInput id="label" name="label" required defaultValue={item?.label} /></FormField>
        <FormField label="Suffix" htmlFor="suffix"><FormInput id="suffix" name="suffix" defaultValue={item?.suffix} /></FormField>
      </AdminForm>
    </div>
  );
}
