"use client";

import * as React from "react";
import Link from "next/link";
import { PageHeader } from "@/components/admin/page-header";
import { DataTable, type Column, type Action } from "@/components/admin/data-table";
import { ConfirmDialog } from "@/components/admin/confirm-dialog";
import { EmptyState } from "@/components/admin/empty-state";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useAdminList, useAdminDelete } from "@/hooks/use-admin";
import type { Statistic } from "@/types";

const columns: Column<Statistic>[] = [
  { key: "value", label: "Value" },
  { key: "label", label: "Label" },
];

export default function AdminStatisticsPage() {
  const { data, isLoading } = useAdminList<Statistic>("/statistics");
  const deleteMutation = useAdminDelete("/statistics");
  const [deleteId, setDeleteId] = React.useState<string | null>(null);

  const actions: Action<Statistic>[] = [
    { label: "Edit", href: (row) => `/admin/statistics/${row.id}` },
    { label: "Delete", variant: "destructive", onClick: (row) => setDeleteId(row.id) },
  ];

  if (isLoading) return <div className="space-y-6"><Skeleton className="h-10 w-48" /><Skeleton className="h-4 w-72" /><div className="space-y-3"><Skeleton className="h-12 w-full rounded-xl" />{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-16 w-full rounded-xl" />)}</div></div>;

  return (
    <div className="space-y-6">
      <PageHeader title="Statistics" description="Manage statistics displayed on the site." breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "Statistics", href: "/admin/statistics" }]} action={{ label: "Add Statistic", href: "/admin/statistics/new" }} />
      {data && data.length > 0 ? (
        <DataTable columns={columns} data={data} actions={actions} searchKey="label" searchPlaceholder="Search statistics..." />
      ) : (
        <EmptyState title="No statistics" description="Add your first statistic." action={<Button asChild><Link href="/admin/statistics/new">Add Statistic</Link></Button>} />
      )}
      <ConfirmDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)} title="Delete Statistic" description="This action cannot be undone." loading={deleteMutation.isPending} onConfirm={async () => { if (deleteId) { await deleteMutation.mutateAsync(deleteId); setDeleteId(null); } }} />
    </div>
  );
}
