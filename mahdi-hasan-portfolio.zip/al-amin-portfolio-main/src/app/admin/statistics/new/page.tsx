"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { PageHeader } from "@/components/admin/page-header";
import { AdminForm } from "@/components/admin/admin-form";
import { FormField, FormInput } from "@/components/admin/form-field";
import { useAdminCreate } from "@/hooks/use-admin";
import type { Statistic } from "@/types";

export default function AdminStatisticsNewPage() {
  const router = useRouter();
  const createMutation = useAdminCreate<Statistic>("/statistics");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget as HTMLFormElement);
    await createMutation.mutateAsync({
      value: fd.get("value") as string,
      label: fd.get("label") as string,
      suffix: fd.get("suffix") as string,
    });
    router.push("/admin/statistics");
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Add Statistic" breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "Statistics", href: "/admin/statistics" }, { label: "New", href: "/admin/statistics/new" }]} />
      <AdminForm title="Statistic Details" onSubmit={handleSubmit} loading={createMutation.isPending} backHref="/admin/statistics">
        <FormField label="Value" htmlFor="value" required description="The number/value displayed, e.g. 50M+, 3.8x"><FormInput id="value" name="value" required placeholder="e.g. 50M+" /></FormField>
        <FormField label="Label" htmlFor="label" required description="Description of what this statistic represents"><FormInput id="label" name="label" required placeholder="e.g. Revenue Generated" /></FormField>
        <FormField label="Suffix" htmlFor="suffix" description="Optional suffix appended to the value"><FormInput id="suffix" name="suffix" placeholder="e.g. +" /></FormField>
      </AdminForm>
    </div>
  );
}
