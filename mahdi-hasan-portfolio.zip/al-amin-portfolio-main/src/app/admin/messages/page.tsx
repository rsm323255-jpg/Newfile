"use client";

import * as React from "react";
import { Mail, MailOpen, Trash2, RefreshCw } from "lucide-react";
import { PageHeader } from "@/components/admin/page-header";
import { StatusBadge } from "@/components/admin/status-badge";
import { EmptyState } from "@/components/admin/empty-state";
import { Skeleton } from "@/components/ui/skeleton";
import { useAdminList, useAdminUpdate, useAdminDelete } from "@/hooks/use-admin";
import type { IMessage } from "@/models/message.model";

function msgId(msg: IMessage) {
  return String(msg._id);
}

export default function AdminMessagesPage() {
  const { data: messages, isLoading, refetch } = useAdminList<IMessage>("/messages");
  const updateMutation = useAdminUpdate<IMessage>("/messages");
  const deleteMutation = useAdminDelete("/messages");
  const [selected, setSelected] = React.useState<Set<string>>(new Set());
  const [expandedId, setExpandedId] = React.useState<string | null>(null);

  function toggleRead(id: string) {
    const msg = messages?.find((m) => msgId(m) === id);
    if (!msg) return;
    updateMutation.mutate({ id, data: { read: !msg.read } });
  }

  function toggleSelect(id: string) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  function selectAll() {
    if (!messages) return;
    if (selected.size === messages.length) {
      setSelected(new Set());
    } else {
      setSelected(new Set(messages.map((m) => msgId(m))));
    }
  }

  function deleteSelected() {
    if (selected.size === 0) return;
    if (!confirm(`Delete ${selected.size} message(s)?`)) return;
    deleteMutation.mutate(selected.size === messages?.length ? "all" : "", {
      onSuccess: () => {
        setSelected(new Set());
        refetch();
      },
    });
  }

  function deleteOne(id: string) {
    if (!confirm("Delete this message?")) return;
    deleteMutation.mutate(id);
  }

  const formatDate = (date: string | Date) => {
    const d = new Date(date);
    return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Messages"
        description="View contact form submissions."
        breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "Messages", href: "/admin/messages" }]}
      />

      {isLoading ? (
        <div className="space-y-3">
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-24 w-full rounded-xl" />
          ))}
        </div>
      ) : messages && messages.length > 0 ? (
        <>
          {/* Toolbar */}
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <button
                onClick={selectAll}
                className="text-xs font-medium text-muted-foreground hover:text-foreground cursor-pointer"
              >
                {selected.size === messages.length ? "Deselect all" : "Select all"}
              </button>
              {selected.size > 0 && (
                <button
                  onClick={deleteSelected}
                  className="flex items-center gap-1.5 text-xs font-medium text-destructive hover:text-destructive/80 cursor-pointer"
                >
                  <Trash2 className="size-3.5" />
                  Delete ({selected.size})
                </button>
              )}
            </div>
            <button
              onClick={() => refetch()}
              className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground hover:text-foreground cursor-pointer"
            >
              <RefreshCw className="size-3.5" />
              Refresh
            </button>
          </div>

          {/* Message List */}
          <div className="space-y-2">
            {messages.map((msg) => {
              const id = msgId(msg);
              return (
                <div
                  key={id}
                  className={`rounded-xl border border-border p-4 transition-colors ${
                    msg.read ? "bg-background" : "bg-primary/5 border-primary/20"
                  } ${selected.has(id) ? "ring-1 ring-primary/30" : ""}`}
                >
                  <div className="flex items-start gap-3">
                    {/* Checkbox */}
                    <input
                      type="checkbox"
                      checked={selected.has(id)}
                      onChange={() => toggleSelect(id)}
                      className="mt-1 size-4 shrink-0 rounded border-border accent-primary cursor-pointer"
                    />

                    {/* Read Toggle */}
                    <button
                      onClick={() => toggleRead(id)}
                      className="mt-0.5 shrink-0 cursor-pointer text-muted-foreground hover:text-foreground"
                    >
                      {msg.read ? <MailOpen className="size-4" /> : <Mail className="size-4" />}
                    </button>

                    {/* Content */}
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="text-sm font-semibold text-foreground">
                          {msg.subject}
                        </h4>
                        {!msg.read && <StatusBadge variant="info">New</StatusBadge>}
                      </div>
                      <div className="mt-1 flex items-center gap-2 text-xs text-muted-foreground flex-wrap">
                        <span className="font-medium">{msg.name}</span>
                        <span>&middot;</span>
                        <span>{msg.email}</span>
                        <span>&middot;</span>
                        <span>{formatDate(msg.createdAt)}</span>
                      </div>

                      {/* Expandable Message */}
                      {expandedId === id ? (
                        <div className="mt-3">
                          <p className="text-sm text-muted-foreground whitespace-pre-wrap leading-relaxed">
                            {msg.message}
                          </p>
                          <button
                            onClick={() => setExpandedId(null)}
                            className="mt-2 text-xs text-primary hover:text-primary/80 cursor-pointer"
                          >
                            Show less
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => {
                            setExpandedId(id);
                            if (!msg.read) toggleRead(id);
                          }}
                          className="mt-2 line-clamp-2 text-sm text-muted-foreground text-left cursor-pointer hover:text-foreground"
                        >
                          {msg.message}
                        </button>
                      )}
                    </div>

                    {/* Delete */}
                    <button
                      onClick={() => deleteOne(id)}
                      className="shrink-0 cursor-pointer text-muted-foreground hover:text-destructive p-1"
                    >
                      <Trash2 className="size-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </>
      ) : (
        <EmptyState
          title="No messages"
          description="Contact form submissions will appear here."
          icon={<Mail className="size-6" />}
        />
      )}
    </div>
  );
}
