"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { PageHeader } from "@/components/admin/page-header";
import { AdminForm } from "@/components/admin/admin-form";
import { FormField, FormInput, FormTextarea } from "@/components/admin/form-field";
import { useAdminCreate } from "@/hooks/use-admin";
import type { FAQItem } from "@/types";

export default function AdminFAQNewPage() {
  const router = useRouter();
  const createMutation = useAdminCreate<FAQItem>("/faq");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget as HTMLFormElement);
    await createMutation.mutateAsync({ question: fd.get("question") as string, answer: fd.get("answer") as string });
    router.push("/admin/faq");
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Add FAQ" breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "FAQ", href: "/admin/faq" }, { label: "New", href: "/admin/faq/new" }]} />
      <AdminForm title="FAQ Details" onSubmit={handleSubmit} loading={createMutation.isPending} backHref="/admin/faq">
        <FormField label="Question" htmlFor="question" required><FormInput id="question" name="question" required placeholder="What do people ask?" /></FormField>
        <FormField label="Answer" htmlFor="answer" required><FormTextarea id="answer" name="answer" required placeholder="Provide a clear answer..." /></FormField>
      </AdminForm>
    </div>
  );
}
