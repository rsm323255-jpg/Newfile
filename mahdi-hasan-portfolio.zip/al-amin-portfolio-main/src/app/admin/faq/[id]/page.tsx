"use client";

import * as React from "react";
import { useRouter, useParams } from "next/navigation";
import { Skeleton } from "@/components/ui/skeleton";
import { PageHeader } from "@/components/admin/page-header";
import { AdminForm } from "@/components/admin/admin-form";
import { FormField, FormInput, FormTextarea } from "@/components/admin/form-field";
import { useAdminDetail, useAdminUpdate } from "@/hooks/use-admin";
import type { FAQItem } from "@/types";

export default function AdminFAQEditPage() {
  const router = useRouter();
  const params = useParams();
  const id = params.id as string;
  const { data: item, isLoading } = useAdminDetail<FAQItem>("/faq", id);
  const updateMutation = useAdminUpdate<FAQItem>("/faq");

  if (isLoading) return <div className="space-y-6"><Skeleton className="h-10 w-48" /><Skeleton className="h-4 w-72" /><div className="space-y-4"><Skeleton className="h-12 w-full rounded-xl" /><Skeleton className="h-12 w-full rounded-xl" /><Skeleton className="h-24 w-full rounded-xl" /></div></div>;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget as HTMLFormElement);
    await updateMutation.mutateAsync({ id, data: { question: fd.get("question") as string, answer: fd.get("answer") as string } });
    router.push("/admin/faq");
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Edit FAQ" breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "FAQ", href: "/admin/faq" }, { label: "Edit", href: `/admin/faq/${id}` }]} />
      <AdminForm title="FAQ Details" onSubmit={handleSubmit} loading={updateMutation.isPending} backHref="/admin/faq" submitLabel="Update">
        <FormField label="Question" htmlFor="question" required><FormInput id="question" name="question" required defaultValue={item?.question} /></FormField>
        <FormField label="Answer" htmlFor="answer" required><FormTextarea id="answer" name="answer" required defaultValue={item?.answer} /></FormField>
      </AdminForm>
    </div>
  );
}
