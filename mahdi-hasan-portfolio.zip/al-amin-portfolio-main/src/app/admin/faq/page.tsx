"use client";

import * as React from "react";
import Link from "next/link";
import { PageHeader } from "@/components/admin/page-header";
import { DataTable, type Column, type Action } from "@/components/admin/data-table";
import { ConfirmDialog } from "@/components/admin/confirm-dialog";
import { EmptyState } from "@/components/admin/empty-state";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useAdminList, useAdminDelete } from "@/hooks/use-admin";
import type { FAQItem } from "@/types";

const columns: Column<FAQItem>[] = [
  { key: "question", label: "Question" },
  { key: "answer", label: "Answer", render: (v) => <span className="line-clamp-1">{String(v)}</span> },
];

export default function AdminFAQPage() {
  const { data, isLoading } = useAdminList<FAQItem>("/faq");
  const deleteMutation = useAdminDelete("/faq");
  const [deleteId, setDeleteId] = React.useState<string | null>(null);

  const actions: Action<FAQItem>[] = [
    { label: "Edit", href: (row) => `/admin/faq/${row.id}` },
    { label: "Delete", variant: "destructive", onClick: (row) => setDeleteId(row.id) },
  ];

  if (isLoading) return <div className="space-y-6"><Skeleton className="h-10 w-48" /><Skeleton className="h-4 w-72" /><div className="space-y-3"><Skeleton className="h-12 w-full rounded-xl" />{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-16 w-full rounded-xl" />)}</div></div>;

  return (
    <div className="space-y-6">
      <PageHeader title="FAQ" description="Manage frequently asked questions." breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "FAQ", href: "/admin/faq" }]} action={{ label: "Add FAQ", href: "/admin/faq/new" }} />
      {data && data.length > 0 ? (
        <DataTable columns={columns} data={data} actions={actions} searchKey="question" searchPlaceholder="Search FAQ..." />
      ) : (
        <EmptyState title="No FAQ items" description="Add your first FAQ." action={<Button asChild><Link href="/admin/faq/new">Add FAQ</Link></Button>} />
      )}
      <ConfirmDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)} title="Delete FAQ" description="This action cannot be undone." loading={deleteMutation.isPending} onConfirm={async () => { if (deleteId) { await deleteMutation.mutateAsync(deleteId); setDeleteId(null); } }} />
    </div>
  );
}
