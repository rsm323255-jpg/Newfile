"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { PageHeader } from "@/components/admin/page-header";
import { AdminForm } from "@/components/admin/admin-form";
import { FormField, FormInput, FormTextarea } from "@/components/admin/form-field";
import { ImageUpload } from "@/components/admin/image-upload";
import { useAdminCreate } from "@/hooks/use-admin";
import type { Testimonial } from "@/types";

export default function AdminTestimonialsNewPage() {
  const router = useRouter();
  const createMutation = useAdminCreate<Testimonial>("/testimonials");
  const [avatar, setAvatar] = React.useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget as HTMLFormElement);
    await createMutation.mutateAsync({
      name: fd.get("name") as string,
      role: fd.get("role") as string,
      company: fd.get("company") as string,
      content: fd.get("content") as string,
      avatar,
      rating: Number(fd.get("rating")) || 5,
    });
    router.push("/admin/testimonials");
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Add Testimonial" breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "Testimonials", href: "/admin/testimonials" }, { label: "New", href: "/admin/testimonials/new" }]} />
      <AdminForm title="Testimonial Details" onSubmit={handleSubmit} loading={createMutation.isPending} backHref="/admin/testimonials">
        <FormField label="Name" htmlFor="name" required><FormInput id="name" name="name" required placeholder="Client name" /></FormField>
        <FormField label="Role" htmlFor="role" required><FormInput id="role" name="role" required placeholder="e.g. CEO" /></FormField>
        <FormField label="Company" htmlFor="company" required><FormInput id="company" name="company" required placeholder="Company name" /></FormField>
        <FormField label="Avatar" htmlFor="avatar">
          <input type="hidden" name="avatar" value={avatar} />
          <ImageUpload value={avatar} onChange={setAvatar} folder="avatars" />
        </FormField>
        <FormField label="Rating" htmlFor="rating"><FormInput id="rating" name="rating" type="number" min="1" max="5" defaultValue="5" /></FormField>
        <FormField label="Content" htmlFor="content" required><FormTextarea id="content" name="content" required placeholder="What did they say?" /></FormField>
      </AdminForm>
    </div>
  );
}
