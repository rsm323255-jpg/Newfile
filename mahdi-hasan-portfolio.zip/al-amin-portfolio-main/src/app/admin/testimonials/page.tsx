"use client";

import * as React from "react";
import Link from "next/link";
import { PageHeader } from "@/components/admin/page-header";
import { DataTable, type Column, type Action } from "@/components/admin/data-table";
import { ConfirmDialog } from "@/components/admin/confirm-dialog";
import { StatusBadge } from "@/components/admin/status-badge";
import { EmptyState } from "@/components/admin/empty-state";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useAdminList, useAdminDelete } from "@/hooks/use-admin";
import type { Testimonial } from "@/types";

const columns: Column<Testimonial>[] = [
  { key: "name", label: "Name" },
  { key: "company", label: "Company", hideOnMobile: true },
  { key: "role", label: "Role", hideOnMobile: true },
  { key: "rating", label: "Rating", hideOnMobile: true, render: (v) => <StatusBadge variant="warning">{"★".repeat(Number(v))}</StatusBadge> },
  { key: "content", label: "Content", hideOnMobile: true, render: (v) => <span className="line-clamp-1">{String(v)}</span> },
];

export default function AdminTestimonialsPage() {
  const { data, isLoading } = useAdminList<Testimonial>("/testimonials");
  const deleteMutation = useAdminDelete("/testimonials");
  const [deleteId, setDeleteId] = React.useState<string | null>(null);

  const actions: Action<Testimonial>[] = [
    { label: "Edit", href: (row) => `/admin/testimonials/${row.id}` },
    { label: "Delete", variant: "destructive", onClick: (row) => setDeleteId(row.id) },
  ];

  if (isLoading) return <div className="space-y-6"><Skeleton className="h-10 w-48" /><Skeleton className="h-4 w-72" /><div className="space-y-3"><Skeleton className="h-12 w-full rounded-xl" />{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-16 w-full rounded-xl" />)}</div></div>;

  return (
    <div className="space-y-6">
      <PageHeader title="Testimonials" description="Manage client testimonials." breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "Testimonials", href: "/admin/testimonials" }]} action={{ label: "Add Testimonial", href: "/admin/testimonials/new" }} />
      {data && data.length > 0 ? (
        <DataTable columns={columns} data={data} actions={actions} searchKey="name" searchPlaceholder="Search testimonials..." />
      ) : (
        <EmptyState title="No testimonials" description="Add your first testimonial." action={<Button asChild><Link href="/admin/testimonials/new">Add Testimonial</Link></Button>} />
      )}
      <ConfirmDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)} title="Delete Testimonial" description="This action cannot be undone." loading={deleteMutation.isPending} onConfirm={async () => { if (deleteId) { await deleteMutation.mutateAsync(deleteId); setDeleteId(null); } }} />
    </div>
  );
}
