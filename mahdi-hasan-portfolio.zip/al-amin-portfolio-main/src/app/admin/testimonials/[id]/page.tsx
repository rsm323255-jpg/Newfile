"use client";

import * as React from "react";
import { useRouter, useParams } from "next/navigation";
import { Skeleton } from "@/components/ui/skeleton";
import { PageHeader } from "@/components/admin/page-header";
import { AdminForm } from "@/components/admin/admin-form";
import { FormField, FormInput, FormTextarea } from "@/components/admin/form-field";
import { ImageUpload } from "@/components/admin/image-upload";
import { useAdminDetail, useAdminUpdate } from "@/hooks/use-admin";
import type { Testimonial } from "@/types";

export default function AdminTestimonialsEditPage() {
  const router = useRouter();
  const params = useParams();
  const id = params.id as string;
  const { data: item, isLoading } = useAdminDetail<Testimonial>("/testimonials", id);
  const updateMutation = useAdminUpdate<Testimonial>("/testimonials");
  const [avatar, setAvatar] = React.useState("");

  React.useEffect(() => {
    if (item) setAvatar(item.avatar);
  }, [item]);

  if (isLoading) return <div className="space-y-6"><Skeleton className="h-10 w-48" /><Skeleton className="h-4 w-72" /><div className="space-y-4"><Skeleton className="h-12 w-full rounded-xl" /><Skeleton className="h-12 w-full rounded-xl" /><Skeleton className="h-24 w-full rounded-xl" /></div></div>;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget as HTMLFormElement);
    await updateMutation.mutateAsync({
      id,
      data: {
        name: fd.get("name") as string,
        role: fd.get("role") as string,
        company: fd.get("company") as string,
        content: fd.get("content") as string,
        avatar,
        rating: Number(fd.get("rating")) || 5,
      },
    });
    router.push("/admin/testimonials");
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Edit Testimonial" breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "Testimonials", href: "/admin/testimonials" }, { label: "Edit", href: `/admin/testimonials/${id}` }]} />
      <AdminForm title="Testimonial Details" onSubmit={handleSubmit} loading={updateMutation.isPending} backHref="/admin/testimonials" submitLabel="Update">
        <FormField label="Name" htmlFor="name" required><FormInput id="name" name="name" required defaultValue={item?.name} /></FormField>
        <FormField label="Role" htmlFor="role" required><FormInput id="role" name="role" required defaultValue={item?.role} /></FormField>
        <FormField label="Company" htmlFor="company" required><FormInput id="company" name="company" required defaultValue={item?.company} /></FormField>
        <FormField label="Avatar" htmlFor="avatar">
          <input type="hidden" name="avatar" value={avatar} />
          <ImageUpload value={avatar} onChange={setAvatar} folder="avatars" />
        </FormField>
        <FormField label="Rating" htmlFor="rating"><FormInput id="rating" name="rating" type="number" min="1" max="5" defaultValue={item?.rating} /></FormField>
        <FormField label="Content" htmlFor="content" required><FormTextarea id="content" name="content" required defaultValue={item?.content} /></FormField>
      </AdminForm>
    </div>
  );
}
