"use client";

import * as React from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  LayoutDashboard,
  FileText,
  Image,
  MessageSquare,
  Star,
  Users,
  Briefcase,
  HelpCircle,
  Target,
  Layers,
  Globe,
  Settings,
  LogOut,
  ChevronLeft,
  Menu,
  X,
  Shield,
  TrendingUp,
} from "lucide-react";
import { ThemeToggle } from "@/components/shared/theme-toggle";
import { useAppDispatch, useAppSelector } from "@/hooks/use-redux";
import { useLogoutMutation, useGetMeQuery } from "@/store/api/auth-api";
import { clearAuth, setCredentials, initializeAuth } from "@/store/slices/auth-slice";
import { cn } from "@/lib/utils";

interface SidebarLink {
  href: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  section?: string;
  minRole?: "admin" | "editor" | "viewer";
}

const ROLE_HIERARCHY: Record<string, number> = {
  admin: 3,
  editor: 2,
  viewer: 1,
};

const sidebarLinks: SidebarLink[] = [
  { href: "/admin", label: "Dashboard", icon: LayoutDashboard, section: "overview" },
  { href: "/admin/portfolio", label: "Portfolio", icon: Briefcase, section: "content" },
  { href: "/admin/case-studies", label: "Case Studies", icon: FileText, section: "content" },
  { href: "/admin/testimonials", label: "Testimonials", icon: Star, section: "content" },
  { href: "/admin/skills", label: "Skills", icon: Target, section: "content" },
  { href: "/admin/team", label: "Team", icon: Users, section: "content" },
  { href: "/admin/faq", label: "FAQ", icon: HelpCircle, section: "content" },
  { href: "/admin/clients", label: "Clients", icon: Layers, section: "content" },
  { href: "/admin/process", label: "Process", icon: Settings, section: "content" },
  { href: "/admin/statistics", label: "Statistics", icon: TrendingUp, section: "content" },
  { href: "/admin/why-choose-us", label: "Why Choose Us", icon: Target, section: "content" },
  { href: "/admin/content", label: "Site Content", icon: Globe, section: "management", minRole: "editor" },
  { href: "/admin/messages", label: "Messages", icon: MessageSquare, section: "management" },
  { href: "/admin/media", label: "Media", icon: Image, section: "management", minRole: "editor" },
];

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const router = useRouter();
  const dispatch = useAppDispatch();
  const [sidebarOpen, setSidebarOpen] = React.useState(false);
  const [collapsed, setCollapsed] = React.useState(false);

  const { user, isAuthenticated, isInitialized } = useAppSelector((s) => s.auth);
  const [logout] = useLogoutMutation();
  const isLoginPage = pathname === "/admin/login";
  const { data: meData } = useGetMeQuery(undefined, {
    skip: isAuthenticated || !isInitialized || isLoginPage,
    pollingInterval: 10 * 60 * 1000, // 10 minutes (token expires in 15)
  });

  // Initialize auth state from cookies on mount
  React.useEffect(() => {
    if (!isInitialized) {
      dispatch(initializeAuth());
    }
  }, [isInitialized, dispatch]);

  // Sync /me response with Redux
  React.useEffect(() => {
    if (meData?.success && meData.data) {
      dispatch(
        setCredentials({
          user: meData.data,
          accessToken: "", // handled by cookies
          refreshToken: "",
        })
      );
    }
  }, [meData, dispatch]);

  const isActive = (href: string) =>
    href === "/admin" ? pathname === "/admin" : pathname.startsWith(href);

  const hasPermission = (minRole?: "admin" | "editor" | "viewer") => {
    if (!minRole || !user) return true;
    return ROLE_HIERARCHY[user.role] >= ROLE_HIERARCHY[minRole];
  };

  React.useEffect(() => {
    setSidebarOpen(false);
  }, [pathname]);

  React.useEffect(() => {
    document.body.style.overflow = sidebarOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [sidebarOpen]);

  const handleLogout = async () => {
    try {
      await logout().unwrap();
    } finally {
      dispatch(clearAuth());
      router.push("/admin/login");
    }
  };

  if (pathname === "/admin/login") {
    return <>{children}</>;
  }

  const visibleLinks = sidebarLinks.filter((l) => hasPermission(l.minRole));

  return (
    <div className="flex h-dvh overflow-hidden bg-background">
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/50 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-50 flex flex-col border-r border-border bg-card transition-all duration-300",
          collapsed ? "w-[68px]" : "w-64",
          sidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        )}
      >
        <div className="flex h-16 items-center justify-between border-b border-border px-4">
          {!collapsed && (
            <Link href="/admin" className="flex items-center gap-2.5">
              <span className="flex size-9 shrink-0 items-center justify-center rounded-xl bg-primary text-sm font-bold text-white">
                MH
              </span>
              <span className="font-heading text-sm font-bold tracking-tight text-foreground">
                Admin Panel
              </span>
            </Link>
          )}
          {collapsed && (
            <span className="mx-auto flex size-9 shrink-0 items-center justify-center rounded-xl bg-primary text-sm font-bold text-white">
              MH
            </span>
          )}
          <button
            onClick={() => setSidebarOpen(false)}
            className="flex size-8 cursor-pointer items-center justify-center rounded-lg text-muted-foreground hover:bg-muted lg:hidden"
          >
            <X className="size-4" />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto p-3">
          {(
            [
              { section: "Overview", filter: "overview" },
              { section: "Content", filter: "content" },
              { section: "Management", filter: "management" },
            ] as const
          ).map(({ section, filter }) => {
            const links = visibleLinks.filter((l) => l.section === filter);
            if (links.length === 0) return null;
            return (
              <div key={filter} className="mb-2">
                {!collapsed && (
                  <div className="mb-1 px-3 pt-3 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground/70">
                    {section}
                  </div>
                )}
                <div className="space-y-0.5">
                  {links.map((link) => {
                    const Icon = link.icon;
                    return (
                      <Link
                        key={link.href}
                        href={link.href}
                        className={cn(
                          "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors",
                          isActive(link.href)
                            ? "bg-primary/10 text-primary"
                            : "text-muted-foreground hover:bg-muted hover:text-foreground"
                        )}
                        title={collapsed ? link.label : undefined}
                      >
                        <Icon className="size-4 shrink-0" />
                        {!collapsed && <span>{link.label}</span>}
                      </Link>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </nav>

        <div className="border-t border-border p-3 space-y-1">
          {user && (
            <div
              className={cn(
                "flex items-center gap-3 rounded-xl px-3 py-2 text-xs",
                collapsed ? "justify-center" : ""
              )}
            >
              <Shield className="size-3.5 shrink-0 text-muted-foreground" />
              {!collapsed && (
                <div className="flex flex-col">
                  <span className="font-medium text-foreground">{user.name}</span>
                  <span className="text-muted-foreground capitalize">{user.role}</span>
                </div>
              )}
            </div>
          )}
          <button
            onClick={handleLogout}
            className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive"
            title={collapsed ? "Logout" : undefined}
          >
            <LogOut className="size-4 shrink-0" />
            {!collapsed && <span>Logout</span>}
          </button>
        </div>
      </aside>

      <div
        className={cn(
          "flex flex-1 flex-col transition-all duration-300",
          collapsed ? "lg:ml-[68px]" : "lg:ml-64"
        )}
      >
        <header className="sticky top-0 z-30 flex h-16 items-center gap-4 border-b border-border bg-background/80 px-4 backdrop-blur-md sm:px-6">
          <button
            onClick={() => setSidebarOpen(true)}
            className="flex size-9 cursor-pointer items-center justify-center rounded-xl border border-border bg-background text-foreground lg:hidden"
          >
            <Menu className="size-5" />
          </button>
          <button
            onClick={() => setCollapsed((c) => !c)}
            className="hidden cursor-pointer items-center justify-center rounded-xl border border-border bg-background p-2 text-foreground hover:bg-muted lg:flex"
          >
            <ChevronLeft
              className={cn(
                "size-4 transition-transform duration-300",
                collapsed && "rotate-180"
              )}
            />
          </button>
          <div className="flex-1" />
          <ThemeToggle />
        </header>

        <main className="flex-1 min-w-0 overflow-y-auto overflow-x-hidden p-4 sm:p-6">{children}</main>
      </div>
    </div>
  );
}
