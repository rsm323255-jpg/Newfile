"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { PageHeader } from "@/components/admin/page-header";
import { AdminForm } from "@/components/admin/admin-form";
import { FormField, FormInput, FormTextarea } from "@/components/admin/form-field";
import { useAdminCreate } from "@/hooks/use-admin";
import type { WhyChooseUsFeature } from "@/types";

export default function AdminWhyChooseUsNewPage() {
  const router = useRouter();
  const createMutation = useAdminCreate<WhyChooseUsFeature>("/why-choose-us");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget as HTMLFormElement);
    await createMutation.mutateAsync({
      title: fd.get("title") as string,
      description: fd.get("description") as string,
      icon: fd.get("icon") as string,
    });
    router.push("/admin/why-choose-us");
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Add Feature" breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "Why Choose Us", href: "/admin/why-choose-us" }, { label: "New", href: "/admin/why-choose-us/new" }]} />
      <AdminForm title="Feature Details" onSubmit={handleSubmit} loading={createMutation.isPending} backHref="/admin/why-choose-us">
        <FormField label="Title" htmlFor="title" required><FormInput id="title" name="title" required placeholder="e.g. Data-Driven Strategy" /></FormField>
        <FormField label="Icon (Lucide name)" htmlFor="icon" description="Use a Lucide icon name, e.g. BarChart3, Eye, Trophy"><FormInput id="icon" name="icon" placeholder="e.g. BarChart3" /></FormField>
        <FormField label="Description" htmlFor="description" required><FormTextarea id="description" name="description" required placeholder="Describe this feature..." /></FormField>
      </AdminForm>
    </div>
  );
}
