"use client";

import * as React from "react";
import { useRouter, useParams } from "next/navigation";
import { PageHeader } from "@/components/admin/page-header";
import { AdminForm } from "@/components/admin/admin-form";
import { FormField, FormInput, FormTextarea } from "@/components/admin/form-field";
import { Skeleton } from "@/components/ui/skeleton";
import { useAdminDetail, useAdminUpdate } from "@/hooks/use-admin";
import type { WhyChooseUsFeature } from "@/types";

export default function AdminWhyChooseUsEditPage() {
  const router = useRouter();
  const params = useParams();
  const id = params.id as string;
  const { data: item, isLoading } = useAdminDetail<WhyChooseUsFeature>("/why-choose-us", id);
  const updateMutation = useAdminUpdate<WhyChooseUsFeature>("/why-choose-us");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget as HTMLFormElement);
    await updateMutation.mutateAsync({
      id,
      data: {
        title: fd.get("title") as string,
        description: fd.get("description") as string,
        icon: fd.get("icon") as string,
      },
    });
    router.push("/admin/why-choose-us");
  }

  if (isLoading) return <div className="space-y-6"><Skeleton className="h-10 w-48" /><Skeleton className="h-4 w-72" /><div className="space-y-4"><Skeleton className="h-12 w-full rounded-xl" /><Skeleton className="h-12 w-full rounded-xl" /><Skeleton className="h-12 w-full rounded-xl" /></div></div>;

  return (
    <div className="space-y-6">
      <PageHeader title="Edit Feature" breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "Why Choose Us", href: "/admin/why-choose-us" }, { label: "Edit", href: `/admin/why-choose-us/${id}` }]} />
      <AdminForm title="Feature Details" onSubmit={handleSubmit} loading={updateMutation.isPending} backHref="/admin/why-choose-us" submitLabel="Update">
        <FormField label="Title" htmlFor="title" required><FormInput id="title" name="title" required defaultValue={item?.title} /></FormField>
        <FormField label="Icon (Lucide name)" htmlFor="icon"><FormInput id="icon" name="icon" defaultValue={item?.icon} /></FormField>
        <FormField label="Description" htmlFor="description" required><FormTextarea id="description" name="description" required defaultValue={item?.description} /></FormField>
      </AdminForm>
    </div>
  );
}
