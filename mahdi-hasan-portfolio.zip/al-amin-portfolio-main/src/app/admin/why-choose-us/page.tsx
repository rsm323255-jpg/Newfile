"use client";

import * as React from "react";
import Link from "next/link";
import { PageHeader } from "@/components/admin/page-header";
import { DataTable, type Column, type Action } from "@/components/admin/data-table";
import { ConfirmDialog } from "@/components/admin/confirm-dialog";
import { EmptyState } from "@/components/admin/empty-state";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useAdminList, useAdminDelete } from "@/hooks/use-admin";
import type { WhyChooseUsFeature } from "@/types";

const columns: Column<WhyChooseUsFeature>[] = [
  { key: "title", label: "Title" },
  { key: "icon", label: "Icon" },
  { key: "description", label: "Description", render: (v) => <span className="line-clamp-1">{String(v)}</span> },
];

export default function AdminWhyChooseUsPage() {
  const { data, isLoading } = useAdminList<WhyChooseUsFeature>("/why-choose-us");
  const deleteMutation = useAdminDelete("/why-choose-us");
  const [deleteId, setDeleteId] = React.useState<string | null>(null);

  const actions: Action<WhyChooseUsFeature>[] = [
    { label: "Edit", href: (row) => `/admin/why-choose-us/${row.id}` },
    { label: "Delete", variant: "destructive", onClick: (row) => setDeleteId(row.id) },
  ];

  if (isLoading) return <div className="space-y-6"><Skeleton className="h-10 w-48" /><Skeleton className="h-4 w-72" /><div className="space-y-3"><Skeleton className="h-12 w-full rounded-xl" />{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-16 w-full rounded-xl" />)}</div></div>;

  return (
    <div className="space-y-6">
      <PageHeader title="Why Choose Us" description="Manage features displayed in the Why Choose Us section." breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "Why Choose Us", href: "/admin/why-choose-us" }]} action={{ label: "Add Feature", href: "/admin/why-choose-us/new" }} />
      {data && data.length > 0 ? (
        <DataTable columns={columns} data={data} actions={actions} searchKey="title" searchPlaceholder="Search features..." />
      ) : (
        <EmptyState title="No features" description="Add your first feature." action={<Button asChild><Link href="/admin/why-choose-us/new">Add Feature</Link></Button>} />
      )}
      <ConfirmDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)} title="Delete Feature" description="This action cannot be undone." loading={deleteMutation.isPending} onConfirm={async () => { if (deleteId) { await deleteMutation.mutateAsync(deleteId); setDeleteId(null); } }} />
    </div>
  );
}
