"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { Plus, Trash2 } from "lucide-react";
import { PageHeader } from "@/components/admin/page-header";
import { AdminForm } from "@/components/admin/admin-form";
import {
  FormField,
  FormInput,
  FormTextarea,
} from "@/components/admin/form-field";
import { ImageUpload } from "@/components/admin/image-upload";
import { Button } from "@/components/ui/button";
import { useAdminCreate } from "@/hooks/use-admin";
import type { PortfolioItem } from "@/types";

export default function AdminPortfolioNewPage() {
  const router = useRouter();
  const createMutation = useAdminCreate<PortfolioItem>("/portfolio");
  const [tags, setTags] = React.useState("");
  const [image, setImage] = React.useState("");
  const [results, setResults] = React.useState<{ metric: string; value: string }[]>([]);

  function addResult() {
    setResults([...results, { metric: "", value: "" }]);
  }

  function removeResult(index: number) {
    setResults(results.filter((_, i) => i !== index));
  }

  function updateResult(index: number, field: "metric" | "value", val: string) {
    const updated = [...results];
    updated[index][field] = val;
    setResults(updated);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const form = e.currentTarget as HTMLFormElement;
    const fd = new FormData(form);
    await createMutation.mutateAsync({
      title: fd.get("title") as string,
      slug: fd.get("slug") as string || undefined,
      category: fd.get("category") as string,
      image,
      description: fd.get("description") as string,
      tags: tags.split(",").map((t) => t.trim()).filter(Boolean),
      results: results.filter((r) => r.metric && r.value),
    });
    router.push("/admin/portfolio");
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Add Portfolio Item"
        breadcrumbs={[
          { label: "Admin", href: "/admin" },
          { label: "Portfolio", href: "/admin/portfolio" },
          { label: "New", href: "/admin/portfolio/new" },
        ]}
      />
      <AdminForm
        title="Portfolio Details"
        onSubmit={handleSubmit}
        loading={createMutation.isPending}
        backHref="/admin/portfolio"
      >
        <FormField label="Title" htmlFor="title" required>
          <FormInput id="title" name="title" required placeholder="e.g. E-commerce Growth Campaign" />
        </FormField>
        <FormField label="Slug" htmlFor="slug" description="Auto-generated from title if left empty">
          <FormInput id="slug" name="slug" placeholder="e.g. e-commerce-growth-campaign" />
        </FormField>
        <FormField label="Category" htmlFor="category" required>
          <FormInput id="category" name="category" required placeholder="e.g. Meta Ads" />
        </FormField>
        <FormField label="Image" htmlFor="image">
          <input type="hidden" name="image" value={image} />
          <ImageUpload value={image} onChange={setImage} folder="portfolio" />
        </FormField>
        <FormField label="Description" htmlFor="description" required>
          <FormTextarea id="description" name="description" required placeholder="Describe the project..." />
        </FormField>
        <FormField label="Tags" htmlFor="tags" description="Comma-separated list of tags">
          <FormInput id="tags" value={tags} onChange={(e) => setTags(e.target.value)} placeholder="e.g. Meta Ads, E-commerce, ROI" />
        </FormField>

        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-sm font-medium">Results</label>
            <Button type="button" variant="outline" size="sm" onClick={addResult}>
              <Plus className="size-3.5" />
              Add Result
            </Button>
          </div>
          {results.map((result, i) => (
            <div key={i} className="flex flex-col gap-2 sm:flex-row sm:items-center">
              <FormInput
                value={result.metric}
                onChange={(e) => updateResult(i, "metric", e.target.value)}
                placeholder="Metric (e.g. ROAS)"
                className="flex-1 min-w-0"
              />
              <FormInput
                value={result.value}
                onChange={(e) => updateResult(i, "value", e.target.value)}
                placeholder="Value (e.g. 4.2x)"
                className="flex-1 min-w-0"
              />
              <Button type="button" variant="ghost" size="sm" onClick={() => removeResult(i)} className="sm:mt-0 mt-1 self-start">
                <Trash2 className="size-4 text-destructive" />
              </Button>
            </div>
          ))}
        </div>
      </AdminForm>
    </div>
  );
}
