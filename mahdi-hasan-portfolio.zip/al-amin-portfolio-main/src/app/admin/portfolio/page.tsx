"use client";

import * as React from "react";
import Link from "next/link";
import { Loader2 } from "lucide-react";
import { PageHeader } from "@/components/admin/page-header";
import { DataTable, type Column, type Action } from "@/components/admin/data-table";
import { ConfirmDialog } from "@/components/admin/confirm-dialog";
import { StatusBadge } from "@/components/admin/status-badge";
import { EmptyState } from "@/components/admin/empty-state";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useAdminList, useAdminDelete } from "@/hooks/use-admin";
import type { PortfolioItem } from "@/types";

const columns: Column<PortfolioItem>[] = [
  { key: "title", label: "Title" },
  { key: "category", label: "Category", hideOnMobile: true, render: (v) => <StatusBadge variant="info">{String(v)}</StatusBadge> },
  { key: "description", label: "Description", hideOnMobile: true, render: (v) => <span className="line-clamp-1">{String(v)}</span> },
  { key: "tags", label: "Tags", hideOnMobile: true, render: (v) => {
    const tags = v as string[];
    return (
      <div className="flex flex-wrap gap-1">
        {tags.slice(0, 2).map((t) => (
          <StatusBadge key={t} variant="default">{t}</StatusBadge>
        ))}
        {tags.length > 2 && <StatusBadge variant="default">+{tags.length - 2}</StatusBadge>}
      </div>
    );
  }},
];

export default function AdminPortfolioPage() {
  const { data, isLoading } = useAdminList<PortfolioItem>("/portfolio");
  const deleteMutation = useAdminDelete("/portfolio");
  const [deleteId, setDeleteId] = React.useState<string | null>(null);

  const actions: Action<PortfolioItem>[] = [
    { label: "Edit", href: (row) => `/admin/portfolio/${row.id}` },
    { label: "Delete", variant: "destructive", onClick: (row) => setDeleteId(row.id) },
  ];

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-48" />
        <Skeleton className="h-4 w-72" />
        <div className="space-y-3">
          <Skeleton className="h-12 w-full rounded-xl" />
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-16 w-full rounded-xl" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Portfolio"
        description="Manage your portfolio items."
        breadcrumbs={[
          { label: "Admin", href: "/admin" },
          { label: "Portfolio", href: "/admin/portfolio" },
        ]}
        action={{ label: "Add Portfolio", href: "/admin/portfolio/new" }}
      />

      {data && data.length > 0 ? (
        <DataTable
          columns={columns}
          data={data}
          actions={actions}
          searchKey="title"
          searchPlaceholder="Search portfolio..."
        />
      ) : (
        <EmptyState
          title="No portfolio items"
          description="Create your first portfolio item to showcase your work."
          action={
            <Button asChild>
              <Link href="/admin/portfolio/new">Add Portfolio</Link>
            </Button>
          }
        />
      )}

      <ConfirmDialog
        open={!!deleteId}
        onOpenChange={() => setDeleteId(null)}
        title="Delete Portfolio Item"
        description="This action cannot be undone. The item will be permanently removed."
        loading={deleteMutation.isPending}
        onConfirm={async () => {
          if (deleteId) {
            await deleteMutation.mutateAsync(deleteId);
            setDeleteId(null);
          }
        }}
      />
    </div>
  );
}
