"use client";

import * as React from "react";
import { useRouter, useParams } from "next/navigation";
import { Skeleton } from "@/components/ui/skeleton";
import { PageHeader } from "@/components/admin/page-header";
import { AdminForm } from "@/components/admin/admin-form";
import { FormField, FormInput, FormTextarea } from "@/components/admin/form-field";
import { useAdminDetail, useAdminUpdate } from "@/hooks/use-admin";
import type { TeamMember } from "@/types";

export default function AdminTeamEditPage() {
  const router = useRouter();
  const params = useParams();
  const id = params.id as string;
  const { data: item, isLoading } = useAdminDetail<TeamMember>("/team", id);
  const updateMutation = useAdminUpdate<TeamMember>("/team");

  if (isLoading) return <div className="space-y-6"><Skeleton className="h-10 w-48" /><Skeleton className="h-4 w-72" /><div className="space-y-4"><Skeleton className="h-12 w-full rounded-xl" /><Skeleton className="h-12 w-full rounded-xl" /><Skeleton className="h-24 w-full rounded-xl" /></div></div>;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget as HTMLFormElement);
    await updateMutation.mutateAsync({ id, data: { name: fd.get("name") as string, role: fd.get("role") as string, bio: fd.get("bio") as string, avatar: fd.get("avatar") as string, social: { linkedin: fd.get("linkedin") as string || undefined, twitter: fd.get("twitter") as string || undefined, instagram: fd.get("instagram") as string || undefined } } });
    router.push("/admin/team");
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Edit Member" breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "Team", href: "/admin/team" }, { label: "Edit", href: `/admin/team/${id}` }]} />
      <AdminForm title="Member Details" onSubmit={handleSubmit} loading={updateMutation.isPending} backHref="/admin/team" submitLabel="Update">
        <FormField label="Name" htmlFor="name" required><FormInput id="name" name="name" required defaultValue={item?.name} /></FormField>
        <FormField label="Role" htmlFor="role" required><FormInput id="role" name="role" required defaultValue={item?.role} /></FormField>
        <FormField label="Avatar URL" htmlFor="avatar"><FormInput id="avatar" name="avatar" defaultValue={item?.avatar} /></FormField>
        <FormField label="Bio" htmlFor="bio" required><FormTextarea id="bio" name="bio" required defaultValue={item?.bio} /></FormField>
        <FormField label="LinkedIn URL" htmlFor="linkedin"><FormInput id="linkedin" name="linkedin" defaultValue={item?.social.linkedin} /></FormField>
        <FormField label="Twitter URL" htmlFor="twitter"><FormInput id="twitter" name="twitter" defaultValue={item?.social.twitter} /></FormField>
        <FormField label="Instagram URL" htmlFor="instagram"><FormInput id="instagram" name="instagram" defaultValue={item?.social.instagram} /></FormField>
      </AdminForm>
    </div>
  );
}
