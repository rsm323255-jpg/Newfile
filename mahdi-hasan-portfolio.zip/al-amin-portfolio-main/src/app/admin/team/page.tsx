"use client";

import * as React from "react";
import Link from "next/link";
import { PageHeader } from "@/components/admin/page-header";
import { DataTable, type Column, type Action } from "@/components/admin/data-table";
import { ConfirmDialog } from "@/components/admin/confirm-dialog";
import { EmptyState } from "@/components/admin/empty-state";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useAdminList, useAdminDelete } from "@/hooks/use-admin";
import type { TeamMember } from "@/types";

const columns: Column<TeamMember>[] = [
  { key: "name", label: "Name" },
  { key: "role", label: "Role" },
  { key: "bio", label: "Bio", render: (v) => <span className="line-clamp-1">{String(v)}</span> },
];

export default function AdminTeamPage() {
  const { data, isLoading } = useAdminList<TeamMember>("/team");
  const deleteMutation = useAdminDelete("/team");
  const [deleteId, setDeleteId] = React.useState<string | null>(null);

  const actions: Action<TeamMember>[] = [
    { label: "Edit", href: (row) => `/admin/team/${row.id}` },
    { label: "Delete", variant: "destructive", onClick: (row) => setDeleteId(row.id) },
  ];

  if (isLoading) return <div className="space-y-6"><Skeleton className="h-10 w-48" /><Skeleton className="h-4 w-72" /><div className="space-y-3"><Skeleton className="h-12 w-full rounded-xl" />{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-16 w-full rounded-xl" />)}</div></div>;

  return (
    <div className="space-y-6">
      <PageHeader title="Team" description="Manage team members." breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "Team", href: "/admin/team" }]} action={{ label: "Add Member", href: "/admin/team/new" }} />
      {data && data.length > 0 ? (
        <DataTable columns={columns} data={data} actions={actions} searchKey="name" searchPlaceholder="Search team..." />
      ) : (
        <EmptyState title="No team members" description="Add your first team member." action={<Button asChild><Link href="/admin/team/new">Add Member</Link></Button>} />
      )}
      <ConfirmDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)} title="Delete Member" description="This action cannot be undone." loading={deleteMutation.isPending} onConfirm={async () => { if (deleteId) { await deleteMutation.mutateAsync(deleteId); setDeleteId(null); } }} />
    </div>
  );
}
