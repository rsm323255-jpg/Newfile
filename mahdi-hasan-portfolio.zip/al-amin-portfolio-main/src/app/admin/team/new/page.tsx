"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { PageHeader } from "@/components/admin/page-header";
import { AdminForm } from "@/components/admin/admin-form";
import { FormField, FormInput, FormTextarea } from "@/components/admin/form-field";
import { useAdminCreate } from "@/hooks/use-admin";
import type { TeamMember } from "@/types";

export default function AdminTeamNewPage() {
  const router = useRouter();
  const createMutation = useAdminCreate<TeamMember>("/team");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget as HTMLFormElement);
    await createMutation.mutateAsync({
      name: fd.get("name") as string,
      role: fd.get("role") as string,
      bio: fd.get("bio") as string,
      avatar: fd.get("avatar") as string,
      social: {
        linkedin: fd.get("linkedin") as string || undefined,
        twitter: fd.get("twitter") as string || undefined,
        instagram: fd.get("instagram") as string || undefined,
      },
    });
    router.push("/admin/team");
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Add Team Member" breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "Team", href: "/admin/team" }, { label: "New", href: "/admin/team/new" }]} />
      <AdminForm title="Member Details" onSubmit={handleSubmit} loading={createMutation.isPending} backHref="/admin/team">
        <FormField label="Name" htmlFor="name" required><FormInput id="name" name="name" required placeholder="Full name" /></FormField>
        <FormField label="Role" htmlFor="role" required><FormInput id="role" name="role" required placeholder="e.g. Lead Strategist" /></FormField>
        <FormField label="Avatar URL" htmlFor="avatar"><FormInput id="avatar" name="avatar" placeholder="/images/avatar.jpg" /></FormField>
        <FormField label="Bio" htmlFor="bio" required><FormTextarea id="bio" name="bio" required placeholder="Short bio..." /></FormField>
        <FormField label="LinkedIn URL" htmlFor="linkedin"><FormInput id="linkedin" name="linkedin" placeholder="https://linkedin.com/in/..." /></FormField>
        <FormField label="Twitter URL" htmlFor="twitter"><FormInput id="twitter" name="twitter" placeholder="https://x.com/..." /></FormField>
        <FormField label="Instagram URL" htmlFor="instagram"><FormInput id="instagram" name="instagram" placeholder="https://instagram.com/..." /></FormField>
      </AdminForm>
    </div>
  );
}
