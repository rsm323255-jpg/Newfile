"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { PageHeader } from "@/components/admin/page-header";
import { AdminForm } from "@/components/admin/admin-form";
import { FormField, FormInput } from "@/components/admin/form-field";
import { useAdminCreate } from "@/hooks/use-admin";
import type { Client } from "@/types";

export default function AdminClientsNewPage() {
  const router = useRouter();
  const createMutation = useAdminCreate<Client>("/clients");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget as HTMLFormElement);
    await createMutation.mutateAsync({ name: fd.get("name") as string, logo: fd.get("logo") as string, website: fd.get("website") as string || undefined });
    router.push("/admin/clients");
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Add Client" breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "Clients", href: "/admin/clients" }, { label: "New", href: "/admin/clients/new" }]} />
      <AdminForm title="Client Details" onSubmit={handleSubmit} loading={createMutation.isPending} backHref="/admin/clients">
        <FormField label="Name" htmlFor="name" required><FormInput id="name" name="name" required placeholder="Client name" /></FormField>
        <FormField label="Logo" htmlFor="logo" description="Logo identifier or image URL"><FormInput id="logo" name="logo" placeholder="e.g. client-logo.png" /></FormField>
        <FormField label="Website" htmlFor="website"><FormInput id="website" name="website" placeholder="https://..." /></FormField>
      </AdminForm>
    </div>
  );
}
