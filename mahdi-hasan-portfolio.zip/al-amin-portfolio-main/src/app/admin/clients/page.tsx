"use client";

import * as React from "react";
import Link from "next/link";
import { PageHeader } from "@/components/admin/page-header";
import { DataTable, type Column, type Action } from "@/components/admin/data-table";
import { ConfirmDialog } from "@/components/admin/confirm-dialog";
import { EmptyState } from "@/components/admin/empty-state";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useAdminList, useAdminDelete } from "@/hooks/use-admin";
import type { Client } from "@/types";

const columns: Column<Client>[] = [
  { key: "name", label: "Name" },
  { key: "logo", label: "Logo", hideOnMobile: true },
  { key: "website", label: "Website", hideOnMobile: true, render: (v) => v ? <a href={String(v)} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">{String(v)}</a> : <span className="text-muted-foreground">-</span> },
];

export default function AdminClientsPage() {
  const { data, isLoading } = useAdminList<Client>("/clients");
  const deleteMutation = useAdminDelete("/clients");
  const [deleteId, setDeleteId] = React.useState<string | null>(null);

  const actions: Action<Client>[] = [
    { label: "Edit", href: (row) => `/admin/clients/${row.id}` },
    { label: "Delete", variant: "destructive", onClick: (row) => setDeleteId(row.id) },
  ];

  if (isLoading) return <div className="space-y-6"><Skeleton className="h-10 w-48" /><Skeleton className="h-4 w-72" /><div className="space-y-3"><Skeleton className="h-12 w-full rounded-xl" />{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-16 w-full rounded-xl" />)}</div></div>;

  return (
    <div className="space-y-6">
      <PageHeader title="Clients" description="Manage your clients." breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "Clients", href: "/admin/clients" }]} action={{ label: "Add Client", href: "/admin/clients/new" }} />
      {data && data.length > 0 ? (
        <DataTable columns={columns} data={data} actions={actions} searchKey="name" searchPlaceholder="Search clients..." />
      ) : (
        <EmptyState title="No clients" description="Add your first client." action={<Button asChild><Link href="/admin/clients/new">Add Client</Link></Button>} />
      )}
      <ConfirmDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)} title="Delete Client" description="This action cannot be undone." loading={deleteMutation.isPending} onConfirm={async () => { if (deleteId) { await deleteMutation.mutateAsync(deleteId); setDeleteId(null); } }} />
    </div>
  );
}
