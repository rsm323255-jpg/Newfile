"use client";

import * as React from "react";
import { useRouter, useParams } from "next/navigation";
import { Skeleton } from "@/components/ui/skeleton";
import { PageHeader } from "@/components/admin/page-header";
import { AdminForm } from "@/components/admin/admin-form";
import { FormField, FormInput } from "@/components/admin/form-field";
import { useAdminDetail, useAdminUpdate } from "@/hooks/use-admin";
import type { Client } from "@/types";

export default function AdminClientsEditPage() {
  const router = useRouter();
  const params = useParams();
  const id = params.id as string;
  const { data: item, isLoading } = useAdminDetail<Client>("/clients", id);
  const updateMutation = useAdminUpdate<Client>("/clients");

  if (isLoading) return <div className="space-y-6"><Skeleton className="h-10 w-48" /><Skeleton className="h-4 w-72" /><div className="space-y-4"><Skeleton className="h-12 w-full rounded-xl" /><Skeleton className="h-12 w-full rounded-xl" /><Skeleton className="h-24 w-full rounded-xl" /></div></div>;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget as HTMLFormElement);
    await updateMutation.mutateAsync({ id, data: { name: fd.get("name") as string, logo: fd.get("logo") as string, website: fd.get("website") as string || undefined } });
    router.push("/admin/clients");
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Edit Client" breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "Clients", href: "/admin/clients" }, { label: "Edit", href: `/admin/clients/${id}` }]} />
      <AdminForm title="Client Details" onSubmit={handleSubmit} loading={updateMutation.isPending} backHref="/admin/clients" submitLabel="Update">
        <FormField label="Name" htmlFor="name" required><FormInput id="name" name="name" required defaultValue={item?.name} /></FormField>
        <FormField label="Logo" htmlFor="logo"><FormInput id="logo" name="logo" defaultValue={item?.logo} /></FormField>
        <FormField label="Website" htmlFor="website"><FormInput id="website" name="website" defaultValue={item?.website} /></FormField>
      </AdminForm>
    </div>
  );
}
