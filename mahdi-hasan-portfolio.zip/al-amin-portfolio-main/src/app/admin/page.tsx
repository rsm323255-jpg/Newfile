"use client";

import * as React from "react";
import Link from "next/link";
import { useQuery } from "@tanstack/react-query";
import {
  Briefcase,
  FileText,
  Star,
  MessageSquare,
  Users,
  TrendingUp,
  Eye,
  Globe,
  Plus,
  Mail,
  Settings,
  Activity,
  ChevronDown,
  Loader2,
  ExternalLink,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Modal } from "@/components/ui/modal";
import { Skeleton } from "@/components/ui/skeleton";
import { useAdminList } from "@/hooks/use-admin";
import type {
  PortfolioItem,
  CaseStudy,
  Testimonial,
  TeamMember,
  FAQItem,
  Client,
  ProcessStep,
  MessageSubmission,
  ApiResponse,
} from "@/types";

interface ActivityItem {
  id: string;
  action: string;
  entity: string;
  entityId?: string;
  entityTitle?: string;
  userName: string;
  createdAt: string;
}

interface VisitorRow {
  id: string;
  ip: string;
  path: string;
  referrer: string;
  userAgent: string;
  createdAt: string;
}

interface VisitorStats {
  totalVisits: number;
  uniqueVisitors: number;
  topPages: { path: string; count: number }[];
  dailyVisits: { date: string; visits: number }[];
}

interface ActivityPage {
  data: ActivityItem[];
  nextCursor: string | null;
  total: number;
}

interface VisitorPage {
  visitors: VisitorRow[];
  nextCursor: string | null;
  stats: VisitorStats;
}

function timeAgo(dateStr: string): string {
  const seconds = Math.floor((Date.now() - new Date(dateStr).getTime()) / 1000);
  if (seconds < 60) return "just now";
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days}d ago`;
  const months = Math.floor(days / 30);
  return `${months}mo ago`;
}

function formatDate(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

const actionIcons: Record<string, string> = {
  created: "✨",
  updated: "✏️",
  deleted: "🗑️",
};

const entityLabels: Record<string, string> = {
  portfolio: "Portfolio",
  "case-studies": "Case Study",
  testimonials: "Testimonial",
  skills: "Skill",
  team: "Team",
  faq: "FAQ",
  clients: "Client",
  process: "Process",
  messages: "Message",
  "content/contact": "Contact",
  "content/social": "Social Links",
  "content/newsletter": "Newsletter",
  "content/hero": "Hero",
  "content/about": "About",
  "content/skills-section": "Skills Section",
};

export default function AdminDashboardPage() {
  const { data: portfolio } = useAdminList<PortfolioItem>("/portfolio");
  const { data: caseStudies } = useAdminList<CaseStudy>("/case-studies");
  const { data: testimonials } = useAdminList<Testimonial>("/testimonials");
  const { data: messages } = useAdminList<MessageSubmission>("/messages");
  const { data: team } = useAdminList<TeamMember>("/team");
  const { data: faq } = useAdminList<FAQItem>("/faq");
  const { data: clients } = useAdminList<Client>("/clients");
  const { data: processSteps } = useAdminList<ProcessStep>("/process");

  // Activity — React Query polling every 30s
  const activityQuery = useQuery({
    queryKey: ["admin", "activity", "dashboard"],
    queryFn: async () => {
      const res = await fetch("/api/activity?limit=8");
      const json: ApiResponse<ActivityPage> = await res.json();
      if (!json.success || !json.data) throw new Error("Failed");
      return json.data;
    },
    refetchInterval: 30_000,
    staleTime: 10_000,
  });

  // Visitor stats — React Query polling every 60s
  const visitorQuery = useQuery({
    queryKey: ["admin", "visitors", "dashboard"],
    queryFn: async () => {
      const res = await fetch("/api/visitors?days=30");
      const json: ApiResponse<VisitorPage> = await res.json();
      if (!json.success || !json.data) throw new Error("Failed");
      return json.data;
    },
    refetchInterval: 30_000,
    staleTime: 10_000,
  });

  const activityData = activityQuery.data;
  const visitorData = visitorQuery.data;

  // Cursor pagination state (appended pages, separate from react-query)
  const [extraActivities, setExtraActivities] = React.useState<ActivityItem[]>([]);
  const [activityCursor, setActivityCursor] = React.useState<string | null>(null);
  const [loadingMoreActivity, setLoadingMoreActivity] = React.useState(false);

  const [extraVisitors, setExtraVisitors] = React.useState<VisitorRow[]>([]);
  const [visitorCursor, setVisitorCursor] = React.useState<string | null>(null);
  const [loadingMoreVisitors, setLoadingMoreVisitors] = React.useState(false);
  const [visitorModalOpen, setVisitorModalOpen] = React.useState(false);

  // Sync cursor from react-query data
  React.useEffect(() => {
    if (activityData) setActivityCursor(activityData.nextCursor);
  }, [activityData]);

  React.useEffect(() => {
    if (visitorData) setVisitorCursor(visitorData.nextCursor);
  }, [visitorData]);

  // Reset extra pages when react-query refetches fresh data
  React.useEffect(() => {
    setExtraActivities([]);
  }, [activityQuery.dataUpdatedAt]);

  React.useEffect(() => {
    setExtraVisitors([]);
  }, [visitorQuery.dataUpdatedAt]);

  function loadMoreActivity() {
    if (!activityCursor) return;
    setLoadingMoreActivity(true);
    fetch(`/api/activity?limit=8&cursor=${activityCursor}`)
      .then((r) => r.json())
      .then((json: ApiResponse<ActivityPage>) => {
        if (json.success && json.data) {
          setExtraActivities((prev) => [...prev, ...json.data!.data]);
          setActivityCursor(json.data.nextCursor);
        }
      })
      .catch(() => {})
      .finally(() => setLoadingMoreActivity(false));
  }

  function loadMoreVisitors() {
    if (!visitorCursor) return;
    setLoadingMoreVisitors(true);
    fetch(`/api/visitors?limit=20&days=30&cursor=${visitorCursor}`)
      .then((r) => r.json())
      .then((json: ApiResponse<VisitorPage>) => {
        if (json.success && json.data) {
          setExtraVisitors((prev) => [...prev, ...json.data!.visitors]);
          setVisitorCursor(json.data.nextCursor);
        }
      })
      .catch(() => {})
      .finally(() => setLoadingMoreVisitors(false));
  }

  const allActivities = [
    ...(activityData?.data ?? []),
    ...extraActivities,
  ];
  const allVisitors = [
    ...(visitorData?.visitors ?? []),
    ...extraVisitors,
  ];

  const stats = [
    {
      label: "Portfolio",
      value: portfolio?.length ?? "–",
      icon: Briefcase,
      href: "/admin/portfolio",
      color: "text-primary bg-primary/10",
    },
    {
      label: "Case Studies",
      value: caseStudies?.length ?? "–",
      icon: FileText,
      href: "/admin/case-studies",
      color: "text-accent bg-accent/10",
    },
    {
      label: "Testimonials",
      value: testimonials?.length ?? "–",
      icon: Star,
      href: "/admin/testimonials",
      color: "text-primary bg-primary/10",
    },
    {
      label: "Messages",
      value: messages?.length ?? "–",
      icon: MessageSquare,
      href: "/admin/messages",
      color: "text-emerald-600 bg-emerald-600/10",
    },
    {
      label: "Total Visits",
      value: visitorData?.stats.totalVisits ?? "–",
      icon: TrendingUp,
      onClick: () => setVisitorModalOpen(true),
      color: "text-accent bg-accent/10",
    },
    {
      label: "Unique Visitors",
      value: visitorData?.stats.uniqueVisitors ?? "–",
      icon: Eye,
      onClick: () => setVisitorModalOpen(true),
      color: "text-cyan-600 bg-cyan-600/10",
    },
  ];

  return (
    <div className="space-y-6 sm:space-y-8 overflow-hidden">
      <div>
        <h1 className="font-heading text-xl font-bold tracking-tight text-foreground sm:text-2xl">
          Dashboard
        </h1>
        <p className="mt-1 text-xs text-muted-foreground sm:text-sm">
          Welcome back! Here&apos;s an overview of your portfolio.
        </p>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 sm:gap-4 lg:grid-cols-3">
        {stats.map((stat) => {
          const Icon = stat.icon;
          const cardContent = (
            <Card
              className={
                stat.href || stat.onClick
                  ? "cursor-pointer transition-colors hover:bg-muted/50"
                  : ""
              }
            >
              <CardContent className="flex items-start gap-3 sm:gap-4">
                <div
                  className={`flex size-10 shrink-0 items-center justify-center rounded-xl sm:size-12 ${stat.color}`}
                >
                  <Icon className="size-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-xs text-muted-foreground sm:text-sm">{stat.label}</p>
                  <p className="font-heading text-xl font-bold tracking-tight text-foreground sm:text-2xl tabular-nums">
                    {stat.value}
                  </p>
                </div>
              </CardContent>
            </Card>
          );
          if (stat.href) {
            return (
              <Link key={stat.label} href={stat.href} className="block min-w-0">
                {cardContent}
              </Link>
            );
          }
          if (stat.onClick) {
            return (
              <button
                key={stat.label}
                onClick={stat.onClick}
                className="block min-w-0 text-left w-full"
              >
                {cardContent}
              </button>
            );
          }
          return <div key={stat.label} className="min-w-0">{cardContent}</div>;
        })}
      </div>

      {/* Activity + Top Pages + Quick Actions */}
      <div className="grid gap-3 min-w-0 sm:gap-6 lg:grid-cols-3">
        {/* Recent Activity */}
        <Card className="lg:col-span-1">
          <CardContent>
            <div className="mb-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Activity className="size-4 text-muted-foreground" />
                <h3 className="font-heading text-base font-semibold text-foreground">
                  Recent Activity
                </h3>
              </div>
              {activityData && (
                <span className="rounded-full bg-muted px-2 py-0.5 text-xs font-medium text-muted-foreground">
                  {activityData.total}
                </span>
              )}
            </div>
            <div className="h-[360px] overflow-y-auto pr-1">
            {activityQuery.isLoading ? (
              <div className="space-y-3">
                {Array.from({ length: 5 }).map((_, i) => (
                  <div key={i} className="flex items-start gap-3 border-b border-border pb-3">
                    <Skeleton className="size-5 shrink-0 rounded" />
                    <div className="flex-1 space-y-2">
                      <Skeleton className="h-4 w-3/4" />
                      <Skeleton className="h-3 w-1/4" />
                    </div>
                  </div>
                ))}
              </div>
            ) : allActivities.length === 0 ? (
              <p className="py-8 text-center text-sm text-muted-foreground">
                No activity yet
              </p>
            ) : (
              <>
                <div className="space-y-3">
                  {allActivities.map((item) => (
                    <div
                      key={item.id}
                      className="flex items-start gap-3 border-b border-border pb-3 last:border-0 last:pb-0"
                    >
                      <span className="mt-0.5 text-sm">
                        {actionIcons[item.action] || "📝"}
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="text-sm text-foreground">
                          <span className="font-medium">{item.userName}</span>{" "}
                          {item.action}{" "}
                          <span className="font-medium">
                            {entityLabels[item.entity] || item.entity}
                          </span>
                          {item.entityTitle && (
                            <span className="text-muted-foreground">
                              {" "}
                              &ldquo;{item.entityTitle}&rdquo;
                            </span>
                          )}
                        </p>
                        <p className="mt-0.5 text-xs text-muted-foreground">
                          {timeAgo(item.createdAt)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
                {activityCursor && (
                  <div className="mt-4 flex justify-center">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={loadMoreActivity}
                      disabled={loadingMoreActivity}
                    >
                      {loadingMoreActivity ? (
                        <Loader2 className="mr-2 size-3 animate-spin" />
                      ) : (
                        <ChevronDown className="mr-2 size-3" />
                      )}
                      Load More
                    </Button>
                  </div>
                )}
              </>
            )}
            </div>
          </CardContent>
        </Card>

        {/* Top Pages */}
        <Card className="lg:col-span-1">
          <CardContent>
            <div className="mb-4 flex items-center gap-2">
              <Globe className="size-4 text-muted-foreground" />
              <h3 className="font-heading text-base font-semibold text-foreground">
                Top Pages
              </h3>
            </div>
            <div className="h-[360px] overflow-y-auto pr-1">
            {visitorQuery.isLoading ? (
              <div className="space-y-3">
                {Array.from({ length: 5 }).map((_, i) => (
                  <div key={i} className="flex items-center justify-between border-b border-border pb-3">
                    <Skeleton className="h-4 w-2/3" />
                    <Skeleton className="h-5 w-8 rounded-full" />
                  </div>
                ))}
              </div>
            ) : !visitorData?.stats.topPages?.length ? (
              <p className="py-8 text-center text-sm text-muted-foreground">
                No visitor data yet
              </p>
            ) : (
              <div className="space-y-3">
                {visitorData.stats.topPages.map((page) => (
                  <div
                    key={page.path}
                    className="flex items-center justify-between border-b border-border pb-3 last:border-0 last:pb-0"
                  >
                    <span className="truncate text-sm text-foreground">
                      {page.path || "/"}
                    </span>
                    <span className="ml-2 shrink-0 rounded-full bg-muted px-2 py-0.5 text-xs font-medium text-muted-foreground">
                      {page.count}
                    </span>
                  </div>
                ))}
              </div>
            )}
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card className="lg:col-span-1">
          <CardContent>
            <div className="mb-4 flex items-center gap-2">
              <Plus className="size-4 text-muted-foreground" />
              <h3 className="font-heading text-base font-semibold text-foreground">
                Quick Actions
              </h3>
            </div>
            <div className="space-y-2">
              {[
                { label: "Add Portfolio Item", href: "/admin/portfolio/new", icon: Briefcase },
                { label: "Add Case Study", href: "/admin/case-studies/new", icon: FileText },
                { label: "Add Testimonial", href: "/admin/testimonials/new", icon: Star },
                { label: "View Messages", href: "/admin/messages", icon: Mail },
                { label: "Site Content", href: "/admin/content", icon: Settings },
              ].map((action) => (
                <Link
                  key={action.href}
                  href={action.href}
                  className="flex items-center gap-3 rounded-xl border border-border bg-muted/50 px-3 py-2.5 text-sm font-medium text-foreground transition-colors hover:bg-muted sm:px-4 sm:py-3"
                >
                  <action.icon className="size-4 text-muted-foreground" />
                  {action.label}
                </Link>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-2 gap-3 min-w-0 sm:gap-4 lg:grid-cols-4">
        {[
          { label: "Team Members", value: team?.length ?? "–", icon: Users },
          { label: "FAQ Items", value: faq?.length ?? "–", icon: FileText },
          { label: "Clients", value: clients?.length ?? "–", icon: Briefcase },
          { label: "Process Steps", value: processSteps?.length ?? "–", icon: Settings },
        ].map((item) => (
          <Card key={item.label}>
            <CardContent className="flex items-center gap-3">
              <item.icon className="size-5 shrink-0 text-muted-foreground" />
              <div className="min-w-0 flex-1">
                <p className="text-xs text-muted-foreground sm:text-sm">{item.label}</p>
                <p className="font-heading text-lg font-bold text-foreground sm:text-xl">
                  {item.value}
                </p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Visitor Detail Modal */}
      <Modal
        open={visitorModalOpen}
        onClose={() => setVisitorModalOpen(false)}
        ariaLabel="Visitor Details"
      >
        <div className="p-6 sm:p-8">
          <div className="mb-6 flex items-center justify-between">
            <div>
              <h2 className="font-heading text-xl font-bold text-foreground">
                Visitor Details
              </h2>
              <p className="mt-1 text-sm text-muted-foreground">
                {visitorData?.stats.totalVisits ?? 0} total visits ·{" "}
                {visitorData?.stats.uniqueVisitors ?? 0} unique visitors
              </p>
            </div>
          </div>

          {allVisitors.length === 0 ? (
            <p className="py-8 text-center text-sm text-muted-foreground">
              No visitor data yet
            </p>
          ) : (
            <>
              <div className="overflow-x-auto rounded-xl border border-border">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="px-3 py-3 text-left font-medium text-muted-foreground sm:px-4">
                        Date
                      </th>
                      <th className="hidden px-3 py-3 text-left font-medium text-muted-foreground sm:table-cell sm:px-4">
                        IP
                      </th>
                      <th className="px-3 py-3 text-left font-medium text-muted-foreground sm:px-4">
                        Page
                      </th>
                      <th className="hidden px-3 py-3 text-left font-medium text-muted-foreground sm:table-cell sm:px-4">
                        Referrer
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {allVisitors.map((v) => (
                      <tr
                        key={v.id}
                        className="border-b border-border last:border-0"
                      >
                        <td className="whitespace-nowrap px-3 py-3 text-muted-foreground sm:px-4">
                          {formatDate(v.createdAt)}
                        </td>
                        <td className="hidden px-3 py-3 font-mono text-xs text-foreground sm:table-cell sm:px-4">
                          {v.ip}
                        </td>
                        <td className="px-3 py-3 text-foreground sm:px-4">{v.path}</td>
                        <td className="hidden px-3 py-3 text-muted-foreground sm:table-cell sm:px-4 max-w-[200px] truncate">
                          {v.referrer ? (
                            <span className="flex items-center gap-1">
                              <ExternalLink className="size-3 shrink-0" />
                              {v.referrer}
                            </span>
                          ) : (
                            "–"
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {visitorCursor && (
                <div className="mt-4 flex justify-center">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={loadMoreVisitors}
                    disabled={loadingMoreVisitors}
                  >
                    {loadingMoreVisitors ? (
                      <Loader2 className="mr-2 size-3 animate-spin" />
                    ) : (
                      <ChevronDown className="mr-2 size-3" />
                    )}
                    Load More
                  </Button>
                </div>
              )}
            </>
          )}
        </div>
      </Modal>
    </div>
  );
}
