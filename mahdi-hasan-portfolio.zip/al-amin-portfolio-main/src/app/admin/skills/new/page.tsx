"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { PageHeader } from "@/components/admin/page-header";
import { AdminForm } from "@/components/admin/admin-form";
import { FormField, FormInput, FormTextarea } from "@/components/admin/form-field";
import { useAdminCreate } from "@/hooks/use-admin";
import type { Skill } from "@/types";

export default function AdminSkillsNewPage() {
  const router = useRouter();
  const createMutation = useAdminCreate<Skill>("/skills");
  const [features, setFeatures] = React.useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget as HTMLFormElement);
    await createMutation.mutateAsync({
      title: fd.get("title") as string,
      description: fd.get("description") as string,
      icon: fd.get("icon") as string,
      features: features.split("\n").map((f) => f.trim()).filter(Boolean),
    });
    router.push("/admin/skills");
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Add Skill" breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "Skills", href: "/admin/skills" }, { label: "New", href: "/admin/skills/new" }]} />
      <AdminForm title="Skill Details" onSubmit={handleSubmit} loading={createMutation.isPending} backHref="/admin/skills">
        <FormField label="Title" htmlFor="title" required><FormInput id="title" name="title" required placeholder="e.g. Meta Ads" /></FormField>
        <FormField label="Icon (Emoji)" htmlFor="icon"><FormInput id="icon" name="icon" placeholder="e.g. 📊" /></FormField>
        <FormField label="Description" htmlFor="description" required><FormTextarea id="description" name="description" required placeholder="Describe this skill..." /></FormField>
        <FormField label="Features" htmlFor="features" description="One feature per line"><FormTextarea id="features" value={features} onChange={(e) => setFeatures(e.target.value)} placeholder={"Feature 1\nFeature 2\nFeature 3"} /></FormField>
      </AdminForm>
    </div>
  );
}
