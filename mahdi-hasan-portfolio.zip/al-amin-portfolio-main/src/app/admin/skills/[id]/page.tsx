"use client";

import * as React from "react";
import { useRouter, useParams } from "next/navigation";
import { Skeleton } from "@/components/ui/skeleton";
import { PageHeader } from "@/components/admin/page-header";
import { AdminForm } from "@/components/admin/admin-form";
import { FormField, FormInput, FormTextarea } from "@/components/admin/form-field";
import { useAdminDetail, useAdminUpdate } from "@/hooks/use-admin";
import type { Skill } from "@/types";

export default function AdminSkillsEditPage() {
  const router = useRouter();
  const params = useParams();
  const id = params.id as string;
  const { data: item, isLoading } = useAdminDetail<Skill>("/skills", id);
  const updateMutation = useAdminUpdate<Skill>("/skills");
  const [features, setFeatures] = React.useState("");

  React.useEffect(() => { if (item) setFeatures(item.features.join("\n")); }, [item]);

  if (isLoading) return <div className="space-y-6"><Skeleton className="h-10 w-48" /><Skeleton className="h-4 w-72" /><div className="space-y-4"><Skeleton className="h-12 w-full rounded-xl" /><Skeleton className="h-12 w-full rounded-xl" /><Skeleton className="h-24 w-full rounded-xl" /></div></div>;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget as HTMLFormElement);
    await updateMutation.mutateAsync({ id, data: { title: fd.get("title") as string, description: fd.get("description") as string, icon: fd.get("icon") as string, features: features.split("\n").map((f) => f.trim()).filter(Boolean) } });
    router.push("/admin/skills");
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Edit Skill" breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "Skills", href: "/admin/skills" }, { label: "Edit", href: `/admin/skills/${id}` }]} />
      <AdminForm title="Skill Details" onSubmit={handleSubmit} loading={updateMutation.isPending} backHref="/admin/skills" submitLabel="Update">
        <FormField label="Title" htmlFor="title" required><FormInput id="title" name="title" required defaultValue={item?.title} /></FormField>
        <FormField label="Icon (Emoji)" htmlFor="icon"><FormInput id="icon" name="icon" defaultValue={item?.icon} /></FormField>
        <FormField label="Description" htmlFor="description" required><FormTextarea id="description" name="description" required defaultValue={item?.description} /></FormField>
        <FormField label="Features" htmlFor="features" description="One feature per line"><FormTextarea id="features" value={features} onChange={(e) => setFeatures(e.target.value)} /></FormField>
      </AdminForm>
    </div>
  );
}
