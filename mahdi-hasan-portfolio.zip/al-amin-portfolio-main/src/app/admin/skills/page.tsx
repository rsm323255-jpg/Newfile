"use client";

import * as React from "react";
import Link from "next/link";
import { PageHeader } from "@/components/admin/page-header";
import { DataTable, type Column, type Action } from "@/components/admin/data-table";
import { ConfirmDialog } from "@/components/admin/confirm-dialog";
import { EmptyState } from "@/components/admin/empty-state";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useAdminList, useAdminDelete } from "@/hooks/use-admin";
import type { Skill } from "@/types";

const columns: Column<Skill>[] = [
  { key: "icon", label: "Icon", render: (v) => <span className="text-xl">{String(v)}</span> },
  { key: "title", label: "Title" },
  { key: "description", label: "Description", hideOnMobile: true, render: (v) => <span className="line-clamp-1">{String(v)}</span> },
  { key: "features", label: "Features", hideOnMobile: true, render: (v) => <span>{(v as string[]).length} features</span> },
];

export default function AdminSkillsPage() {
  const { data, isLoading } = useAdminList<Skill>("/skills");
  const deleteMutation = useAdminDelete("/skills");
  const [deleteId, setDeleteId] = React.useState<string | null>(null);

  const actions: Action<Skill>[] = [
    { label: "Edit", href: (row) => `/admin/skills/${row.id}` },
    { label: "Delete", variant: "destructive", onClick: (row) => setDeleteId(row.id) },
  ];

  if (isLoading) return <div className="space-y-6"><Skeleton className="h-10 w-48" /><Skeleton className="h-4 w-72" /><div className="space-y-3"><Skeleton className="h-12 w-full rounded-xl" />{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-16 w-full rounded-xl" />)}</div></div>;

  return (
    <div className="space-y-6">
      <PageHeader title="Skills" description="Manage your skills and services." breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "Skills", href: "/admin/skills" }]} action={{ label: "Add Skill", href: "/admin/skills/new" }} />
      {data && data.length > 0 ? (
        <DataTable columns={columns} data={data} actions={actions} searchKey="title" searchPlaceholder="Search skills..." />
      ) : (
        <EmptyState title="No skills" description="Add your first skill." action={<Button asChild><Link href="/admin/skills/new">Add Skill</Link></Button>} />
      )}
      <ConfirmDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)} title="Delete Skill" description="This action cannot be undone." loading={deleteMutation.isPending} onConfirm={async () => { if (deleteId) { await deleteMutation.mutateAsync(deleteId); setDeleteId(null); } }} />
    </div>
  );
}
