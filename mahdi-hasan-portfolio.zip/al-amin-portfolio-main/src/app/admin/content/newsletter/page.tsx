"use client";

import * as React from "react";
import { Skeleton } from "@/components/ui/skeleton";
import { PageHeader } from "@/components/admin/page-header";
import { AdminForm } from "@/components/admin/admin-form";
import { FormField, FormInput } from "@/components/admin/form-field";
import { useAdminSingleton, useAdminUpdateSingleton } from "@/hooks/use-admin";
import type { NewsletterData } from "@/types";

export default function AdminNewsletterContentPage() {
  const { data: item, isLoading } = useAdminSingleton<NewsletterData>("/content/newsletter");
  const updateMutation = useAdminUpdateSingleton<NewsletterData>("/content/newsletter");

  if (isLoading) return <div className="space-y-6"><Skeleton className="h-10 w-48" /><Skeleton className="h-4 w-72" /><div className="space-y-4"><Skeleton className="h-12 w-full rounded-xl" /><Skeleton className="h-12 w-full rounded-xl" /></div></div>;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget as HTMLFormElement);
    await updateMutation.mutateAsync({
      title: fd.get("title") as string,
      description: fd.get("description") as string,
      button: fd.get("button") as string,
    });
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Edit Newsletter" breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "Content", href: "/admin/content" }, { label: "Newsletter", href: "/admin/content/newsletter" }]} />
      <AdminForm title="Newsletter Details" onSubmit={handleSubmit} loading={updateMutation.isPending} backHref="/admin/content" submitLabel="Update">
        <FormField label="Title" htmlFor="title" required><FormInput id="title" name="title" required defaultValue={item?.title} /></FormField>
        <FormField label="Description" htmlFor="description" required><FormInput id="description" name="description" required defaultValue={item?.description} /></FormField>
        <FormField label="Button Text" htmlFor="button"><FormInput id="button" name="button" defaultValue={item?.button} /></FormField>
      </AdminForm>
    </div>
  );
}
