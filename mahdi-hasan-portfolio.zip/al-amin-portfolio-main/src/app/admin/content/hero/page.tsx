"use client";

import * as React from "react";
import { Skeleton } from "@/components/ui/skeleton";
import toast from "react-hot-toast";
import { PageHeader } from "@/components/admin/page-header";
import { AdminForm } from "@/components/admin/admin-form";
import { FormField, FormInput, FormTextarea } from "@/components/admin/form-field";
import { ImageUpload } from "@/components/admin/image-upload";
import { useAdminSingleton, useAdminUpdateSingleton } from "@/hooks/use-admin";
import type { HeroData } from "@/types";

export default function AdminHeroContentPage() {
  const { data: item, isLoading } = useAdminSingleton<HeroData>("/content/hero");
  const updateMutation = useAdminUpdateSingleton<HeroData>("/content/hero");
  const [imageUrl, setImageUrl] = React.useState("");

  React.useEffect(() => {
    if (item?.image) setImageUrl(item.image);
  }, [item?.image]);

  if (isLoading) return <div className="space-y-6"><Skeleton className="h-10 w-48" /><Skeleton className="h-4 w-72" /><div className="space-y-4"><Skeleton className="h-12 w-full rounded-xl" /><Skeleton className="h-12 w-full rounded-xl" /><Skeleton className="h-24 w-full rounded-xl" /></div></div>;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!imageUrl) {
      toast.error("Please upload a hero image");
      return;
    }
    const fd = new FormData(e.currentTarget as HTMLFormElement);
    try {
      await updateMutation.mutateAsync({
        title: fd.get("title") as string,
        subtitle: fd.get("subtitle") as string,
        description: fd.get("description") as string,
        ctaPrimary: fd.get("ctaPrimary") as string,
        ctaSecondary: fd.get("ctaSecondary") as string,
        image: imageUrl,
        stats: item?.stats ?? [],
      });
    } catch {}
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Edit Hero Section" breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "Content", href: "/admin/content" }, { label: "Hero", href: "/admin/content/hero" }]} />
      <AdminForm title="Hero Details" onSubmit={handleSubmit} loading={updateMutation.isPending} backHref="/admin/content" submitLabel="Update">
        <FormField label="Title" htmlFor="title" required><FormInput id="title" name="title" required defaultValue={item?.title} /></FormField>
        <FormField label="Subtitle" htmlFor="subtitle" required><FormInput id="subtitle" name="subtitle" required defaultValue={item?.subtitle} /></FormField>
        <FormField label="Description" htmlFor="description" required><FormTextarea id="description" name="description" required defaultValue={item?.description} /></FormField>
        <FormField label="Primary CTA" htmlFor="ctaPrimary"><FormInput id="ctaPrimary" name="ctaPrimary" defaultValue={item?.ctaPrimary} /></FormField>
        <FormField label="Secondary CTA" htmlFor="ctaSecondary"><FormInput id="ctaSecondary" name="ctaSecondary" defaultValue={item?.ctaSecondary} /></FormField>
        <FormField label="Hero Image" htmlFor="hero-image" required description="Recommended size: 800x800px">
          <ImageUpload
            value={imageUrl}
            onChange={setImageUrl}
            folder="hero"
          />
        </FormField>
      </AdminForm>
    </div>
  );
}
