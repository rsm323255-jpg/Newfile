"use client";

import * as React from "react";
import { Plus, Trash2 } from "lucide-react";
import toast from "react-hot-toast";
import { PageHeader } from "@/components/admin/page-header";
import { AdminForm } from "@/components/admin/admin-form";
import { FormField, FormInput, FormTextarea } from "@/components/admin/form-field";
import { ImageUpload } from "@/components/admin/image-upload";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useAdminSingleton, useAdminUpdateSingleton } from "@/hooks/use-admin";
import type { AboutData, Statistic } from "@/types";

export default function AdminAboutContentPage() {
  const { data: item, isLoading } = useAdminSingleton<AboutData>("/content/about");
  const updateMutation = useAdminUpdateSingleton<AboutData>("/content/about");
  const [imageUrl, setImageUrl] = React.useState("");
  const [achievements, setAchievements] = React.useState<Statistic[]>([]);

  React.useEffect(() => {
    if (item) {
      setImageUrl(item.image || "");
      setAchievements(item.achievements || []);
    }
  }, [item]);

  if (isLoading) return <div className="space-y-6"><Skeleton className="h-10 w-48" /><Skeleton className="h-4 w-72" /><div className="space-y-4"><Skeleton className="h-12 w-full rounded-xl" /><Skeleton className="h-12 w-full rounded-xl" /><Skeleton className="h-24 w-full rounded-xl" /></div></div>;

  function addAchievement() {
    setAchievements((prev) => [
      ...prev,
      { id: `a${Date.now()}`, value: "", label: "", suffix: "" },
    ]);
  }

  function removeAchievement(id: string) {
    setAchievements((prev) => prev.filter((a) => a.id !== id));
  }

  function updateAchievement(id: string, field: keyof Statistic, value: string) {
    setAchievements((prev) =>
      prev.map((a) => (a.id === id ? { ...a, [field]: value } : a))
    );
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget as HTMLFormElement);
    try {
      await updateMutation.mutateAsync({
        title: fd.get("title") as string,
        description: fd.get("description") as string,
        mission: fd.get("mission") as string,
        missionContent: fd.get("missionContent") as string,
        vision: fd.get("vision") as string,
        visionContent: fd.get("visionContent") as string,
        experience: fd.get("experience") as string,
        image: imageUrl,
        achievements,
      });
    } catch {}
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Edit About Section" breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "Content", href: "/admin/content" }, { label: "About", href: "/admin/content/about" }]} />
      <AdminForm title="About Details" onSubmit={handleSubmit} loading={updateMutation.isPending} backHref="/admin/content" submitLabel="Update">
        <FormField label="Title" htmlFor="title" required><FormInput id="title" name="title" required defaultValue={item?.title} /></FormField>
        <FormField label="Description" htmlFor="description" required><FormTextarea id="description" name="description" required defaultValue={item?.description} /></FormField>
        <FormField label="Mission" htmlFor="mission" required><FormTextarea id="mission" name="mission" required defaultValue={item?.mission} /></FormField>
        <FormField label="Mission Content" htmlFor="missionContent" description="Detailed content shown below the mission card"><FormTextarea id="missionContent" name="missionContent" defaultValue={item?.missionContent} /></FormField>
        <FormField label="Vision" htmlFor="vision" required><FormTextarea id="vision" name="vision" required defaultValue={item?.vision} /></FormField>
        <FormField label="Vision Content" htmlFor="visionContent" description="Detailed content shown below the vision card"><FormTextarea id="visionContent" name="visionContent" defaultValue={item?.visionContent} /></FormField>
        <FormField label="Experience" htmlFor="experience"><FormInput id="experience" name="experience" defaultValue={item?.experience} placeholder="e.g. 10+ years" /></FormField>

        <FormField label="About Image" htmlFor="about-image" description="Photo for the about section">
          <ImageUpload value={imageUrl} onChange={setImageUrl} folder="about" />
        </FormField>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-medium text-foreground">Achievements</h3>
            <Button type="button" variant="outline" size="sm" onClick={addAchievement}>
              <Plus className="size-4 mr-1" /> Add
            </Button>
          </div>
          {achievements.length === 0 && (
            <p className="text-sm text-muted-foreground">No achievements yet. Click Add to create one.</p>
          )}
          {achievements.map((stat) => (
            <div key={stat.id} className="flex flex-col gap-3 rounded-xl border border-border bg-background p-4 sm:flex-row sm:items-start">
              <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-muted-foreground">Value</label>
                  <input
                    value={stat.value}
                    onChange={(e) => updateAchievement(stat.id, "value", e.target.value)}
                    placeholder="e.g. 10+"
                    className="h-9 w-full rounded-lg border border-border bg-background px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring/50"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-muted-foreground">Label</label>
                  <input
                    value={stat.label}
                    onChange={(e) => updateAchievement(stat.id, "label", e.target.value)}
                    placeholder="e.g. Years Experience"
                    className="h-9 w-full rounded-lg border border-border bg-background px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring/50"
                  />
                </div>
              </div>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="sm:mt-5 text-destructive hover:text-destructive self-end sm:self-auto"
                onClick={() => removeAchievement(stat.id)}
              >
                <Trash2 className="size-4" />
              </Button>
            </div>
          ))}
        </div>
      </AdminForm>
    </div>
  );
}
