"use client";

import * as React from "react";
import Link from "next/link";
import { useQueries } from "@tanstack/react-query";
import { ExternalLink } from "lucide-react";
import { PageHeader } from "@/components/admin/page-header";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

interface ContentData {
  eyebrow?: string;
  title?: string;
  subtitle?: string;
  description?: string;
  email?: string;
  phone?: string;
  lastUpdated?: string;
  content?: string;
  linkedin?: string;
}

const sections = [
  { title: "Hero Section", description: "Edit homepage hero title, subtitle, description and CTA buttons.", href: "/admin/content/hero", api: "/content/hero" },
  { title: "About Section", description: "Edit about page title, description, mission, vision and experience.", href: "/admin/content/about", api: "/content/about" },
  { title: "Skills Section", description: "Edit skills section title and subtitle.", href: "/admin/content/skills", api: "/content/skills-section" },
  { title: "Portfolio Section", description: "Edit portfolio section eyebrow, title and subtitle.", href: "/admin/content/portfolio-section", api: "/content/portfolio-section" },
  { title: "Case Studies Section", description: "Edit case studies section eyebrow, title and subtitle.", href: "/admin/content/case-studies-section", api: "/content/case-studies-section" },
  { title: "Testimonials Section", description: "Edit testimonials section eyebrow, title and subtitle.", href: "/admin/content/testimonials-section", api: "/content/testimonials-section" },
  { title: "Team Section", description: "Edit team section eyebrow, title and subtitle.", href: "/admin/content/team-section", api: "/content/team-section" },
  { title: "FAQ Section", description: "Edit FAQ section eyebrow, title and subtitle.", href: "/admin/content/faq-section", api: "/content/faq-section" },
  { title: "Clients Section", description: "Edit clients section eyebrow, title and subtitle.", href: "/admin/content/clients-section", api: "/content/clients-section" },
  { title: "Process Section", description: "Edit process section eyebrow, title and subtitle.", href: "/admin/content/process-section", api: "/content/process-section" },
  { title: "Statistics Section", description: "Edit statistics section eyebrow, title and subtitle.", href: "/admin/content/statistics-section", api: "/content/statistics-section" },
  { title: "Why Choose Us Section", description: "Edit why choose us section eyebrow, title and subtitle.", href: "/admin/content/why-choose-us-section", api: "/content/why-choose-us-section" },
  { title: "Contact Info", description: "Edit contact email, phone, address and working hours.", href: "/admin/content/contact", api: "/content/contact" },
  { title: "Newsletter", description: "Edit newsletter section title, description and button text.", href: "/admin/content/newsletter", api: "/content/newsletter" },
  { title: "Social Links", description: "Edit social media URLs for LinkedIn, Instagram, Facebook and TikTok.", href: "/admin/content/social", api: "/content/social" },
  { title: "Privacy Policy", description: "Edit privacy policy content.", href: "/admin/content/privacy-policy", api: "/content/privacy-policy" },
  { title: "Terms & Conditions", description: "Edit terms & conditions content.", href: "/admin/content/terms", api: "/content/terms" },
];

function getPreview(href: string, data: ContentData | null | undefined): string | null {
  if (!data) return null;
  switch (href) {
    case "/admin/content/hero":
      return data.title || null;
    case "/admin/content/about":
      return data.title || null;
    case "/admin/content/skills":
      return data.title && data.subtitle ? `${data.title} — ${data.subtitle}` : data.title || null;
    case "/admin/content/contact":
      return data.email && data.phone ? `${data.email} · ${data.phone}` : data.email || null;
    case "/admin/content/newsletter":
      return data.title || null;
    case "/admin/content/social":
      return data.linkedin ? "Connected" : null;
    case "/admin/content/privacy-policy":
      return data.lastUpdated ? `Last updated: ${data.lastUpdated}` : data.content ? "Content set" : "Not set yet";
    case "/admin/content/terms":
      return data.lastUpdated ? `Last updated: ${data.lastUpdated}` : data.content ? "Content set" : "Not set yet";
    default:
      if (data.title && data.subtitle) return `${data.title} — ${data.subtitle}`;
      return data.title || null;
  }
}

export default function AdminContentPage() {
  const results = useQueries({
    queries: sections.map((s) => ({
      queryKey: ["content-preview", s.api],
      queryFn: async (): Promise<ContentData | null> => {
        try {
          const res = await fetch(`/api${s.api}`);
          if (!res.ok) return null;
          const json = await res.json();
          return json.data ?? null;
        } catch {
          return null;
        }
      },
      staleTime: 30000,
    })),
  });

  return (
    <div className="space-y-6">
      <PageHeader
        title="Site Content"
        description="Manage static page content and site-wide settings."
        breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "Content", href: "/admin/content" }]}
      />
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {sections.map((s, i) => {
          const { data, isLoading } = results[i];
          const preview = getPreview(s.href, data);
          return (
            <Link key={s.href} href={s.href}>
              <Card className="h-full transition-colors hover:border-primary/40 hover:bg-muted/30">
                <CardContent className="space-y-2">
                  <div className="flex items-center justify-between">
                    <h3 className="font-heading text-base font-semibold text-foreground">{s.title}</h3>
                    <ExternalLink className="size-3.5 text-muted-foreground" />
                  </div>
                   <p className="text-sm text-muted-foreground line-clamp-2">{s.description}</p>
                  {isLoading ? (
                    <Skeleton className="h-4 w-3/4 rounded" />
                  ) : preview ? (
                    <p className="text-xs text-muted-foreground/70 line-clamp-2 italic">{preview}</p>
                  ) : null}
                </CardContent>
              </Card>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
