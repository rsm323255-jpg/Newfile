"use client";

import * as React from "react";
import { Skeleton } from "@/components/ui/skeleton";
import { PageHeader } from "@/components/admin/page-header";
import { AdminForm } from "@/components/admin/admin-form";
import { FormField, FormInput, FormTextarea } from "@/components/admin/form-field";
import { useAdminSingleton, useAdminUpdateSingleton } from "@/hooks/use-admin";
import type { ContactInfo } from "@/types";

export default function AdminContactContentPage() {
  const { data: item, isLoading } = useAdminSingleton<ContactInfo>("/content/contact");
  const updateMutation = useAdminUpdateSingleton<ContactInfo>("/content/contact");

  if (isLoading) return <div className="space-y-6"><Skeleton className="h-10 w-48" /><Skeleton className="h-4 w-72" /><div className="space-y-4"><Skeleton className="h-12 w-full rounded-xl" /><Skeleton className="h-12 w-full rounded-xl" /><Skeleton className="h-12 w-full rounded-xl" /></div></div>;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget as HTMLFormElement);
    await updateMutation.mutateAsync({
      eyebrow: fd.get("eyebrow") as string,
      title: fd.get("title") as string,
      subtitle: fd.get("subtitle") as string,
      email: fd.get("email") as string,
      phone: fd.get("phone") as string,
      address: fd.get("address") as string,
      workingHours: fd.get("workingHours") as string,
    });
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Edit Contact Info" breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "Content", href: "/admin/content" }, { label: "Contact", href: "/admin/content/contact" }]} />
      <AdminForm title="Contact Details" onSubmit={handleSubmit} loading={updateMutation.isPending} backHref="/admin/content" submitLabel="Update">
        <FormField label="Eyebrow" htmlFor="eyebrow" required><FormInput id="eyebrow" name="eyebrow" required defaultValue={item?.eyebrow} /></FormField>
        <FormField label="Title" htmlFor="title" required><FormInput id="title" name="title" required defaultValue={item?.title} /></FormField>
        <FormField label="Subtitle" htmlFor="subtitle" required><FormTextarea id="subtitle" name="subtitle" required defaultValue={item?.subtitle} /></FormField>
        <FormField label="Email" htmlFor="email" required><FormInput id="email" name="email" type="email" required defaultValue={item?.email} /></FormField>
        <FormField label="Phone" htmlFor="phone" required><FormInput id="phone" name="phone" required defaultValue={item?.phone} /></FormField>
        <FormField label="Address" htmlFor="address" required><FormInput id="address" name="address" required defaultValue={item?.address} /></FormField>
        <FormField label="Working Hours" htmlFor="workingHours"><FormInput id="workingHours" name="workingHours" defaultValue={item?.workingHours} /></FormField>
      </AdminForm>
    </div>
  );
}
