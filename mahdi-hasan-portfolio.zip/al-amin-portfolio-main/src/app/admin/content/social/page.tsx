"use client";

import * as React from "react";
import { Skeleton } from "@/components/ui/skeleton";
import { PageHeader } from "@/components/admin/page-header";
import { AdminForm } from "@/components/admin/admin-form";
import { FormField, FormInput } from "@/components/admin/form-field";
import { useAdminSingleton, useAdminUpdateSingleton } from "@/hooks/use-admin";
import type { SocialLinks } from "@/types";

export default function AdminSocialContentPage() {
  const { data: item, isLoading } = useAdminSingleton<SocialLinks>("/content/social");
  const updateMutation = useAdminUpdateSingleton<SocialLinks>("/content/social");

  if (isLoading) return <div className="space-y-6"><Skeleton className="h-10 w-48" /><Skeleton className="h-4 w-72" /><div className="space-y-4"><Skeleton className="h-12 w-full rounded-xl" /><Skeleton className="h-12 w-full rounded-xl" /></div></div>;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget as HTMLFormElement);
    await updateMutation.mutateAsync({
      linkedin: fd.get("linkedin") as string,
      instagram: fd.get("instagram") as string,
      facebook: fd.get("facebook") as string,
      tiktok: fd.get("tiktok") as string,
      twitter: fd.get("twitter") as string || undefined,
      youtube: fd.get("youtube") as string || undefined,
    });
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Edit Social Links" breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "Content", href: "/admin/content" }, { label: "Social", href: "/admin/content/social" }]} />
      <AdminForm title="Social Links" onSubmit={handleSubmit} loading={updateMutation.isPending} backHref="/admin/content" submitLabel="Update">
        <FormField label="LinkedIn" htmlFor="linkedin"><FormInput id="linkedin" name="linkedin" defaultValue={item?.linkedin} placeholder="https://linkedin.com/..." /></FormField>
        <FormField label="Instagram" htmlFor="instagram"><FormInput id="instagram" name="instagram" defaultValue={item?.instagram} placeholder="https://instagram.com/..." /></FormField>
        <FormField label="Facebook" htmlFor="facebook"><FormInput id="facebook" name="facebook" defaultValue={item?.facebook} placeholder="https://facebook.com/..." /></FormField>
        <FormField label="TikTok" htmlFor="tiktok"><FormInput id="tiktok" name="tiktok" defaultValue={item?.tiktok} placeholder="https://tiktok.com/..." /></FormField>
        <FormField label="Twitter / X" htmlFor="twitter"><FormInput id="twitter" name="twitter" defaultValue={item?.twitter} placeholder="https://x.com/..." /></FormField>
        <FormField label="YouTube" htmlFor="youtube"><FormInput id="youtube" name="youtube" defaultValue={item?.youtube} placeholder="https://youtube.com/..." /></FormField>
      </AdminForm>
    </div>
  );
}
