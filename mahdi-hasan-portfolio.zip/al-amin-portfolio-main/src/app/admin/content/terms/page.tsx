"use client";

import * as React from "react";
import { Skeleton } from "@/components/ui/skeleton";
import { PageHeader } from "@/components/admin/page-header";
import { AdminForm } from "@/components/admin/admin-form";
import { FormField, FormInput } from "@/components/admin/form-field";
import dynamic from "next/dynamic";

const TiptapEditor = dynamic(
  () => import("@/components/admin/tiptap-editor").then((m) => m.TiptapEditor),
  { ssr: false, loading: () => <div className="h-80 w-full animate-pulse rounded-xl bg-muted" /> }
);
import { useAdminSingleton, useAdminUpdateSingleton } from "@/hooks/use-admin";
import type { TermsData } from "@/types";

export default function AdminTermsContentPage() {
  const { data: item, isLoading } = useAdminSingleton<TermsData>("/content/terms");
  const updateMutation = useAdminUpdateSingleton<TermsData>("/content/terms");
  const [content, setContent] = React.useState("");

  React.useEffect(() => {
    if (item) setContent(item.content);
  }, [item]);

  if (isLoading) return <div className="space-y-6"><Skeleton className="h-10 w-48" /><Skeleton className="h-4 w-72" /><div className="space-y-4"><Skeleton className="h-12 w-full rounded-xl" /><Skeleton className="h-80 w-full rounded-xl" /><Skeleton className="h-12 w-full rounded-xl" /></div></div>;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget as HTMLFormElement);
    await updateMutation.mutateAsync({
      title: fd.get("title") as string,
      content,
      lastUpdated: fd.get("lastUpdated") as string,
    });
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Edit Terms & Conditions" breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "Content", href: "/admin/content" }, { label: "Terms & Conditions", href: "/admin/content/terms" }]} />
      <AdminForm title="Terms & Conditions Details" onSubmit={handleSubmit} loading={updateMutation.isPending} backHref="/admin/content" submitLabel="Update">
        <FormField label="Title" htmlFor="title" required><FormInput id="title" name="title" required defaultValue={item?.title} /></FormField>
        <FormField label="Content" htmlFor="content" required description="Use the editor to format your content">
          <TiptapEditor content={content} onChange={setContent} placeholder="Write your terms & conditions content..." />
        </FormField>
        <FormField label="Last Updated" htmlFor="lastUpdated" description="Display date, e.g. January 1, 2025"><FormInput id="lastUpdated" name="lastUpdated" defaultValue={item?.lastUpdated} placeholder="e.g. January 1, 2025" /></FormField>
      </AdminForm>
    </div>
  );
}
