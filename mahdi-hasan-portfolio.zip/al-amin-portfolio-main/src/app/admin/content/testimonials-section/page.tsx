"use client";

import * as React from "react";
import { Skeleton } from "@/components/ui/skeleton";
import toast from "react-hot-toast";
import { PageHeader } from "@/components/admin/page-header";
import { AdminForm } from "@/components/admin/admin-form";
import { FormField, FormInput, FormTextarea } from "@/components/admin/form-field";
import { useAdminSingleton, useAdminUpdateSingleton } from "@/hooks/use-admin";
import type { SectionSettings } from "@/types";

export default function AdminTestimonialsSectionPage() {
  const { data: item, isLoading } = useAdminSingleton<SectionSettings>("/content/testimonials-section");
  const updateMutation = useAdminUpdateSingleton<SectionSettings>("/content/testimonials-section");

  if (isLoading) return <div className="space-y-6"><Skeleton className="h-10 w-48" /><Skeleton className="h-4 w-72" /><div className="space-y-4"><Skeleton className="h-12 w-full rounded-xl" /><Skeleton className="h-12 w-full rounded-xl" /><Skeleton className="h-20 w-full rounded-xl" /></div></div>;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget as HTMLFormElement);
    try {
      await updateMutation.mutateAsync({
        eyebrow: fd.get("eyebrow") as string,
        title: fd.get("title") as string,
        subtitle: fd.get("subtitle") as string,
      });
    } catch {}
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Edit Testimonials Section" breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "Content", href: "/admin/content" }, { label: "Testimonials Section", href: "/admin/content/testimonials-section" }]} />
      <AdminForm title="Testimonials Section Details" onSubmit={handleSubmit} loading={updateMutation.isPending} backHref="/admin/content" submitLabel="Update">
        <FormField label="Eyebrow" htmlFor="eyebrow" required><FormInput id="eyebrow" name="eyebrow" required defaultValue={item?.eyebrow} /></FormField>
        <FormField label="Title" htmlFor="title" required><FormInput id="title" name="title" required defaultValue={item?.title} /></FormField>
        <FormField label="Subtitle" htmlFor="subtitle" required><FormTextarea id="subtitle" name="subtitle" required defaultValue={item?.subtitle} /></FormField>
      </AdminForm>
    </div>
  );
}
