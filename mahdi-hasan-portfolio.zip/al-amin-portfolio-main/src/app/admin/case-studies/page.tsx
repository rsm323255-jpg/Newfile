"use client";

import * as React from "react";
import Link from "next/link";
import { PageHeader } from "@/components/admin/page-header";
import { DataTable, type Column, type Action } from "@/components/admin/data-table";
import { ConfirmDialog } from "@/components/admin/confirm-dialog";
import { StatusBadge } from "@/components/admin/status-badge";
import { EmptyState } from "@/components/admin/empty-state";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useAdminList, useAdminDelete } from "@/hooks/use-admin";
import type { CaseStudy } from "@/types";

const columns: Column<CaseStudy>[] = [
  { key: "title", label: "Title" },
  { key: "client", label: "Client" },
  { key: "tags", label: "Tags", hideOnMobile: true, render: (v) => {
    const tags = v as string[];
    return <div className="flex flex-wrap gap-1">{tags.slice(0, 2).map((t) => <StatusBadge key={t} variant="default">{t}</StatusBadge>)}</div>;
  }},
];

export default function AdminCaseStudiesPage() {
  const { data, isLoading } = useAdminList<CaseStudy>("/case-studies");
  const deleteMutation = useAdminDelete("/case-studies");
  const [deleteId, setDeleteId] = React.useState<string | null>(null);

  const actions: Action<CaseStudy>[] = [
    { label: "Edit", href: (row) => `/admin/case-studies/${row.id}` },
    { label: "Delete", variant: "destructive", onClick: (row) => setDeleteId(row.id) },
  ];

  if (isLoading) return <div className="space-y-6"><Skeleton className="h-10 w-48" /><Skeleton className="h-4 w-72" /><div className="space-y-3"><Skeleton className="h-12 w-full rounded-xl" />{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-16 w-full rounded-xl" />)}</div></div>;

  return (
    <div className="space-y-6">
      <PageHeader title="Case Studies" description="Manage your case studies." breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "Case Studies", href: "/admin/case-studies" }]} action={{ label: "Add Case Study", href: "/admin/case-studies/new" }} />
      {data && data.length > 0 ? (
        <DataTable columns={columns} data={data} actions={actions} searchKey="title" searchPlaceholder="Search case studies..." />
      ) : (
        <EmptyState title="No case studies" description="Create your first case study." action={<Button asChild><Link href="/admin/case-studies/new">Add Case Study</Link></Button>} />
      )}
      <ConfirmDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)} title="Delete Case Study" description="This action cannot be undone." loading={deleteMutation.isPending} onConfirm={async () => { if (deleteId) { await deleteMutation.mutateAsync(deleteId); setDeleteId(null); } }} />
    </div>
  );
}
