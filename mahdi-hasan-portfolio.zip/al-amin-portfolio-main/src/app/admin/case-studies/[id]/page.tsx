"use client";

import * as React from "react";
import { useRouter, useParams } from "next/navigation";
import { Plus, Trash2 } from "lucide-react";
import { PageHeader } from "@/components/admin/page-header";
import { AdminForm } from "@/components/admin/admin-form";
import { FormField, FormInput, FormTextarea } from "@/components/admin/form-field";
import { ImageUpload } from "@/components/admin/image-upload";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useAdminDetail, useAdminUpdate } from "@/hooks/use-admin";
import type { CaseStudy } from "@/types";

export default function AdminCaseStudiesEditPage() {
  const router = useRouter();
  const params = useParams();
  const id = params.id as string;
  const { data: item, isLoading } = useAdminDetail<CaseStudy>("/case-studies", id);
  const updateMutation = useAdminUpdate<CaseStudy>("/case-studies");
  const [tags, setTags] = React.useState("");
  const [image, setImage] = React.useState("");
  const [results, setResults] = React.useState<{ before: string; after: string; metric: string }[]>([]);

  React.useEffect(() => {
    if (item) {
      setTags(item.tags.join(", "));
      setImage(item.image);
      setResults(item.results.map((r) => ({ ...r })));
    }
  }, [item]);

  if (isLoading) return <div className="space-y-6"><Skeleton className="h-10 w-48" /><Skeleton className="h-4 w-72" /><div className="space-y-4"><Skeleton className="h-12 w-full rounded-xl" /><Skeleton className="h-12 w-full rounded-xl" /><Skeleton className="h-40 w-full rounded-xl" /><Skeleton className="h-24 w-full rounded-xl" /></div></div>;

  function addResult() {
    setResults([...results, { before: "", after: "", metric: "" }]);
  }

  function removeResult(index: number) {
    setResults(results.filter((_, i) => i !== index));
  }

  function updateResult(index: number, field: "before" | "after" | "metric", val: string) {
    const updated = [...results];
    updated[index][field] = val;
    setResults(updated);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget as HTMLFormElement);
    await updateMutation.mutateAsync({
      id,
      data: {
        title: fd.get("title") as string,
        slug: fd.get("slug") as string || undefined,
        client: fd.get("client") as string,
        challenge: fd.get("challenge") as string,
        solution: fd.get("solution") as string,
        image,
        tags: tags.split(",").map((t) => t.trim()).filter(Boolean),
        results: results.filter((r) => r.metric && r.after),
      },
    });
    router.push("/admin/case-studies");
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Edit Case Study" breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "Case Studies", href: "/admin/case-studies" }, { label: "Edit", href: `/admin/case-studies/${id}` }]} />
      <AdminForm title="Case Study Details" onSubmit={handleSubmit} loading={updateMutation.isPending} backHref="/admin/case-studies" submitLabel="Update">
        <FormField label="Title" htmlFor="title" required><FormInput id="title" name="title" required defaultValue={item?.title} /></FormField>
        <FormField label="Slug" htmlFor="slug" description="Auto-generated from title if left empty"><FormInput id="slug" name="slug" defaultValue={item?.slug} /></FormField>
        <FormField label="Client" htmlFor="client" required><FormInput id="client" name="client" required defaultValue={item?.client} /></FormField>
        <FormField label="Image" htmlFor="image">
          <input type="hidden" name="image" value={image} />
          <ImageUpload value={image} onChange={setImage} folder="case-studies" />
        </FormField>
        <FormField label="Challenge" htmlFor="challenge" required><FormTextarea id="challenge" name="challenge" required defaultValue={item?.challenge} /></FormField>
        <FormField label="Solution" htmlFor="solution" required><FormTextarea id="solution" name="solution" required defaultValue={item?.solution} /></FormField>
        <FormField label="Tags" htmlFor="tags" description="Comma-separated"><FormInput id="tags" value={tags} onChange={(e) => setTags(e.target.value)} /></FormField>

        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-sm font-medium">Results</label>
            <Button type="button" variant="outline" size="sm" onClick={addResult}>
              <Plus className="size-3.5" />
              Add Result
            </Button>
          </div>
          {results.map((result, i) => (
            <div key={i} className="flex flex-col gap-2 sm:flex-row sm:items-center">
              <FormInput value={result.before} onChange={(e) => updateResult(i, "before", e.target.value)} placeholder="Before (e.g. $20K)" className="flex-1 min-w-0" />
              <FormInput value={result.after} onChange={(e) => updateResult(i, "after", e.target.value)} placeholder="After (e.g. $150K)" className="flex-1 min-w-0" />
              <FormInput value={result.metric} onChange={(e) => updateResult(i, "metric", e.target.value)} placeholder="Metric (e.g. Revenue)" className="flex-1 min-w-0" />
              <Button type="button" variant="ghost" size="sm" onClick={() => removeResult(i)} className="sm:mt-0 mt-1 self-start">
                <Trash2 className="size-4 text-destructive" />
              </Button>
            </div>
          ))}
        </div>
      </AdminForm>
    </div>
  );
}
