"use client";

import * as React from "react";
import Image from "next/image";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import {
  Upload,
  Trash2,
  Copy,
  Check,
  ImageIcon,
  Loader2,
  Search,
  Grid3X3,
  List,
  ChevronLeft,
  ChevronRight,
  X,
  AlertCircle,
} from "lucide-react";
import toast from "react-hot-toast";

import { PageHeader } from "@/components/admin/page-header";
import { Button } from "@/components/ui/button";
import { Modal } from "@/components/ui/modal";
import { Skeleton } from "@/components/ui/skeleton";
import { fadeUp, staggerContainer } from "@/components/common/motion";
import type { ApiResponse } from "@/types";

type MediaItem = {
  _id: string;
  url: string;
  publicId: string;
  filename: string;
  originalName: string;
  mimeType: string;
  size: number;
  folder: string;
  createdAt: string;
};

type MediaResponse = {
  items: MediaItem[];
  total: number;
  page: number;
  totalPages: number;
};

function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export default function AdminMediaPage() {
  const qc = useQueryClient();
  const [page, setPage] = React.useState(1);
  const [search, setSearch] = React.useState("");
  const [view, setView] = React.useState<"grid" | "list">("grid");
  const [preview, setPreview] = React.useState<MediaItem | null>(null);
  const [deleteItem, setDeleteItem] = React.useState<MediaItem | null>(null);
  const [dragActive, setDragActive] = React.useState(false);
  const [uploading, setUploading] = React.useState<File[]>([]);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const { data, isLoading } = useQuery({
    queryKey: ["admin", "media", page],
    queryFn: async () => {
      const res = await fetch(`/api/media?page=${page}&limit=24`);
      const json: ApiResponse<MediaResponse> = await res.json();
      if (!json.success) throw new Error(json.error ?? "Failed to fetch");
      return json.data!;
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (item: MediaItem) => {
      const res = await fetch("/api/media", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: item._id }),
      });
      const json: ApiResponse = await res.json();
      if (!json.success) throw new Error(json.error ?? "Failed to delete");
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin", "media"] });
      toast.success("Image deleted");
      setDeleteItem(null);
    },
    onError: (err: Error) => {
      toast.error(err.message);
    },
  });

  async function uploadFiles(files: FileList | File[]) {
    const fileArray = Array.from(files);
    const valid = fileArray.filter((f) => {
      if (f.size > 5 * 1024 * 1024) {
        toast.error(`${f.name} exceeds 5MB limit`);
        return false;
      }
      if (!["image/jpeg", "image/png", "image/webp", "image/gif"].includes(f.type)) {
        toast.error(`${f.name} is not a supported image type`);
        return false;
      }
      return true;
    });

    if (valid.length === 0) return;
    setUploading(valid);

    let successCount = 0;
    for (const file of valid) {
      try {
        const fd = new FormData();
        fd.append("file", file);
        fd.append("folder", "gallery");
        const res = await fetch("/api/upload", { method: "POST", body: fd });
        const json: ApiResponse = await res.json();
        if (json.success) successCount++;
        else toast.error(`${file.name}: ${json.error}`);
      } catch {
        toast.error(`Failed to upload ${file.name}`);
      }
    }

    setUploading([]);
    if (successCount > 0) {
      toast.success(`${successCount} image${successCount > 1 ? "s" : ""} uploaded`);
      qc.invalidateQueries({ queryKey: ["admin", "media"] });
    }
  }

  function handleDrop(e: React.DragEvent) {
    e.preventDefault();
    setDragActive(false);
    if (e.dataTransfer.files.length > 0) uploadFiles(e.dataTransfer.files);
  }

  function handleDragOver(e: React.DragEvent) {
    e.preventDefault();
    setDragActive(true);
  }

  function handleDragLeave(e: React.DragEvent) {
    e.preventDefault();
    setDragActive(false);
  }

  function copyUrl(url: string) {
    navigator.clipboard.writeText(url);
    toast.success("URL copied to clipboard");
  }

  const filteredItems = data?.items.filter((item) =>
    search ? item.originalName.toLowerCase().includes(search.toLowerCase()) : true
  );

  return (
    <div className="space-y-6">
      <PageHeader
        title="Media Library"
        description={`${data?.total ?? 0} images in your gallery`}
        breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "Media", href: "/admin/media" }]}
      />

      {/* Upload Zone */}
      <div
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onClick={() => fileInputRef.current?.click()}
        className={`relative cursor-pointer rounded-2xl border-2 border-dashed p-8 text-center transition-all sm:p-12 ${
          dragActive
            ? "border-primary bg-primary/5"
            : "border-border hover:border-primary/40 hover:bg-muted/50"
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept="image/jpeg,image/png,image/webp,image/gif"
          multiple
          className="hidden"
          onChange={(e) => {
            if (e.target.files) uploadFiles(e.target.files);
            e.target.value = "";
          }}
        />
        <div className="flex flex-col items-center gap-3">
          <div className={`flex size-14 items-center justify-center rounded-2xl transition-colors ${
            dragActive ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"
          }`}>
            <Upload className="size-6" />
          </div>
          <div>
            <p className="text-sm font-medium text-foreground">
              {dragActive ? "Drop images here" : "Click to upload or drag and drop"}
            </p>
            <p className="mt-1 text-xs text-muted-foreground">
              JPEG, PNG, WebP, GIF · Max 5MB each
            </p>
          </div>
        </div>
      </div>

      {/* Upload Progress */}
      <AnimatePresence>
        {uploading.length > 0 && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="rounded-2xl border border-border bg-card p-4">
              <div className="flex items-center gap-3">
                <Loader2 className="size-5 animate-spin text-primary" />
                <div>
                  <p className="text-sm font-medium text-foreground">
                    Uploading {uploading.length} image{uploading.length > 1 ? "s" : ""}...
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {uploading.map((f) => f.name).join(", ")}
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Toolbar */}
      {data && data.items.length > 0 && (
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search images..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="h-10 w-full rounded-xl border border-border bg-background pl-10 pr-4 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring/50"
            />
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant={view === "grid" ? "secondary" : "ghost"}
              size="icon"
              className="size-9"
              onClick={() => setView("grid")}
            >
              <Grid3X3 className="size-4" />
            </Button>
            <Button
              variant={view === "list" ? "secondary" : "ghost"}
              size="icon"
              className="size-9"
              onClick={() => setView("list")}
            >
              <List className="size-4" />
            </Button>
          </div>
        </div>
      )}

      {/* Gallery Grid */}
      {isLoading ? (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <Skeleton key={i} className="aspect-square rounded-2xl" />
          ))}
        </div>
      ) : filteredItems && filteredItems.length > 0 ? (
        <>
          {view === "grid" ? (
            <motion.div
              className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4"
              initial="hidden"
              animate="visible"
              variants={staggerContainer}
            >
              {filteredItems.map((item) => (
                <motion.div
                  key={item._id}
                  variants={fadeUp}
                  className="group relative aspect-square overflow-hidden rounded-2xl border border-border bg-muted"
                >
                  <Image
                    src={item.url}
                    alt={item.originalName}
                    fill
                    sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
                    className="object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 transition-opacity group-hover:opacity-100" />
                  <div className="absolute bottom-0 left-0 right-0 p-3 opacity-0 transition-opacity group-hover:opacity-100">
                    <p className="truncate text-xs font-medium text-white">
                      {item.originalName}
                    </p>
                    <p className="text-xs text-white/70">
                      {formatFileSize(item.size)}
                    </p>
                  </div>
                  <div className="absolute top-2 right-2 flex gap-1.5 opacity-0 transition-opacity group-hover:opacity-100">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setPreview(item);
                      }}
                      className="flex size-8 items-center justify-center rounded-lg bg-black/50 text-white backdrop-blur-sm transition-colors hover:bg-black/70"
                    >
                      <ImageIcon className="size-3.5" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        copyUrl(item.url);
                      }}
                      className="flex size-8 items-center justify-center rounded-lg bg-black/50 text-white backdrop-blur-sm transition-colors hover:bg-black/70"
                    >
                      <Copy className="size-3.5" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setDeleteItem(item);
                      }}
                      className="flex size-8 items-center justify-center rounded-lg bg-black/50 text-white backdrop-blur-sm transition-colors hover:bg-red-500/80"
                    >
                      <Trash2 className="size-3.5" />
                    </button>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          ) : (
            <div className="space-y-2">
              {filteredItems.map((item) => (
                <div
                  key={item._id}
                  className="flex items-center gap-4 rounded-xl border border-border bg-card p-3 transition-colors hover:border-primary/20"
                >
                  <div className="relative size-16 shrink-0 overflow-hidden rounded-lg">
                    <Image
                      src={item.url}
                      alt={item.originalName}
                      fill
                      sizes="64px"
                      className="object-cover"
                    />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium text-foreground">
                      {item.originalName}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {formatFileSize(item.size)} · {item.mimeType.split("/")[1].toUpperCase()}
                    </p>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="size-8"
                      onClick={() => copyUrl(item.url)}
                    >
                      <Copy className="size-3.5" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="size-8 text-muted-foreground hover:text-red-500"
                      onClick={() => setDeleteItem(item)}
                    >
                      <Trash2 className="size-3.5" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Pagination */}
          {data && data.totalPages > 1 && (
            <div className="flex items-center justify-center gap-2 pt-4">
              <Button
                variant="outline"
                size="icon"
                className="size-9"
                disabled={page <= 1}
                onClick={() => setPage((p) => p - 1)}
              >
                <ChevronLeft className="size-4" />
              </Button>
              <span className="text-sm text-muted-foreground">
                Page {page} of {data.totalPages}
              </span>
              <Button
                variant="outline"
                size="icon"
                className="size-9"
                disabled={page >= data.totalPages}
                onClick={() => setPage((p) => p + 1)}
              >
                <ChevronRight className="size-4" />
              </Button>
            </div>
          )}
        </>
      ) : (
        <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-border py-16">
          <ImageIcon className="size-10 text-muted-foreground/40" />
          <p className="mt-4 text-sm font-medium text-muted-foreground">
            {search ? "No images match your search" : "No images yet"}
          </p>
          <p className="mt-1 text-xs text-muted-foreground/70">
            {search ? "Try a different search term" : "Upload your first image above"}
          </p>
        </div>
      )}

      {/* Preview Modal */}
      <Modal open={!!preview} onClose={() => setPreview(null)} ariaLabel="Image preview">
        {preview && (
          <div className="overflow-hidden">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={preview.url}
              alt={preview.originalName}
              className="w-full object-contain"
              style={{ maxHeight: "70vh" }}
            />
            <div className="border-t border-border p-4 sm:p-6">
              <div className="flex items-start justify-between gap-4">
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium text-foreground">
                    {preview.originalName}
                  </p>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {formatFileSize(preview.size)} · {preview.mimeType.split("/")[1].toUpperCase()} · {new Date(preview.createdAt).toLocaleDateString()}
                  </p>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => copyUrl(preview.url)}>
                    <Copy className="mr-1.5 size-3.5" />
                    Copy URL
                  </Button>
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => {
                      setDeleteItem(preview);
                      setPreview(null);
                    }}
                  >
                    <Trash2 className="mr-1.5 size-3.5" />
                    Delete
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}
      </Modal>

      {/* Delete Confirmation */}
      <Modal open={!!deleteItem} onClose={() => setDeleteItem(null)} ariaLabel="Delete image">
        <div className="p-6 sm:p-8">
          <div className="flex size-12 items-center justify-center rounded-2xl bg-red-500/10">
            <AlertCircle className="size-6 text-red-500" />
          </div>
          <h3 className="mt-4 font-heading text-lg font-bold text-foreground">
            Delete image?
          </h3>
          <p className="mt-2 text-sm text-muted-foreground">
            &ldquo;{deleteItem?.originalName}&rdquo; will be permanently removed from your gallery and Cloudinary.
          </p>
          <div className="mt-6 flex justify-end gap-3">
            <Button variant="outline" onClick={() => setDeleteItem(null)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              disabled={deleteMutation.isPending}
              onClick={() => deleteItem && deleteMutation.mutate(deleteItem)}
            >
              {deleteMutation.isPending ? (
                <Loader2 className="mr-1.5 size-4 animate-spin" />
              ) : (
                <Trash2 className="mr-1.5 size-4" />
              )}
              Delete
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
