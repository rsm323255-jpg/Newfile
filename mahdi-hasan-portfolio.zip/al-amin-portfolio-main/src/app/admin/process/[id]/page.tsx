"use client";

import * as React from "react";
import { useRouter, useParams } from "next/navigation";
import { Skeleton } from "@/components/ui/skeleton";
import { PageHeader } from "@/components/admin/page-header";
import { AdminForm } from "@/components/admin/admin-form";
import { FormField, FormInput, FormTextarea } from "@/components/admin/form-field";
import { useAdminDetail, useAdminUpdate } from "@/hooks/use-admin";
import type { ProcessStep } from "@/types";

export default function AdminProcessEditPage() {
  const router = useRouter();
  const params = useParams();
  const id = params.id as string;
  const { data: item, isLoading } = useAdminDetail<ProcessStep>("/process", id);
  const updateMutation = useAdminUpdate<ProcessStep>("/process");

  if (isLoading) return <div className="space-y-6"><Skeleton className="h-10 w-48" /><Skeleton className="h-4 w-72" /><div className="space-y-4"><Skeleton className="h-12 w-full rounded-xl" /><Skeleton className="h-12 w-full rounded-xl" /><Skeleton className="h-24 w-full rounded-xl" /></div></div>;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget as HTMLFormElement);
    await updateMutation.mutateAsync({ id, data: { title: fd.get("title") as string, description: fd.get("description") as string, icon: fd.get("icon") as string } });
    router.push("/admin/process");
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Edit Step" breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "Process", href: "/admin/process" }, { label: "Edit", href: `/admin/process/${id}` }]} />
      <AdminForm title="Step Details" onSubmit={handleSubmit} loading={updateMutation.isPending} backHref="/admin/process" submitLabel="Update">
        <FormField label="Title" htmlFor="title" required><FormInput id="title" name="title" required defaultValue={item?.title} /></FormField>
        <FormField label="Icon (Emoji)" htmlFor="icon"><FormInput id="icon" name="icon" defaultValue={item?.icon} /></FormField>
        <FormField label="Description" htmlFor="description" required><FormTextarea id="description" name="description" required defaultValue={item?.description} /></FormField>
      </AdminForm>
    </div>
  );
}
