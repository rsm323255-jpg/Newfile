"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { PageHeader } from "@/components/admin/page-header";
import { AdminForm } from "@/components/admin/admin-form";
import { FormField, FormInput, FormTextarea } from "@/components/admin/form-field";
import { useAdminCreate } from "@/hooks/use-admin";
import type { ProcessStep } from "@/types";

export default function AdminProcessNewPage() {
  const router = useRouter();
  const createMutation = useAdminCreate<ProcessStep>("/process");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget as HTMLFormElement);
    await createMutation.mutateAsync({ title: fd.get("title") as string, description: fd.get("description") as string, icon: fd.get("icon") as string });
    router.push("/admin/process");
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Add Process Step" breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "Process", href: "/admin/process" }, { label: "New", href: "/admin/process/new" }]} />
      <AdminForm title="Step Details" onSubmit={handleSubmit} loading={createMutation.isPending} backHref="/admin/process">
        <FormField label="Title" htmlFor="title" required><FormInput id="title" name="title" required placeholder="e.g. Discovery" /></FormField>
        <FormField label="Icon (Emoji)" htmlFor="icon"><FormInput id="icon" name="icon" placeholder="e.g. 🔍" /></FormField>
        <FormField label="Description" htmlFor="description" required><FormTextarea id="description" name="description" required placeholder="Describe this step..." /></FormField>
      </AdminForm>
    </div>
  );
}
