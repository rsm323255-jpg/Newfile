"use client";

import * as React from "react";
import Link from "next/link";
import { PageHeader } from "@/components/admin/page-header";
import { DataTable, type Column, type Action } from "@/components/admin/data-table";
import { ConfirmDialog } from "@/components/admin/confirm-dialog";
import { EmptyState } from "@/components/admin/empty-state";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useAdminList, useAdminDelete } from "@/hooks/use-admin";
import type { ProcessStep } from "@/types";

const columns: Column<ProcessStep>[] = [
  { key: "icon", label: "Icon", render: (v) => <span className="text-xl">{String(v)}</span> },
  { key: "title", label: "Title" },
  { key: "description", label: "Description", render: (v) => <span className="line-clamp-1">{String(v)}</span> },
];

export default function AdminProcessPage() {
  const { data, isLoading } = useAdminList<ProcessStep>("/process");
  const deleteMutation = useAdminDelete("/process");
  const [deleteId, setDeleteId] = React.useState<string | null>(null);

  const actions: Action<ProcessStep>[] = [
    { label: "Edit", href: (row) => `/admin/process/${row.id}` },
    { label: "Delete", variant: "destructive", onClick: (row) => setDeleteId(row.id) },
  ];

  if (isLoading) return <div className="space-y-6"><Skeleton className="h-10 w-48" /><Skeleton className="h-4 w-72" /><div className="space-y-3"><Skeleton className="h-12 w-full rounded-xl" />{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-16 w-full rounded-xl" />)}</div></div>;

  return (
    <div className="space-y-6">
      <PageHeader title="Process" description="Manage your process steps." breadcrumbs={[{ label: "Admin", href: "/admin" }, { label: "Process", href: "/admin/process" }]} action={{ label: "Add Step", href: "/admin/process/new" }} />
      {data && data.length > 0 ? (
        <DataTable columns={columns} data={data} actions={actions} searchKey="title" searchPlaceholder="Search process..." />
      ) : (
        <EmptyState title="No process steps" description="Add your first step." action={<Button asChild><Link href="/admin/process/new">Add Step</Link></Button>} />
      )}
      <ConfirmDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)} title="Delete Step" description="This action cannot be undone." loading={deleteMutation.isPending} onConfirm={async () => { if (deleteId) { await deleteMutation.mutateAsync(deleteId); setDeleteId(null); } }} />
    </div>
  );
}
