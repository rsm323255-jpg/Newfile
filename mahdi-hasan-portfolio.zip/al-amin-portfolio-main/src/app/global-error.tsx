"use client";

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <html lang="en">
      <body className="flex min-h-screen flex-col items-center justify-center bg-background px-6 text-foreground">
        <div className="flex flex-col items-center text-center">
          <p className="font-mono text-sm font-medium uppercase tracking-[0.3em] text-destructive">
            Critical error
          </p>
          <h1 className="mt-4 text-4xl font-bold tracking-tight sm:text-5xl">
            Something went terribly wrong
          </h1>
          <p className="mt-4 max-w-md text-muted-foreground">
            We hit an unexpected error while loading the application.
            {error.digest ? ` Error reference: ${error.digest}` : ""}
          </p>
          <button
            onClick={() => reset()}
            className="mt-8 inline-flex h-12 items-center justify-center rounded-xl bg-primary px-7 text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/25 transition-all hover:bg-primary/90"
          >
            Try Again
          </button>
        </div>
      </body>
    </html>
  );
}
