import type { Metadata } from "next";
import { siteConfig } from "@/config/site";

import { HeroSection } from "@/components/sections/hero";
import { ClientsSection } from "@/components/sections/clients";
import { SkillsSection } from "@/components/sections/skills";
import { AboutSection } from "@/components/sections/about";
import { ProcessSection } from "@/components/sections/process";
import { PortfolioSection } from "@/components/sections/portfolio";
import { TestimonialsSection } from "@/components/sections/testimonials";
import { FAQSection } from "@/components/sections/faq";
import { ContactSection } from "@/components/sections/contact";
import { CtaBand } from "@/components/sections/cta-band";
import { getHero } from "@/services";

export const dynamic = "force-dynamic";

export async function generateMetadata(): Promise<Metadata> {
  const hero = await getHero();
  return {
    title: hero.subtitle,
    description: hero.description,
    alternates: {
      canonical: "/",
    },
    openGraph: {
      title: hero.subtitle,
      description: hero.description,
      url: "/",
      images: [
        {
          url: siteConfig.ogImage,
          width: 1200,
          height: 630,
          alt: `${siteConfig.name} - Media Buyer & Paid Advertising Consultant`,
        },
      ],
    },
    twitter: {
      card: "summary_large_image",
      title: hero.subtitle,
      description: hero.description,
      images: [siteConfig.ogImage],
    },
  };
}

const personJsonLd = {
  "@context": "https://schema.org",
  "@type": "Person",
  name: siteConfig.name,
  jobTitle: siteConfig.author.role,
  url: siteConfig.url,
  email: siteConfig.author.email,
  image: `${siteConfig.url}${siteConfig.ogImage}`,
  description: siteConfig.description,
  sameAs: Object.values(siteConfig.social),
  knowsAbout: ["Media Buying", "Paid Advertising", "Campaign Strategy", "Performance Marketing", "Growth Strategy"],
};

export default function Home() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(personJsonLd) }}
      />
      <HeroSection />
      <ClientsSection />
      <AboutSection />
      <SkillsSection />
      <PortfolioSection />
      <ProcessSection />
      <TestimonialsSection />
      <FAQSection />
      <CtaBand />
      <ContactSection />
    </>
  );
}
