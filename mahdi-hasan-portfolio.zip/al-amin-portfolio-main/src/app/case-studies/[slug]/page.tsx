import type { Metadata } from "next";
import { notFound } from "next/navigation";

import { CaseStudyDetail } from "@/components/sections/case-study-detail";
import { getCaseStudies, getCaseStudyBySlug } from "@/services";
import { siteConfig } from "@/config/site";

export const dynamic = "force-dynamic";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const study = await getCaseStudyBySlug(slug);
  if (!study) return { title: "Case Study Not Found" };

  return {
    title: `${study.title} | Mahdi Hasan`,
    description: study.challenge,
    alternates: {
      canonical: `/case-studies/${slug}`,
    },
    openGraph: {
      title: study.title,
      description: study.challenge,
      url: `/case-studies/${slug}`,
      type: "article",
      authors: [siteConfig.name],
      images: [
        {
          url: study.image || siteConfig.ogImage,
          width: 1200,
          height: 630,
          alt: study.title,
        },
      ],
    },
    twitter: {
      card: "summary_large_image",
      title: study.title,
      description: study.challenge,
      images: [study.image || siteConfig.ogImage],
    },
  };
}

export default async function CaseStudyPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const study = await getCaseStudyBySlug(slug);
  const allStudies = await getCaseStudies();

  if (!study) {
    notFound();
  }

  const index = allStudies.findIndex((s) => s.slug === study.slug);
  const nextStudy = allStudies[(index + 1) % allStudies.length];

  const articleJsonLd = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: study.title,
    description: study.challenge,
    image: study.image || siteConfig.ogImage,
    author: {
      "@type": "Person",
      name: siteConfig.name,
      url: siteConfig.url,
    },
    publisher: {
      "@type": "Organization",
      name: siteConfig.name,
      logo: {
        "@type": "ImageObject",
        url: `${siteConfig.url}${siteConfig.ogImage}`,
      },
    },
    mainEntityOfPage: {
      "@type": "WebPage",
      "@id": `${siteConfig.url}/case-studies/${slug}`,
    },
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(articleJsonLd) }}
      />
      <CaseStudyDetail study={study} nextStudy={nextStudy} />
    </>
  );
}
