import { Skeleton } from "@/components/ui/skeleton";
import { Container } from "@/components/ui/container";

export default function CaseStudyLoading() {
  return (
    <article className="py-16 sm:py-20">
      <Container>
        <div className="mx-auto max-w-4xl">
          <Skeleton className="h-4 w-40 rounded-md" />
          <div className="mt-8 flex gap-2">
            <Skeleton className="h-6 w-20 rounded-full" />
            <Skeleton className="h-6 w-24 rounded-full" />
          </div>
          <Skeleton className="mt-5 h-12 w-full max-w-2xl rounded-2xl" />
          <Skeleton className="mt-4 h-5 w-48 rounded-lg" />
          <Skeleton className="mt-10 aspect-video w-full rounded-3xl" />
          <div className="mt-12 grid grid-cols-1 gap-6 lg:grid-cols-2">
            <Skeleton className="h-56 rounded-3xl" />
            <Skeleton className="h-56 rounded-3xl" />
          </div>
          <Skeleton className="mt-6 h-56 w-full rounded-3xl" />
        </div>
      </Container>
    </article>
  );
}
