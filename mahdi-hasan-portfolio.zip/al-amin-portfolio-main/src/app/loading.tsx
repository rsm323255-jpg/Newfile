import { PageSkeleton } from "@/components/common/skeleton-loaders";

export default function Loading() {
  return <PageSkeleton />;
}
