import { Metadata } from "next";
import { siteConfig } from "@/config/site";

export const dynamic = "force-dynamic";
import { getTerms } from "@/services";
import { PageHeader } from "@/components/common/page-header";
import { Container } from "@/components/ui/container";

export const metadata: Metadata = {
  title: `Terms & Conditions | ${siteConfig.name}`,
  description: `Terms and conditions for ${siteConfig.name}. Read our terms of service.`,
  alternates: {
    canonical: "/terms",
  },
  robots: {
    index: false,
    follow: true,
  },
};

export default async function TermsPage() {
  const data = await getTerms();

  return (
    <main className="min-h-screen">
      <PageHeader
        eyebrow="Legal"
        title={data.title}
        description="Terms governing the use of this website and our services."
      />
      <Container className="py-16 sm:py-20">
        <div className="mx-auto max-w-4xl">
          <div className="rounded-2xl border border-border bg-card p-6 shadow-sm sm:p-10 lg:p-12">
            {data.content ? (
              <div
                className="prose prose-slate max-w-none dark:prose-invert
                  prose-headings:font-heading prose-headings:tracking-tight
                  prose-h2:mt-10 prose-h2:mb-4 prose-h2:text-xl prose-h2:font-semibold prose-h2:text-foreground
                  prose-h3:mt-8 prose-h3:mb-3 prose-h3:text-base prose-h3:font-semibold prose-h3:text-foreground
                  prose-p:leading-relaxed prose-p:text-muted-foreground
                  prose-li:leading-relaxed prose-li:text-muted-foreground
                  prose-strong:text-foreground
                  prose-a:text-primary prose-a:no-underline hover:prose-a:underline
                  prose-ul:my-4 prose-ol:my-4
                  prose-li:my-1.5"
                dangerouslySetInnerHTML={{ __html: data.content }}
              />
            ) : (
              <p className="text-muted-foreground">
                Terms & conditions content has not been set yet. Please contact the administrator.
              </p>
            )}
          </div>
        </div>
      </Container>
    </main>
  );
}
