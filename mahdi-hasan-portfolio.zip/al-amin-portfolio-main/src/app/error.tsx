"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";
import { AlertTriangle, RefreshCw } from "lucide-react";

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <main className="flex min-h-[70vh] flex-col items-center justify-center px-6">
      <div className="flex flex-col items-center text-center">
        <div className="flex size-20 items-center justify-center rounded-2xl bg-destructive/10">
          <AlertTriangle className="size-9 text-destructive" />
        </div>
        <h1 className="mt-6 text-balance text-3xl font-bold tracking-tight sm:text-4xl">
          Something went wrong
        </h1>
        <p className="mt-3 max-w-md text-muted-foreground">
          An unexpected error occurred while rendering this page.
          {error.digest ? ` Error reference: ${error.digest}` : ""}
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-4">
          <Button onClick={() => reset()}>
            <RefreshCw className="mr-2 size-4" />
            Try Again
          </Button>
          <Button variant="outline" asChild>
            <Link href="/">Back to Home</Link>
          </Button>
        </div>
      </div>
    </main>
  );
}
