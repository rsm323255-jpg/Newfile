"use client";

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import toast from "react-hot-toast";
import type { ApiResponse } from "@/types";

const API_BASE = "/api";

let isRefreshing = false;
let refreshPromise: Promise<boolean> | null = null;

async function tryRefresh(): Promise<boolean> {
  if (isRefreshing && refreshPromise) return refreshPromise;

  isRefreshing = true;
  refreshPromise = (async () => {
    try {
      const res = await fetch(`${API_BASE}/auth/refresh`, { method: "POST" });
      const json = await res.json();
      return json.success === true;
    } catch {
      return false;
    } finally {
      isRefreshing = false;
      refreshPromise = null;
    }
  })();

  return refreshPromise;
}

async function fetchWithRefresh(url: string, options?: RequestInit): Promise<Response> {
  const res = await fetch(url, options);

  if (res.status === 401 && !url.includes("/auth/")) {
    const refreshed = await tryRefresh();
    if (refreshed) {
      return fetch(url, options);
    }
    // Refresh failed — redirect to login
    if (typeof window !== "undefined") {
      window.location.href = "/admin/login";
    }
  }

  return res;
}

async function logActivity(
  action: string,
  entity: string,
  data?: { entityId?: string; entityTitle?: string; details?: string }
) {
  try {
    fetch(`${API_BASE}/activity`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action,
        entity,
        entityId: data?.entityId,
        entityTitle: data?.entityTitle,
        details: data?.details,
      }),
    }).catch(() => {});
  } catch {
    // fire-and-forget, never block
  }
}

export function useAdminList<T>(endpoint: string) {
  return useQuery({
    queryKey: ["admin", endpoint],
    queryFn: async () => {
      const res = await fetchWithRefresh(`${API_BASE}${endpoint}`);
      const json: ApiResponse<T[]> = await res.json();
      if (!json.success) throw new Error(json.error ?? "Failed to fetch");
      return json.data ?? [];
    },
  });
}

export function useAdminDetail<T>(endpoint: string, id: string | null) {
  return useQuery({
    queryKey: ["admin", endpoint, id],
    queryFn: async () => {
      if (!id) return null;
      const res = await fetchWithRefresh(`${API_BASE}${endpoint}/${id}`);
      const json: ApiResponse<T> = await res.json();
      if (!json.success) throw new Error(json.error ?? "Failed to fetch");
      return json.data ?? null;
    },
    enabled: !!id,
  });
}

export function useAdminSingleton<T>(endpoint: string) {
  return useQuery({
    queryKey: ["admin", endpoint],
    queryFn: async () => {
      const res = await fetchWithRefresh(`${API_BASE}${endpoint}`);
      const json: ApiResponse<T> = await res.json();
      if (!json.success) throw new Error(json.error ?? "Failed to fetch");
      return json.data ?? null;
    },
  });
}

export function useAdminCreate<T>(endpoint: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (data: Partial<T>) => {
      const res = await fetchWithRefresh(`${API_BASE}${endpoint}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const json: ApiResponse<T> = await res.json();
      if (!json.success) throw new Error(json.error ?? "Failed to create");
      return json.data;
    },
    onSuccess: (result) => {
      qc.invalidateQueries({ queryKey: ["admin", endpoint] });
      toast.success("Created successfully");
      const title = (result as Record<string, unknown>)?.title || (result as Record<string, unknown>)?.name || "";
      logActivity("created", endpoint.replace(/^\//, ""), {
        entityTitle: String(title),
      });
    },
    onError: (err: Error) => {
      toast.error(err.message || "Failed to create");
    },
  });
}

export function useAdminUpdate<T>(endpoint: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<T> }) => {
      const res = await fetchWithRefresh(`${API_BASE}${endpoint}/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const json: ApiResponse<T> = await res.json();
      if (!json.success) throw new Error(json.error ?? "Failed to update");
      return json.data;
    },
    onSuccess: (result, variables) => {
      qc.invalidateQueries({ queryKey: ["admin", endpoint] });
      toast.success("Updated successfully");
      const title = (result as Record<string, unknown>)?.title || (result as Record<string, unknown>)?.name || "";
      logActivity("updated", endpoint.replace(/^\//, ""), {
        entityId: variables.id,
        entityTitle: String(title),
      });
    },
    onError: (err: Error) => {
      toast.error(err.message || "Failed to update");
    },
  });
}

export function useAdminDelete(endpoint: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const res = await fetchWithRefresh(`${API_BASE}${endpoint}/${id}`, {
        method: "DELETE",
      });
      const json: ApiResponse = await res.json();
      if (!json.success) throw new Error(json.error ?? "Failed to delete");
    },
    onSuccess: (_result, id) => {
      qc.invalidateQueries({ queryKey: ["admin", endpoint] });
      toast.success("Deleted successfully");
      logActivity("deleted", endpoint.replace(/^\//, ""), {
        entityId: id,
      });
    },
    onError: (err: Error) => {
      toast.error(err.message || "Failed to delete");
    },
  });
}

export function useAdminUpdateSingleton<T>(endpoint: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (data: T) => {
      const res = await fetchWithRefresh(`${API_BASE}${endpoint}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const json: ApiResponse<T> = await res.json();
      if (!json.success) throw new Error(json.error ?? "Failed to update");
      return json.data;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin", endpoint] });
      toast.success("Updated successfully");
      logActivity("updated", endpoint.replace(/^\//, ""), {});
    },
    onError: (err: Error) => {
      toast.error(err.message || "Failed to update");
    },
  });
}
