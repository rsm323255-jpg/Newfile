"use client";

import { createApi, fetchBaseQuery, type BaseQueryFn, type FetchArgs } from "@reduxjs/toolkit/query/react";
import type { RootState } from "@/store";

interface AuthUser {
  userId: string;
  email: string;
  name: string;
  role: "admin" | "editor" | "viewer";
}

interface LoginRequest {
  email: string;
  password: string;
}

interface AuthResponse {
  success: boolean;
  data?: {
    user: AuthUser;
    accessToken: string;
    refreshToken: string;
  };
  error?: string;
}

interface RefreshResponse {
  success: boolean;
  data?: {
    accessToken: string;
    refreshToken: string;
  };
  error?: string;
}

interface LogoutResponse {
  success: boolean;
}

let isRefreshing = false;
let failedQueue: Array<{
  resolve: (value: unknown) => void;
  reject: (reason?: unknown) => void;
}> = [];

function processQueue(error: unknown | null) {
  failedQueue.forEach((prom) => {
    if (error) {
      prom.reject(error);
    } else {
      prom.resolve(undefined);
    }
  });
  failedQueue = [];
}

const baseQueryWithReauth: BaseQueryFn<
  string | FetchArgs,
  unknown,
  unknown
> = async (args, api, extraOptions) => {
  const baseQuery = fetchBaseQuery({
    baseUrl: "/api/auth",
    credentials: "include",
    prepareHeaders: (headers) => {
      // Auth is purely cookie-based; no Bearer header needed
      return headers;
    },
  });

  const result = await baseQuery(args, api, extraOptions);

  if (result.error && (result.error as { status?: number }).status === 401) {
    // Don't try to refresh if this IS the refresh or login endpoint
    const url = typeof args === "string" ? args : args.url;
    if (url === "/refresh" || url === "/login") {
      return result;
    }

    if (!isRefreshing) {
      isRefreshing = true;

      try {
        const refreshResult = await baseQuery(
          { url: "/refresh", method: "POST" },
          api,
          extraOptions
        );

        if (refreshResult.error) {
          processQueue(refreshResult.error);
          // Refresh failed — clear auth and redirect to login
          api.dispatch({ type: "auth/clearAuth" });
          if (typeof window !== "undefined") {
            window.location.href = "/admin/login";
          }
          return refreshResult;
        }

        processQueue(null);
      } catch (err) {
        processQueue(err);
        api.dispatch({ type: "auth/clearAuth" });
        if (typeof window !== "undefined") {
          window.location.href = "/admin/login";
        }
        return { error: { status: 401, data: "Refresh failed" } };
      } finally {
        isRefreshing = false;
      }
    } else {
      // Already refreshing — queue this request
      return new Promise((resolve, reject) => {
        failedQueue.push({ resolve, reject });
      }).then(() => baseQuery(args, api, extraOptions));
    }

    // Retry the original request with new cookies
    return baseQuery(args, api, extraOptions);
  }

  return result;
};

export const authApi = createApi({
  reducerPath: "authApi",
  baseQuery: baseQueryWithReauth,
  tagTypes: ["Auth"],
  endpoints: (builder) => ({
    login: builder.mutation<AuthResponse, LoginRequest>({
      query: (credentials) => ({
        url: "/login",
        method: "POST",
        body: credentials,
      }),
    }),
    logout: builder.mutation<LogoutResponse, void>({
      query: () => ({
        url: "/logout",
        method: "POST",
      }),
    }),
    refreshToken: builder.mutation<RefreshResponse, void>({
      query: () => ({
        url: "/refresh",
        method: "POST",
      }),
    }),
    getMe: builder.query<{ success: boolean; data?: AuthUser }, void>({
      query: () => ({
        url: "/me",
        method: "GET",
      }),
      providesTags: ["Auth"],
    }),
  }),
});

export const {
  useLoginMutation,
  useLogoutMutation,
  useRefreshTokenMutation,
  useGetMeQuery,
} = authApi;
