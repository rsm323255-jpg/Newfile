import { NextRequest, NextResponse } from "next/server";
import { jwtVerify } from "jose";
import { checkDdos, isBlocked } from "@/lib/rate-limit";

const JWT_SECRET = new TextEncoder().encode(
  process.env.JWT_SECRET ?? "jwt-secret-key-for-dev-only-change-in-production"
);

const ACCESS_TOKEN_COOKIE = "admin_access_token";
const REFRESH_TOKEN_COOKIE = "admin_refresh_token";
const ADMIN_LOGIN_PATH = "/admin/login";
const ADMIN_PATH = "/admin";

async function getAccessTokenPayload(request: NextRequest) {
  const token = request.cookies.get(ACCESS_TOKEN_COOKIE)?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET);
    if (payload.type !== "access") return null;
    return payload;
  } catch {
    return null;
  }
}

async function hasValidRefreshToken(request: NextRequest) {
  const token = request.cookies.get(REFRESH_TOKEN_COOKIE)?.value;
  if (!token) return false;
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET);
    return payload.type === "refresh";
  } catch {
    return false;
  }
}

function addSecurityHeaders(response: NextResponse, request: NextRequest): NextResponse {
  const isProduction = process.env.NODE_ENV === "production";
  const origin = request.nextUrl.origin;

  // Prevent clickjacking
  response.headers.set("X-Frame-Options", "DENY");

  // Prevent MIME type sniffing
  response.headers.set("X-Content-Type-Options", "nosniff");

  // XSS protection
  response.headers.set("X-XSS-Protection", "1; mode=block");

  // Referrer policy
  response.headers.set("Referrer-Policy", "strict-origin-when-cross-origin");

  // Permissions policy — disable camera, microphone, geolocation
  response.headers.set(
    "Permissions-Policy",
    "camera=(), microphone=(), geolocation=(), interest-cohort=()"
  );

  // HSTS (production only)
  if (isProduction) {
    response.headers.set(
      "Strict-Transport-Security",
      "max-age=63072000; includeSubDomains; preload"
    );
  }

  // Content Security Policy
  const cspDirectives = [
    "default-src 'self'",
    "script-src 'self' 'unsafe-eval' 'unsafe-inline'",
    "style-src 'self' 'unsafe-inline'",
    "img-src 'self' data: blob: https://res.cloudinary.com",
    "font-src 'self'",
    "connect-src 'self'",
    "frame-ancestors 'none'",
    "base-uri 'self'",
    "form-action 'self'",
  ].join("; ");

  response.headers.set("Content-Security-Policy", cspDirectives);

  // Remove server identification
  response.headers.delete("X-Powered-By");
  response.headers.delete("Server");

  return response;
}

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // ─── DDoS Protection ────────────────────────────────────────
  const ip =
    request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    request.headers.get("x-real-ip") ||
    "127.0.0.1";

  // Hard block known attack IPs
  if (await isBlocked(ip)) {
    return new NextResponse("Too Many Requests", {
      status: 429,
      headers: { "Retry-After": "60" },
    });
  }

  // Check for burst/DDoS on API routes
  if (pathname.startsWith("/api/")) {
    const ddos = await checkDdos(request);
    if (ddos.blocked) {
      return new NextResponse("Service Temporarily Unavailable", {
        status: 503,
        headers: { "Retry-After": "30" },
      });
    }
  }

  // ─── Admin Route Protection ─────────────────────────────────
  if (!pathname.startsWith(ADMIN_PATH)) {
    const response = NextResponse.next();
    addSecurityHeaders(response, request);
    return response;
  }

  if (pathname === ADMIN_LOGIN_PATH) {
    const hasAccess = await getAccessTokenPayload(request);
    if (hasAccess) {
      return NextResponse.redirect(new URL("/admin", request.url));
    }
    const response = NextResponse.next();
    addSecurityHeaders(response, request);
    return response;
  }

  // Check for valid access token
  const hasAccess = await getAccessTokenPayload(request);
  if (hasAccess) {
    const response = NextResponse.next();
    addSecurityHeaders(response, request);
    return response;
  }

  // If access token expired, check for refresh token
  const hasRefresh = await hasValidRefreshToken(request);
  if (hasRefresh) {
    const response = NextResponse.next();
    addSecurityHeaders(response, request);
    return response;
  }

  // No valid tokens - redirect to login
  const loginUrl = new URL(ADMIN_LOGIN_PATH, request.url);
  loginUrl.searchParams.set("from", pathname);
  return NextResponse.redirect(loginUrl);
}

export const config = {
  matcher: [
    /*
     * Match all request paths except:
     * - _next/static (static files)
     * - _next/image (image optimization)
     * - favicon.ico (browser favicon)
     * - public files
     */
    "/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)",
  ],
};
