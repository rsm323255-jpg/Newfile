import { CaseStudy } from "@/types";

// Intentionally empty until real, approved case studies are available.
export const caseStudies: CaseStudy[] = [];

export default caseStudies;
