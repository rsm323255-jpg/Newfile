export const newsletterData = {
  title: "Paid ads, structured",
  description: "Occasional frameworks and breakdowns on media buying and growth.",
  button: "Subscribe",
};

export type NewsletterData = typeof newsletterData;
