export const socialLinks = {
  linkedin: "https://www.linkedin.com/in/mahdi-hasan100",
};

export default socialLinks;
