import { FAQItem } from "@/types";

export const faqItems: FAQItem[] = [
  {
    id: "f1",
    question: "What does a media buyer and paid advertising consultant do?",
    answer:
      "I plan, launch, and optimize paid advertising campaigns, and build the structure around them: audiences, funnel, creative testing, and reporting, so ad spend turns into predictable growth.",
  },
  {
    id: "f2",
    question: "How do you approach a new campaign?",
    answer:
      "Structure first, creativity second. I start with your goals and current setup, build a media plan and funnel structure, then launch with a testing plan so every result teaches us something.",
  },
  {
    id: "f3",
    question: "How do you measure success?",
    answer:
      "Against the goals we agree up front. Reporting leads with the result and the takeaway, uses specific numbers rather than adjectives, and ends with what we do next.",
  },
  {
    id: "f4",
    question: "What do you need from me to get started?",
    answer:
      "A short discovery call, plus access to your current ad accounts and tracking if they exist. If you are starting from scratch, we plan the foundations together.",
  },
  {
    id: "f5",
    question: "Do you offer consulting without full campaign management?",
    answer:
      "Yes. Strategy sessions, account reviews, and frameworks are available on their own. Tell me what you need in the contact form and I'll suggest the right format.",
  },
  {
    id: "f6",
    question: "How do I get in touch?",
    answer:
      "Use the contact form below or email hello@mahdihasan.co. You can also connect with me on LinkedIn.",
  },
];

export default faqItems;
