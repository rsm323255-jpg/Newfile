import { Testimonial } from "@/types";

// Intentionally empty: the Testimonials section is hidden until genuine, approved testimonials are added
// (via the admin panel or here).
export const testimonials: Testimonial[] = [];

export default testimonials;
