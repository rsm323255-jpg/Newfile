import { AboutData } from "@/types";

// Content pillars from the Brand Design Kit (value = pillar number, label = pillar).
const achievements = [
  { id: "a1", value: "01", label: "Media Buying & Paid Advertising" },
  { id: "a2", value: "02", label: "Vision & Inspiration" },
  { id: "a3", value: "03", label: "Business Podcasts & Video" },
  { id: "a4", value: "04", label: "Growth & Professional Insight" },
];

export const aboutData: AboutData = {
  title: "Strategic vision. Structured growth.",
  description:
    "I'm an independent media buyer and paid advertising consultant. I help businesses that need paid advertising to actually perform, turning ad spend into a structured, repeatable growth system, and I share the thinking behind it in public. Clarity over noise: structure first, creativity second.",
  mission: "Structure first",
  missionContent:
    "A media plan, a funnel, a framework a client can actually run on. Discipline turns instinct into a repeatable system.",
  vision: "Innovation always",
  visionContent:
    "Seeing opportunity before others do: testing new platforms and formats, and bringing a fresh angle to paid media.",
  experience: "",
  image: "",
  achievements,
};

export default aboutData;
