import { ProcessStep } from "@/types";

export const processSteps: ProcessStep[] = [
  {
    id: "ps1",
    title: "Discovery Call",
    description:
      "We talk through your business, offer, current ad setup, and what you want paid advertising to achieve.",
    icon: "📞",
  },
  {
    id: "ps2",
    title: "Audit & Research",
    description:
      "I review your accounts, tracking, audience, and market so the plan is built on evidence, not assumptions.",
    icon: "🔍",
  },
  {
    id: "ps3",
    title: "Strategy & Media Plan",
    description:
      "A structured plan: platforms, budget allocation, funnel stages, creative angles, and the metrics that matter.",
    icon: "📋",
  },
  {
    id: "ps4",
    title: "Campaign Launch",
    description:
      "Campaigns go live with clean structure, correct tracking, and a testing plan ready from day one.",
    icon: "🚀",
  },
  {
    id: "ps5",
    title: "Optimize & Scale",
    description:
      "Results are reviewed against the plan, learnings feed the next round of tests, and what works gets scaled.",
    icon: "⚙️",
  },
];

export default processSteps;
