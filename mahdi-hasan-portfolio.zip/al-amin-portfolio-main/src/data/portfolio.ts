import { PortfolioItem } from "@/types";

/**
 * PLACEHOLDERS: replace with real, approved campaign results (via the admin panel or this file).
 * Items with `placeholder: true` render as clearly-labelled templates, with no invented numbers.
 */
export const portfolioItems: PortfolioItem[] = [
  {
    id: "p1",
    title: "Campaign result: add your first case",
    slug: "placeholder-campaign-1",
    category: "Paid Advertising",
    image: "",
    description:
      "Placeholder. Add the goal, the structure you built, and the measurable outcome (for example, a CPA or ROAS change) with the client's approval.",
    tags: ["Platform", "Industry", "Objective"],
    results: [
      { metric: "Metric", value: "—" },
      { metric: "Metric", value: "—" },
    ],
    placeholder: true,
  },
  {
    id: "p2",
    title: "Funnel structure: add your second case",
    slug: "placeholder-campaign-2",
    category: "Funnel Structure",
    image: "",
    description:
      "Placeholder. Describe the funnel or framework, what changed, and what the client could run on afterwards.",
    tags: ["Funnel", "Testing", "Reporting"],
    results: [
      { metric: "Metric", value: "—" },
      { metric: "Metric", value: "—" },
    ],
    placeholder: true,
  },
  {
    id: "p3",
    title: "Creative testing: add your third case",
    slug: "placeholder-campaign-3",
    category: "Creative Testing",
    image: "",
    description:
      "Placeholder. Show the test plan, the learnings, and the result with a screenshot or dashboard export.",
    tags: ["Creative", "Testing", "Learnings"],
    results: [
      { metric: "Metric", value: "—" },
      { metric: "Metric", value: "—" },
    ],
    placeholder: true,
  },
];

export default portfolioItems;
