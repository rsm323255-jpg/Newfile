import { HeroData } from "@/types";

const stats = [
  { id: "h1", value: "Structure first", label: "Every campaign starts with a plan you can actually run on.", suffix: "" },
  { id: "h2", value: "Numbers over adjectives", label: "Specific metrics and clear takeaways, never vague hype.", suffix: "" },
  { id: "h3", value: "Built in public", label: "The thinking behind the work, shared openly.", suffix: "" },
];

export const heroData: HeroData = {
  title: "Turn ad spend into a structured, repeatable growth system.",
  subtitle: "Media Buyer & Paid Advertising Consultant",
  description:
    "I work directly with businesses to plan, launch, and optimize paid campaigns across major platforms, with the same structure-first discipline behind every decision.",
  ctaPrimary: "Book a Consultation",
  ctaSecondary: "See How I Work",
  image: "",
  stats,
};

export default heroData;
