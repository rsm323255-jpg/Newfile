import { Skill } from "@/types";

// Services are drafted from the Brand Design Kit's positioning and content pillars.
// Review and edit the wording to match your exact offer.
export const skills: Skill[] = [
  {
    id: "s1",
    title: "Campaign Strategy & Media Planning",
    description:
      "A clear plan before any budget is spent: objectives, audiences, platforms, and a media plan you can run on.",
    icon: "🎯",
    features: ["Goal & KPI alignment", "Platform and budget allocation", "Funnel structure"],
  },
  {
    id: "s2",
    title: "Paid Campaign Management",
    description:
      "Hands-on launch and day-to-day management of paid advertising campaigns across major platforms.",
    icon: "📊",
    features: ["Campaign build & launch", "Audience and placement testing", "Ongoing optimization"],
  },
  {
    id: "s3",
    title: "Creative Testing Frameworks",
    description:
      "A structured way to test creative so you know what is working, what is fatiguing, and what to try next.",
    icon: "🎨",
    features: ["Test plans & naming structure", "Creative fatigue signals", "Learnings you can reuse"],
  },
  {
    id: "s4",
    title: "Performance Reporting",
    description:
      "Reporting that leads with the result and the takeaway, with specifics instead of adjectives.",
    icon: "📈",
    features: ["Clear metric definitions", "Performance breakdowns", "Next-step recommendations"],
  },
  {
    id: "s5",
    title: "Growth Consulting",
    description:
      "Practical guidance on scaling paid advertising, working with clients, and growing a business or freelance practice.",
    icon: "🎪",
    features: ["Strategy sessions", "Account & funnel reviews", "Frameworks and checklists"],
  },
  {
    id: "s6",
    title: "Podcasts & Video",
    description:
      "Long-form conversations and video on media buying, business, and growth, putting a voice behind the work.",
    icon: "📱",
    features: ["Podcast appearances", "Video breakdowns", "Behind-the-scenes of building campaigns"],
  },
];

export default skills;
