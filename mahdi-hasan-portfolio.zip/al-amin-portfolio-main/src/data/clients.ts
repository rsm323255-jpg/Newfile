import { Client } from "@/types";

// "Clients" slot is reused as a focus-areas marquee until real client logos are approved for display.
const names = [
  "Media Buying",
  "Paid Advertising",
  "Campaign Strategy",
  "Funnel Structure",
  "Creative Testing",
  "Performance Reporting",
  "Growth Consulting",
  "Podcasts & Video",
];

export const clients: Client[] = names.map((n, i) => ({
  id: `cl${i + 1}`,
  name: n,
  logo: n,
}));

export default clients;
