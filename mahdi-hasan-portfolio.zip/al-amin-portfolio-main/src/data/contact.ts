import { ContactInfo } from "@/types";

export const contactInfo: ContactInfo = {
  eyebrow: "Get in touch",
  title: "Let's build your growth system",
  subtitle:
    "Tell me about your business and what you want paid advertising to do. I'll reply with clear next steps.",
  email: "hello@mahdihasan.co",
  phone: "",
  address: "",
  workingHours: "",
};

export default contactInfo;
