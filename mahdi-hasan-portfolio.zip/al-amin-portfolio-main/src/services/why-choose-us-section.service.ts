import "server-only";
import { connectToDatabase } from "@/lib/mongodb";
import { WhyChooseUsSectionModel } from "@/models";
import type { SectionSettings } from "@/types";

const defaultData: SectionSettings = {
  eyebrow: "Why Choose Us",
  title: "The Unfair Advantage Behind Every Campaign",
  subtitle: "I combine creative storytelling with data-driven precision to deliver results that actually matter to your bottom line.",
};

export async function getWhyChooseUsSection(): Promise<SectionSettings> {
  try {
    await connectToDatabase();
    const data = await WhyChooseUsSectionModel.findOne({ isPublished: true }).sort({ updatedAt: -1 }).lean();
    if (data) {
      return { eyebrow: data.eyebrow || defaultData.eyebrow, title: data.title || defaultData.title, subtitle: data.subtitle || defaultData.subtitle };
    }
  } catch {}
  return defaultData;
}
