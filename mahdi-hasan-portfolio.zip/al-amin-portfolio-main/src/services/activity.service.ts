import "server-only";
import { connectToDatabase } from "@/lib/mongodb";
import { ActivityModel } from "@/models";

interface LogActivityParams {
  action: string;
  entity: string;
  entityId?: string;
  entityTitle?: string;
  userId: string;
  userName: string;
  details?: string;
}

export async function logActivity(params: LogActivityParams): Promise<void> {
  try {
    await connectToDatabase();
    await ActivityModel.create({
      action: params.action,
      entity: params.entity,
      entityId: params.entityId,
      entityTitle: params.entityTitle,
      userId: params.userId,
      userName: params.userName,
      details: params.details,
    });
  } catch {
    // silently fail — activity logging should never break the main flow
  }
}
