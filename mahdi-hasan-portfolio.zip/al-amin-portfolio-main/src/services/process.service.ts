import "server-only";
import { connectToDatabase } from "@/lib/mongodb";
import { ProcessStepModel } from "@/models";
import { processSteps } from "@/data/process";
import type { ProcessStep } from "@/types";

export async function getProcess(): Promise<ProcessStep[]> {
  try {
    await connectToDatabase();
    const items = await ProcessStepModel.find({ isPublished: true }).sort({ order: 1, createdAt: -1 }).lean();
    if (items.length > 0) {
      return items.map((item) => ({
        id: String(item._id),
        title: item.title,
        description: item.description,
        icon: item.icon,
      }));
    }
  } catch {
    // fall through to static data
  }
  return processSteps;
}
