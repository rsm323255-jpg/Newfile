import "server-only";
import { connectToDatabase } from "@/lib/mongodb";
import { ClientsSectionModel } from "@/models";
import type { SectionSettings } from "@/types";

const defaultData: SectionSettings = {
  eyebrow: "Focus Areas",
  title: "Where the work happens",
  subtitle: "Media buying and paid advertising, built on structure.",
};

export async function getClientsSection(): Promise<SectionSettings> {
  try {
    await connectToDatabase();
    const data = await ClientsSectionModel.findOne({ isPublished: true }).sort({ updatedAt: -1 }).lean();
    if (data) {
      return { eyebrow: data.eyebrow || defaultData.eyebrow, title: data.title || defaultData.title, subtitle: data.subtitle || defaultData.subtitle };
    }
  } catch {}
  return defaultData;
}
