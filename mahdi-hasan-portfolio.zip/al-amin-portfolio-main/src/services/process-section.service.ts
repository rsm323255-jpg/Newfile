import "server-only";
import { connectToDatabase } from "@/lib/mongodb";
import { ProcessSectionModel } from "@/models";
import type { SectionSettings } from "@/types";

const defaultData: SectionSettings = {
  eyebrow: "How I Work",
  title: "A five-step marketing engine",
  subtitle: "Structure first, creativity second. A clear, repeatable process from first call to scaled results.",
};

export async function getProcessSection(): Promise<SectionSettings> {
  try {
    await connectToDatabase();
    const data = await ProcessSectionModel.findOne({ isPublished: true }).sort({ updatedAt: -1 }).lean();
    if (data) {
      return { eyebrow: data.eyebrow || defaultData.eyebrow, title: data.title || defaultData.title, subtitle: data.subtitle || defaultData.subtitle };
    }
  } catch {}
  return defaultData;
}
