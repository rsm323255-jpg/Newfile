import "server-only";
import { connectToDatabase } from "@/lib/mongodb";
import { TeamSectionModel } from "@/models";
import type { SectionSettings } from "@/types";

const defaultData: SectionSettings = {
  eyebrow: "Our Team",
  title: "The People Behind the Strategy",
  subtitle: "A dedicated team of marketers, creatives, and strategists committed to your growth.",
};

export async function getTeamSection(): Promise<SectionSettings> {
  try {
    await connectToDatabase();
    const data = await TeamSectionModel.findOne({ isPublished: true }).sort({ updatedAt: -1 }).lean();
    if (data) {
      return { eyebrow: data.eyebrow || defaultData.eyebrow, title: data.title || defaultData.title, subtitle: data.subtitle || defaultData.subtitle };
    }
  } catch {}
  return defaultData;
}
