import "server-only";
import { connectToDatabase } from "@/lib/mongodb";
import { CaseStudiesSectionModel } from "@/models";
import type { SectionSettings } from "@/types";

const defaultData: SectionSettings = {
  eyebrow: "Case Studies",
  title: "Campaigns, in depth.",
  subtitle: "Deep-dive stories on the structure behind the results. Added as real, approved case studies become available.",
};

export async function getCaseStudiesSection(): Promise<SectionSettings> {
  try {
    await connectToDatabase();
    const data = await CaseStudiesSectionModel.findOne({ isPublished: true }).sort({ updatedAt: -1 }).lean();
    if (data) {
      return { eyebrow: data.eyebrow || defaultData.eyebrow, title: data.title || defaultData.title, subtitle: data.subtitle || defaultData.subtitle };
    }
  } catch {}
  return defaultData;
}
