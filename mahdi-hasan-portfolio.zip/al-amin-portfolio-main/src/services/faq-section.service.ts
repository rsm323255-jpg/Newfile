import "server-only";
import { connectToDatabase } from "@/lib/mongodb";
import { FAQSectionModel } from "@/models";
import type { SectionSettings } from "@/types";

const defaultData: SectionSettings = {
  eyebrow: "FAQ",
  title: "Frequently asked questions",
  subtitle: "Straight answers before we start working together.",
};

export async function getFAQSection(): Promise<SectionSettings> {
  try {
    await connectToDatabase();
    const data = await FAQSectionModel.findOne({ isPublished: true }).sort({ updatedAt: -1 }).lean();
    if (data) {
      return { eyebrow: data.eyebrow || defaultData.eyebrow, title: data.title || defaultData.title, subtitle: data.subtitle || defaultData.subtitle };
    }
  } catch {}
  return defaultData;
}
