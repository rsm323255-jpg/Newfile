import "server-only";
import { connectToDatabase } from "@/lib/mongodb";
import { StatisticsSectionModel } from "@/models";
import type { SectionSettings } from "@/types";

const defaultData: SectionSettings = {
  eyebrow: "Track Record",
  title: "Numbers That Speak for Themselves",
  subtitle: "Every metric represents a brand that trusted me to turn their marketing spend into real growth.",
};

export async function getStatisticsSection(): Promise<SectionSettings> {
  try {
    await connectToDatabase();
    const data = await StatisticsSectionModel.findOne({ isPublished: true }).sort({ updatedAt: -1 }).lean();
    if (data) {
      return { eyebrow: data.eyebrow || defaultData.eyebrow, title: data.title || defaultData.title, subtitle: data.subtitle || defaultData.subtitle };
    }
  } catch {}
  return defaultData;
}
