import "server-only";
import { connectToDatabase } from "@/lib/mongodb";
import { SocialLinksModel } from "@/models";
import { socialLinks } from "@/data/social";
import type { SocialLinks } from "@/types";

export async function getSocialLinks(): Promise<SocialLinks> {
  try {
    await connectToDatabase();
    const data = await SocialLinksModel.findOne({ isPublished: true }).sort({ updatedAt: -1 }).lean();
    if (data) {
      return {
        linkedin: data.linkedin,
        instagram: data.instagram,
        facebook: data.facebook,
        tiktok: data.tiktok,
        twitter: data.twitter,
        youtube: data.youtube,
      };
    }
  } catch {
    // fall through to static data
  }
  return socialLinks;
}
