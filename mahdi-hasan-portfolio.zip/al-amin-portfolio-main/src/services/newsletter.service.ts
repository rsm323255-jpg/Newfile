import "server-only";
import { connectToDatabase } from "@/lib/mongodb";
import { NewsletterModel } from "@/models";
import { newsletterData } from "@/data/newsletter";
import type { NewsletterData } from "@/types";

export async function getNewsletter(): Promise<NewsletterData> {
  try {
    await connectToDatabase();
    const data = await NewsletterModel.findOne({ isPublished: true }).sort({ updatedAt: -1 }).lean();
    if (data) {
      return {
        title: data.title,
        description: data.description,
        button: data.button,
      };
    }
  } catch {
    // fall through to static data
  }
  return newsletterData;
}
