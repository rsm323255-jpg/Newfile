import "server-only";
import { connectToDatabase } from "@/lib/mongodb";
import { PrivacyPolicyModel } from "@/models";

const fallback = {
  title: "Privacy Policy",
  content: "",
  lastUpdated: "",
};

export async function getPrivacyPolicy() {
  try {
    await connectToDatabase();
    const data = await PrivacyPolicyModel.findOne({ isPublished: true }).sort({ updatedAt: -1 }).lean();
    if (data) {
      return {
        title: data.title,
        content: data.content,
        lastUpdated: data.lastUpdated,
      };
    }
  } catch {
    // fall through
  }
  return fallback;
}
