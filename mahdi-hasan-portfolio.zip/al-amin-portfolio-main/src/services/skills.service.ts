import "server-only";
import { connectToDatabase } from "@/lib/mongodb";
import { SkillModel } from "@/models";
import { skills } from "@/data/skills";
import type { Skill } from "@/types";

export async function getSkills(): Promise<Skill[]> {
  try {
    await connectToDatabase();
    const dbSkills = await SkillModel.find({ isPublished: true }).sort({ order: 1, createdAt: -1 }).lean();
    if (dbSkills.length > 0) {
      return dbSkills.map((s) => ({
        id: String(s._id),
        title: s.title,
        description: s.description,
        icon: s.icon,
        features: s.features,
      }));
    }
  } catch {
    // fall through to static data
  }
  return skills;
}

export async function getSkill(id: string): Promise<Skill | null> {
  try {
    await connectToDatabase();
    const s = await SkillModel.findById(id).lean();
    if (s) {
      return {
        id: String(s._id),
        title: s.title,
        description: s.description,
        icon: s.icon,
        features: s.features,
      };
    }
  } catch {
    // fall through
  }
  return null;
}
