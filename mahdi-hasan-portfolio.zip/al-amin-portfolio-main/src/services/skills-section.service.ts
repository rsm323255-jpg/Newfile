import "server-only";
import { connectToDatabase } from "@/lib/mongodb";
import { SkillsSectionModel } from "@/models";
import type { SkillsSectionData } from "@/types";

const defaultData: SkillsSectionData = {
  eyebrow: "Services",
  title: "Media buying, built on structure",
  subtitle: "From media plan to optimization, every engagement is designed to be clear, measurable, and repeatable.",
};

export async function getSkillsSection(): Promise<SkillsSectionData> {
  try {
    await connectToDatabase();
    const data = await SkillsSectionModel.findOne({ isPublished: true }).sort({ updatedAt: -1 }).lean();
    if (data) {
      return {
        eyebrow: data.eyebrow || defaultData.eyebrow,
        title: data.title || defaultData.title,
        subtitle: data.subtitle || defaultData.subtitle,
      };
    }
  } catch {
    // fall through to default
  }
  return defaultData;
}
