import "server-only";
import { connectToDatabase } from "@/lib/mongodb";
import { ClientModel } from "@/models";
import { clients } from "@/data/clients";
import type { Client } from "@/types";

export async function getClients(): Promise<Client[]> {
  try {
    await connectToDatabase();
    const items = await ClientModel.find({ isPublished: true }).sort({ order: 1, createdAt: -1 }).lean();
    if (items.length > 0) {
      return items.map((item) => ({
        id: String(item._id),
        name: item.name,
        logo: item.logo,
        website: item.website,
      }));
    }
  } catch {
    // fall through to static data
  }
  return clients;
}
