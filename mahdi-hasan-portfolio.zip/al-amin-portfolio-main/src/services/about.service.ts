import "server-only";
import { connectToDatabase } from "@/lib/mongodb";
import { AboutModel } from "@/models";
import { aboutData } from "@/data/about";
import type { AboutData } from "@/types";

export async function getAbout(): Promise<AboutData> {
  try {
    await connectToDatabase();
    const about = await AboutModel.findOne({ isPublished: true }).sort({ updatedAt: -1 }).lean();
    if (about) {
      return {
        title: about.title,
        description: about.description,
        mission: about.mission,
        missionContent: about.missionContent || "",
        vision: about.vision,
        visionContent: about.visionContent || "",
        experience: about.experience,
        image: about.image,
        achievements: about.achievements.map((s) => ({
          id: s.id,
          value: s.value,
          label: s.label,
          suffix: s.suffix,
        })),
      };
    }
  } catch {
    // fall through to static data
  }
  return aboutData;
}
