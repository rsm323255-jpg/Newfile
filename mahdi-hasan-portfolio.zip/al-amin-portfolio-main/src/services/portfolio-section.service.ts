import "server-only";
import { connectToDatabase } from "@/lib/mongodb";
import { PortfolioSectionModel } from "@/models";
import type { SectionSettings } from "@/types";

const defaultData: SectionSettings = {
  eyebrow: "Selected Work",
  title: "Results, shown with the numbers",
  subtitle: "Real campaign results, with the structure behind them. The cards below are placeholders until approved results are added.",
};

export async function getPortfolioSection(): Promise<SectionSettings> {
  try {
    await connectToDatabase();
    const data = await PortfolioSectionModel.findOne({ isPublished: true }).sort({ updatedAt: -1 }).lean();
    if (data) {
      return { eyebrow: data.eyebrow || defaultData.eyebrow, title: data.title || defaultData.title, subtitle: data.subtitle || defaultData.subtitle };
    }
  } catch {}
  return defaultData;
}
