import "server-only";
import { connectToDatabase } from "@/lib/mongodb";
import { TermsModel } from "@/models";

const fallback = {
  title: "Terms & Conditions",
  content: "",
  lastUpdated: "",
};

export async function getTerms() {
  try {
    await connectToDatabase();
    const data = await TermsModel.findOne({ isPublished: true }).sort({ updatedAt: -1 }).lean();
    if (data) {
      return {
        title: data.title,
        content: data.content,
        lastUpdated: data.lastUpdated,
      };
    }
  } catch {
    // fall through
  }
  return fallback;
}
