import "server-only";
import { connectToDatabase } from "@/lib/mongodb";
import { TeamMemberModel } from "@/models";
import { TeamMember } from "@/types";

export async function getTeam(): Promise<TeamMember[]> {
  await connectToDatabase();
  const members = await TeamMemberModel.find({ isPublished: true }).sort({ order: 1, createdAt: -1 }).lean();
  return members.map((m) => ({
    id: String(m._id),
    name: m.name,
    role: m.role,
    bio: m.bio,
    avatar: m.avatar,
    social: m.social,
  }));
}
