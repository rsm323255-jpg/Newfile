import "server-only";
import { connectToDatabase } from "@/lib/mongodb";
import { TestimonialsSectionModel } from "@/models";
import type { SectionSettings } from "@/types";

const defaultData: SectionSettings = {
  eyebrow: "Testimonials",
  title: "What clients say",
  subtitle: "Words from the people I have worked with.",
};

export async function getTestimonialsSection(): Promise<SectionSettings> {
  try {
    await connectToDatabase();
    const data = await TestimonialsSectionModel.findOne({ isPublished: true }).sort({ updatedAt: -1 }).lean();
    if (data) {
      return { eyebrow: data.eyebrow || defaultData.eyebrow, title: data.title || defaultData.title, subtitle: data.subtitle || defaultData.subtitle };
    }
  } catch {}
  return defaultData;
}
