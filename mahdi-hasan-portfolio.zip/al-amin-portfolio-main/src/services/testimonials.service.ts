import "server-only";
import { connectToDatabase } from "@/lib/mongodb";
import { TestimonialModel } from "@/models";
import { testimonials } from "@/data/testimonials";
import type { Testimonial } from "@/types";

export async function getTestimonials(): Promise<Testimonial[]> {
  try {
    await connectToDatabase();
    const items = await TestimonialModel.find({ isPublished: true }).sort({ order: 1, createdAt: -1 }).lean();
    if (items.length > 0) {
      return items.map((item) => ({
        id: String(item._id),
        name: item.name,
        role: item.role,
        company: item.company,
        content: item.content,
        avatar: item.avatar,
        rating: item.rating,
      }));
    }
  } catch {
    // fall through to static data
  }
  return testimonials;
}
