import "server-only";
import { connectToDatabase } from "@/lib/mongodb";
import { ContactModel } from "@/models";
import { contactInfo } from "@/data/contact";
import type { ContactInfo } from "@/types";

export async function getContact(): Promise<ContactInfo> {
  try {
    await connectToDatabase();
    const data = await ContactModel.findOne({ isPublished: true }).sort({ updatedAt: -1 }).lean();
    if (data) {
      return {
        eyebrow: data.eyebrow || "Contact",
        title: data.title || "Let's build your growth system",
        subtitle: data.subtitle || "Tell me about your business and what you want paid advertising to do. I'll reply with clear next steps.",
        email: data.email,
        phone: data.phone,
        address: data.address,
        workingHours: data.workingHours,
      };
    }
  } catch {
    // fall through to static data
  }
  return contactInfo;
}
