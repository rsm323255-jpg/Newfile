import "server-only";
import { connectToDatabase } from "@/lib/mongodb";
import { StatisticModel } from "@/models";
import { Statistic } from "@/types";

export async function getStatistics(): Promise<Statistic[]> {
  await connectToDatabase();
  const stats = await StatisticModel.find({ isPublished: true }).sort({ order: 1, createdAt: -1 }).lean();
  return stats.map((s) => ({
    id: String(s._id),
    value: s.value,
    label: s.label,
    suffix: s.suffix,
  }));
}
