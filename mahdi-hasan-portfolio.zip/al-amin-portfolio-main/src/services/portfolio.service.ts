import "server-only";
import { connectToDatabase } from "@/lib/mongodb";
import { PortfolioModel } from "@/models";
import { portfolioItems } from "@/data/portfolio";
import type { PortfolioItem } from "@/types";

export async function getPortfolio(): Promise<PortfolioItem[]> {
  try {
    await connectToDatabase();
    const items = await PortfolioModel.find({ isPublished: true }).sort({ order: 1, createdAt: -1 }).lean();
    if (items.length > 0) {
      return items.map((item) => ({
        id: String(item._id),
        title: item.title,
        slug: item.slug,
        category: item.category,
        image: item.image,
        description: item.description,
        tags: item.tags,
        results: item.results,
      }));
    }
  } catch {
    // fall through to static data
  }
  return portfolioItems;
}
