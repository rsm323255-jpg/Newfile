import "server-only";
import { connectToDatabase } from "@/lib/mongodb";
import { FAQModel } from "@/models";
import { faqItems } from "@/data/faq";
import type { FAQItem } from "@/types";

export async function getFAQ(): Promise<FAQItem[]> {
  try {
    await connectToDatabase();
    const items = await FAQModel.find({ isPublished: true }).sort({ order: 1, createdAt: -1 }).lean();
    if (items.length > 0) {
      return items.map((item) => ({
        id: String(item._id),
        question: item.question,
        answer: item.answer,
      }));
    }
  } catch {
    // fall through to static data
  }
  return faqItems;
}
