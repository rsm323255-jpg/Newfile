import "server-only";
import { connectToDatabase } from "@/lib/mongodb";
import { HeroModel } from "@/models";
import { heroData } from "@/data/hero";
import type { HeroData } from "@/types";

export async function getHero(): Promise<HeroData> {
  try {
    await connectToDatabase();
    const hero = await HeroModel.findOne({ isPublished: true }).sort({ updatedAt: -1 }).lean();
    if (hero) {
      return {
        title: hero.title,
        subtitle: hero.subtitle,
        description: hero.description,
        ctaPrimary: hero.ctaPrimary,
        ctaSecondary: hero.ctaSecondary,
        image: hero.image,
        stats: hero.stats.map((s) => ({
          id: s.id,
          value: s.value,
          label: s.label,
          suffix: s.suffix,
        })),
      };
    }
  } catch {
    // fall through to static data
  }
  return heroData;
}
