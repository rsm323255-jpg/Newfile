import "server-only";
import { connectToDatabase } from "@/lib/mongodb";
import { CaseStudyModel } from "@/models";
import { caseStudies } from "@/data/case-studies";
import type { CaseStudy } from "@/types";
import type { ICaseStudy } from "@/models";

type LeanCaseStudy = ICaseStudy & { _id: unknown };

function toCaseStudy(item: LeanCaseStudy): CaseStudy {
  return {
    id: String(item._id),
    title: item.title as string,
    slug: item.slug as string,
    client: item.client as string,
    challenge: item.challenge as string,
    solution: item.solution as string,
    results: item.results as CaseStudy["results"],
    image: item.image as string,
    tags: item.tags as string[],
  };
}

export async function getCaseStudies(): Promise<CaseStudy[]> {
  try {
    await connectToDatabase();
    const items = await CaseStudyModel.find({ isPublished: true }).sort({ order: 1, createdAt: -1 }).lean();
    if (items.length > 0) {
      return items.map(toCaseStudy);
    }
  } catch {
    // fall through to static data
  }
  return caseStudies;
}

export async function getCaseStudyBySlug(slug: string): Promise<CaseStudy | undefined> {
  try {
    await connectToDatabase();
    const item = await CaseStudyModel.findOne({ slug, isPublished: true }).lean();
    if (item) return toCaseStudy(item);
  } catch {
    // fall through to static data
  }
  return caseStudies.find((s) => s.slug === slug);
}
