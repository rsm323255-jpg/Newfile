import "server-only";
import { connectToDatabase } from "@/lib/mongodb";
import { WhyChooseUsModel } from "@/models";
import type { WhyChooseUsFeature } from "@/types";

export async function getWhyChooseUs(): Promise<WhyChooseUsFeature[]> {
  await connectToDatabase();
  const items = await WhyChooseUsModel.find({ isPublished: true }).sort({ order: 1, createdAt: -1 }).lean();
  return items.map((item) => ({
    id: String(item._id),
    title: item.title,
    description: item.description,
    icon: item.icon,
  }));
}
