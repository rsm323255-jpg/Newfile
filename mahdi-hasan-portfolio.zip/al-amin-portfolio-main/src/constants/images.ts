/**
 * Image slots. Drop real assets into /public/images and point these at them.
 * Empty strings render clearly-labelled brand placeholders instead of fake imagery.
 */
export const images = {
  /** Portrait of Mahdi, ideally on a Primary Blue gradient backdrop (see Brand Kit p.12). */
  portrait: "",
  /** Open Graph image is generated at /opengraph-image (see src/app/opengraph-image.tsx). */
  ogImage: "/opengraph-image",
} as const;

export type ImageKey = keyof typeof images;
