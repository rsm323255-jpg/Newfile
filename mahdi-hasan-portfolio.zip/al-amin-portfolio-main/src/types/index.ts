export type Skill = {
  id: string;
  title: string;
  description: string;
  icon: string;
  features: string[];
};

export type Statistic = {
  id: string;
  value: string;
  label: string;
  suffix?: string;
};

export type Testimonial = {
  id: string;
  name: string;
  role: string;
  company: string;
  content: string;
  avatar: string;
  rating: number;
};

export type PortfolioItem = {
  id: string;
  title: string;
  slug: string;
  category: string;
  image: string;
  description: string;
  tags: string[];
  results: {
    metric: string;
    value: string;
  }[];
  /** True for template cards that hold no real client data. */
  placeholder?: boolean;
};

export type CaseStudy = {
  id: string;
  title: string;
  slug: string;
  client: string;
  challenge: string;
  solution: string;
  results: {
    before: string;
    after: string;
    metric: string;
  }[];
  image: string;
  tags: string[];
};

export type TeamMember = {
  id: string;
  name: string;
  role: string;
  bio: string;
  avatar: string;
  social: {
    linkedin?: string;
    twitter?: string;
    instagram?: string;
  };
};

export type FAQItem = {
  id: string;
  question: string;
  answer: string;
};

export type Client = {
  id: string;
  name: string;
  logo: string;
  website?: string;
};

export type ProcessStep = {
  id: string;
  title: string;
  description: string;
  icon: string;
};

export type ContactInfo = {
  eyebrow: string;
  title: string;
  subtitle: string;
  email: string;
  phone?: string;
  address?: string;
  workingHours?: string;
};

export type HeroData = {
  title: string;
  subtitle: string;
  description: string;
  ctaPrimary: string;
  ctaSecondary: string;
  image: string;
  stats: Statistic[];
};

export type AboutData = {
  title: string;
  description: string;
  mission: string;
  missionContent: string;
  vision: string;
  visionContent: string;
  experience: string;
  image: string;
  achievements: Statistic[];
};

export type WhyChooseUsFeature = {
  id: string;
  title: string;
  description: string;
  icon: string;
};

export type NewsletterData = {
  title: string;
  description: string;
  button: string;
};

export type PrivacyPolicyData = {
  title: string;
  content: string;
  lastUpdated: string;
};

export type TermsData = {
  title: string;
  content: string;
  lastUpdated: string;
};

export type SkillsSectionData = {
  eyebrow: string;
  title: string;
  subtitle: string;
};

export type SectionSettings = {
  eyebrow: string;
  title: string;
  subtitle: string;
};

export type SocialLinks = {
  linkedin: string;
  instagram?: string;
  facebook?: string;
  tiktok?: string;
  twitter?: string;
  youtube?: string;
};

export type MessageSubmission = {
  id: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  read: boolean;
  createdAt: string;
};

export type AdminUser = {
  userId: string;
  email: string;
  name: string;
  role: "admin" | "editor" | "viewer";
};

export type ApiResponse<T = unknown> = {
  success: boolean;
  data?: T;
  error?: string;
};
