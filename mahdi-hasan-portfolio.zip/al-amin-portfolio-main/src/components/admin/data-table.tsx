"use client";

import * as React from "react";
import Link from "next/link";
import {
  Search,
  MoreHorizontal,
  Pencil,
  Trash2,
} from "lucide-react";
import { cn } from "@/lib/utils";

export interface Column<T> {
  key: string;
  label: string;
  className?: string;
  hideOnMobile?: boolean;
  render?: (value: T[keyof T], row: T) => React.ReactNode;
}

export interface Action<T> {
  label: string;
  icon?: React.ReactNode;
  href?: (row: T) => string;
  onClick?: (row: T) => void;
  variant?: "default" | "destructive";
}

interface DataTableProps<T extends { id: string }> {
  columns: Column<T>[];
  data: T[];
  actions?: Action<T>[];
  searchPlaceholder?: string;
  searchKey?: keyof T;
  emptyMessage?: string;
  href?: string;
}

export function DataTable<T extends { id: string }>({
  columns,
  data,
  actions,
  searchPlaceholder = "Search...",
  searchKey,
  emptyMessage = "No items found.",
}: DataTableProps<T>) {
  const [search, setSearch] = React.useState("");
  const [openMenuId, setOpenMenuId] = React.useState<string | null>(null);

  const filtered = React.useMemo(() => {
    if (!search || !searchKey) return data;
    const q = search.toLowerCase();
    return data.filter((row) =>
      String(row[searchKey]).toLowerCase().includes(q)
    );
  }, [data, search, searchKey]);

  React.useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      const target = e.target as HTMLElement;
      if (!target.closest("[data-menu]")) {
        setOpenMenuId(null);
      }
    }
    document.addEventListener("click", handleClickOutside);
    return () => document.removeEventListener("click", handleClickOutside);
  }, []);

  return (
    <div className="space-y-4 min-w-0 overflow-hidden">
      <div className="flex items-center gap-3 min-w-0">
        {searchKey && (
          <div className="relative max-w-sm flex-1 min-w-0">
            <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={searchPlaceholder}
              className="h-10 w-full rounded-xl border border-border bg-background pl-10 pr-4 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring/50"
            />
          </div>
        )}
      </div>

      <div className="min-w-0 overflow-x-auto rounded-xl border border-border">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-border bg-muted/50">
              {columns.map((col) => (
                <th
                  key={col.key}
                  className={cn(
                    "px-3 py-3 font-medium text-muted-foreground sm:px-4",
                    col.hideOnMobile && "hidden sm:table-cell",
                    col.className
                  )}
                >
                  {col.label}
                </th>
              ))}
              {actions && actions.length > 0 && (
                <th className="px-3 py-3 text-right font-medium text-muted-foreground sm:px-4">
                  Actions
                </th>
              )}
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr>
                <td
                  colSpan={columns.length + (actions ? 1 : 0)}
                  className="px-4 py-12 text-center text-muted-foreground"
                >
                  {emptyMessage}
                </td>
              </tr>
            ) : (
              filtered.map((row) => (
                <tr
                  key={row.id}
                  className="border-b border-border last:border-0 hover:bg-muted/30"
                >
                  {columns.map((col) => (
                    <td key={col.key} className={cn("px-3 py-3 sm:px-4", col.hideOnMobile && "hidden sm:table-cell", col.className)}>
                      {col.render
                        ? col.render(row[col.key as keyof T], row)
                        : String(row[col.key as keyof T] ?? "")}
                    </td>
                  ))}
                  {actions && actions.length > 0 && (
                    <td className="px-4 py-3 text-right">
                      <div className="relative inline-block" data-menu>
                        <button
                          onClick={() =>
                            setOpenMenuId(
                              openMenuId === row.id ? null : row.id
                            )
                          }
                          className="flex size-8 cursor-pointer items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
                        >
                          <MoreHorizontal className="size-4" />
                        </button>
                        {openMenuId === row.id && (
                          <div className="absolute right-0 top-full z-50 mt-1 w-40 overflow-hidden rounded-xl border border-border bg-card shadow-xl">
                            {actions.map((action, i) => {
                              const content = (
                                <span className="flex items-center gap-2">
                                  {action.icon ?? (
                                    action.variant === "destructive" ? (
                                      <Trash2 className="size-3.5" />
                                    ) : (
                                      <Pencil className="size-3.5" />
                                    )
                                  )}
                                  {action.label}
                                </span>
                              );
                              return action.href ? (
                                <Link
                                  key={i}
                                  href={action.href(row)}
                                  onClick={() => setOpenMenuId(null)}
                                  className={cn(
                                    "flex w-full items-center gap-2 px-4 py-2.5 text-sm transition-colors hover:bg-muted",
                                    action.variant === "destructive" &&
                                      "text-destructive hover:bg-destructive/10"
                                  )}
                                >
                                  {content}
                                </Link>
                              ) : (
                                <button
                                  key={i}
                                  onClick={() => {
                                    action.onClick?.(row);
                                    setOpenMenuId(null);
                                  }}
                                  className={cn(
                                    "flex w-full cursor-pointer items-center gap-2 px-4 py-2.5 text-sm transition-colors hover:bg-muted",
                                    action.variant === "destructive" &&
                                      "text-destructive hover:bg-destructive/10"
                                  )}
                                >
                                  {content}
                                </button>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    </td>
                  )}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
