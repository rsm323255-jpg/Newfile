"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";

interface AdminFormProps {
  title: string;
  description?: string;
  children: React.ReactNode;
  onSubmit: (e: React.FormEvent) => void | Promise<void>;
  loading?: boolean;
  backHref?: string;
  submitLabel?: string;
}

function CancelButton({ href }: { href: string }) {
  const router = useRouter();
  return (
    <Button variant="outline" type="button" onClick={() => router.push(href)}>
      Cancel
    </Button>
  );
}

export function AdminForm({
  title,
  description,
  children,
  onSubmit,
  loading,
  backHref,
  submitLabel = "Save",
}: AdminFormProps) {
  return (
    <form onSubmit={onSubmit} className="space-y-6">
      <div>
        <h2 className="font-heading text-lg font-semibold text-foreground">
          {title}
        </h2>
        {description && (
          <p className="mt-1 text-sm text-muted-foreground">{description}</p>
        )}
      </div>
      <div className="space-y-5 rounded-xl border border-border bg-card p-4 sm:p-6">
        {children}
      </div>
      <div className="flex items-center gap-3">
        <Button type="submit" disabled={loading}>
          {loading ? <Loader2 className="size-4 animate-spin" /> : submitLabel}
        </Button>
        {backHref && <CancelButton href={backHref} />}
      </div>
    </form>
  );
}
