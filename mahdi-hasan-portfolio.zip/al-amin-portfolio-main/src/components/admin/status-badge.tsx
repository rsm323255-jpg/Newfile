import { cn } from "@/lib/utils";

interface StatusBadgeProps {
  variant: "success" | "warning" | "error" | "info" | "default";
  children: React.ReactNode;
  className?: string;
}

const variants = {
  success: "bg-emerald-500/10 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400",
  warning: "bg-cyan/10 text-cyan dark:bg-cyan/15 dark:text-cyan",
  error: "bg-red-500/10 text-red-600 dark:bg-red-500/15 dark:text-red-400",
  info: "bg-blue-500/10 text-blue-600 dark:bg-blue-500/15 dark:text-blue-400",
  default: "bg-muted text-muted-foreground",
};

export function StatusBadge({ variant, children, className }: StatusBadgeProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium",
        variants[variant],
        className
      )}
    >
      {children}
    </span>
  );
}
