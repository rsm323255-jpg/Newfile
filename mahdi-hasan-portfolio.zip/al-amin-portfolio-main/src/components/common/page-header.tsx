"use client";

import * as React from "react";
import { motion } from "framer-motion";

import { Container } from "@/components/ui/container";
import { Badge } from "@/components/ui/badge";
import { fadeUp, staggerContainer } from "@/components/common/motion";

interface PageHeaderProps {
  eyebrow?: string;
  title: React.ReactNode;
  description?: React.ReactNode;
  badge?: string;
}

function PageHeader({ eyebrow, title, description, badge }: PageHeaderProps) {
  return (
    <section className="relative overflow-hidden border-b border-border bg-muted/40 py-20 sm:py-24">
      <div className="pointer-events-none absolute inset-0">
        <div className="bg-grid absolute inset-0 [mask-image:radial-gradient(ellipse_60%_60%_at_50%_0%,black,transparent)]" />
        <div className="absolute -top-32 left-1/4 h-72 w-72 animate-aurora rounded-full bg-primary/10 blur-3xl" />
        <div className="absolute -top-20 right-1/4 h-64 w-64 animate-aurora rounded-full bg-accent/10 blur-3xl [animation-delay:2s]" />
      </div>
      <Container className="relative">
        <motion.div
          className="mx-auto max-w-3xl text-center"
          initial="hidden"
          animate="visible"
          variants={staggerContainer}
        >
          {eyebrow && (
            <motion.span
              variants={fadeUp}
              className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/5 px-4 py-1.5 text-xs font-semibold uppercase tracking-widest text-primary"
            >
              <span className="h-1.5 w-1.5 rounded-full bg-primary" />
              {eyebrow}
            </motion.span>
          )}
          <motion.h1
            variants={fadeUp}
            className="text-balance text-4xl font-bold tracking-tight sm:text-5xl lg:text-6xl"
          >
            {title}
          </motion.h1>
          {description && (
            <motion.p
              variants={fadeUp}
              className="mx-auto mt-6 max-w-2xl text-lg leading-8 text-muted-foreground"
            >
              {description}
            </motion.p>
          )}
          {badge && (
            <motion.div variants={fadeUp}>
              <Badge className="mt-6">{badge}</Badge>
            </motion.div>
          )}
        </motion.div>
      </Container>
    </section>
  );
}

export { PageHeader };
