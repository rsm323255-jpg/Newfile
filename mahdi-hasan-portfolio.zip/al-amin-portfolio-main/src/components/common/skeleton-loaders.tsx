import { Skeleton } from "@/components/ui/skeleton";
import { Container } from "@/components/ui/container";

export function HeroSkeleton() {
  return (
    <section className="relative overflow-hidden border-b border-border bg-muted/40">
      <Container className="py-24 sm:py-32 lg:py-36">
        <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-2">
          <div className="flex flex-col items-center text-center lg:items-start lg:text-left">
            <Skeleton className="h-7 w-48 rounded-full" />
            <Skeleton className="mt-6 h-14 w-full max-w-xl rounded-2xl sm:h-20" />
            <Skeleton className="mt-4 h-14 w-3/4 rounded-2xl" />
            <Skeleton className="mt-6 h-6 w-full max-w-lg rounded-xl" />
            <Skeleton className="mt-3 h-6 w-5/6 rounded-xl" />
            <div className="mt-10 flex gap-4">
              <Skeleton className="h-12 w-44 rounded-xl" />
              <Skeleton className="h-12 w-36 rounded-xl" />
            </div>
          </div>
          <div className="relative mx-auto w-full max-w-lg">
            <Skeleton className="aspect-square w-full rounded-3xl" />
          </div>
        </div>
        <div className="mt-16 grid grid-cols-1 gap-8 border-t border-border pt-12 sm:grid-cols-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="flex flex-col items-center gap-2">
              <Skeleton className="h-8 w-24 rounded-lg" />
              <Skeleton className="h-4 w-32 rounded-md" />
            </div>
          ))}
        </div>
      </Container>
    </section>
  );
}

export function CardGridSkeleton({ count = 6 }: { count?: number }) {
  return (
    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="overflow-hidden rounded-2xl border border-border bg-card">
          <Skeleton className="aspect-[16/10] w-full rounded-none" />
          <div className="space-y-3 p-6">
            <Skeleton className="h-4 w-24 rounded-md" />
            <Skeleton className="h-6 w-full rounded-lg" />
            <Skeleton className="h-4 w-3/4 rounded-md" />
            <Skeleton className="h-4 w-full rounded-md" />
          </div>
        </div>
      ))}
    </div>
  );
}

export function PageHeaderSkeleton() {
  return (
    <section className="border-b border-border bg-muted/40 py-20 sm:py-24">
      <Container>
        <div className="mx-auto flex max-w-3xl flex-col items-center text-center">
          <Skeleton className="h-7 w-40 rounded-full" />
          <Skeleton className="mt-5 h-14 w-full max-w-2xl rounded-2xl" />
          <Skeleton className="mt-5 h-6 w-full max-w-xl rounded-xl" />
        </div>
      </Container>
    </section>
  );
}

export function PageSkeleton() {
  return (
    <>
      <PageHeaderSkeleton />
      <Container className="py-16 sm:py-20">
        <CardGridSkeleton count={6} />
      </Container>
    </>
  );
}
