"use client";

import { Component, type ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { AlertTriangle, RefreshCw } from "lucide-react";

interface ErrorBoundaryState {
  hasError: boolean;
  error?: Error;
}

export class ErrorBoundary extends Component<
  { children: ReactNode },
  ErrorBoundaryState
> {
  constructor(props: { children: ReactNode }) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="flex min-h-[50vh] flex-col items-center justify-center p-8 text-center">
          <div className="flex size-16 items-center justify-center rounded-full bg-destructive/10">
            <AlertTriangle className="size-7 text-destructive" />
          </div>
          <h2 className="mt-5 text-2xl font-bold text-foreground">
            Something went wrong
          </h2>
          <p className="mt-2 max-w-md text-muted-foreground">
            An unexpected error occurred while rendering this section. Please
            refresh the page to try again.
          </p>
          <Button
            onClick={() => window.location.reload()}
            className="mt-6"
            variant="outline"
          >
            <RefreshCw className="mr-2 size-4" />
            Refresh Page
          </Button>
        </div>
      );
    }

    return this.props.children;
  }
}
