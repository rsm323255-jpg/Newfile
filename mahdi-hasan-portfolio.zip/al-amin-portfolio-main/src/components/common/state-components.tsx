import { Button } from "@/components/ui/button";
import { RefreshCw, Inbox, AlertTriangle } from "lucide-react";

interface EmptyStateProps {
  title: string;
  description?: string;
  actionLabel?: string;
  onAction?: () => void;
}

export function EmptyState({
  title,
  description,
  actionLabel,
  onAction,
}: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-border py-20 text-center">
      <div className="flex size-16 items-center justify-center rounded-full bg-muted">
        <Inbox className="size-7 text-muted-foreground" />
      </div>
      <h3 className="mt-5 text-lg font-semibold text-foreground">{title}</h3>
      {description && (
        <p className="mt-2 max-w-sm text-sm text-muted-foreground">
          {description}
        </p>
      )}
      {actionLabel && onAction && (
        <Button onClick={onAction} variant="outline" className="mt-6">
          {actionLabel}
        </Button>
      )}
    </div>
  );
}

interface RetryStateProps {
  message?: string;
  onRetry: () => void;
}

export function RetryState({
  message = "Something went wrong loading this content. Please try again.",
  onRetry,
}: RetryStateProps) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-border bg-card py-20 text-center">
      <div className="flex size-16 items-center justify-center rounded-full bg-destructive/10">
        <AlertTriangle className="size-7 text-destructive" />
      </div>
      <h3 className="mt-5 text-lg font-semibold text-foreground">
        Failed to load
      </h3>
      <p className="mt-2 max-w-sm text-sm text-muted-foreground">{message}</p>
      <Button onClick={onRetry} variant="outline" className="mt-6">
        <RefreshCw className="mr-2 size-4" />
        Retry
      </Button>
    </div>
  );
}
