"use client";

import * as React from "react";
import { usePathname } from "next/navigation";

const TRACKED_PATHS = new Map<string, number>();
const DEBOUNCE_MS = 2000;

export function VisitorTracker() {
  const pathname = usePathname();

  React.useEffect(() => {
    if (!pathname || pathname.startsWith("/admin")) return;

    const now = Date.now();
    const lastTracked = TRACKED_PATHS.get(pathname);
    if (lastTracked && now - lastTracked < DEBOUNCE_MS) return;

    TRACKED_PATHS.set(pathname, now);

    const controller = new AbortController();

    fetch("/api/visitors", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        path: pathname,
        referrer: document.referrer || "",
        userAgent: navigator.userAgent,
      }),
      signal: controller.signal,
    }).catch(() => {});

    return () => controller.abort();
  }, [pathname]);

  return null;
}
