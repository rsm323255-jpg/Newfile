import Link from "next/link";
import { Mail } from "lucide-react";

import { siteConfig, footerLinks } from "@/config/site";
import { brandIconMap } from "@/components/ui/brand-icons";
import { Wordmark } from "@/components/shared/wordmark";
import { getSocialLinks } from "@/services";

function FooterColumn({ title, links }: { title: string; links: { label: string; href: string }[] }) {
  return (
    <div>
      <h4 className="font-heading text-xs font-medium uppercase tracking-[0.18em] text-cyan">
        {title}
      </h4>
      <ul className="mt-4 space-y-2.5">
        {links.map((link) => (
          <li key={link.href}>
            <Link
              href={link.href}
              className="text-sm text-white/75 transition-colors hover:text-white"
            >
              {link.label}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

export async function Footer() {
  const social = await getSocialLinks();
  const socials = Object.entries(social).filter(([platform, url]) => url && brandIconMap[platform]);

  return (
    <footer className="bg-navy text-white">
      <div className="mx-auto max-w-7xl px-6 pb-8 pt-16 lg:px-8">
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <Wordmark tone="light" />
            <p className="mt-5 max-w-sm text-sm leading-7 text-white/75">
              Independent media buyer and paid advertising consultant. Strategic vision, structured
              growth.
            </p>
            <div className="mt-6 flex flex-wrap items-center gap-3">
              <a
                href={`mailto:${siteConfig.contact.email}`}
                aria-label="Email Mahdi Hasan"
                className="flex size-10 items-center justify-center rounded-full border border-white/20 text-white/80 transition-colors hover:border-cyan hover:text-white"
              >
                <Mail className="size-4" />
              </a>
              {socials.map(([platform, url]) => {
                const Icon = brandIconMap[platform];
                return (
                  <a
                    key={platform}
                    href={url}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={`${siteConfig.name} on ${platform}`}
                    className="flex size-10 items-center justify-center rounded-full border border-white/20 text-white/80 transition-colors hover:border-cyan hover:text-white"
                  >
                    <Icon className="size-4" />
                  </a>
                );
              })}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-8 sm:grid-cols-3 lg:col-span-7 lg:pl-12">
            <FooterColumn title="Explore" links={footerLinks.explore} />
            <FooterColumn title="Resources" links={footerLinks.resources} />
            <FooterColumn title="Legal" links={footerLinks.legal} />
          </div>
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-3 border-t border-white/15 pt-6 text-sm text-white/65 md:flex-row">
          <p>
            © {new Date().getFullYear()} {siteConfig.name}. All rights reserved.
          </p>
          <p className="font-serif italic text-white/80">Structure first, creativity second.</p>
        </div>
      </div>
    </footer>
  );
}
