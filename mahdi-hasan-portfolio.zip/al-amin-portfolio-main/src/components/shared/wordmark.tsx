import Link from "next/link";

import { cn } from "@/lib/utils";

/** MH monogram: Space Grotesk Bold on a solid Primary Blue circle (Brand Kit p.7). */
export function Monogram({ className }: { className?: string }) {
  return (
    <span
      aria-hidden="true"
      className={cn(
        "flex size-10 shrink-0 items-center justify-center rounded-full bg-brand font-heading text-sm font-bold tracking-tight text-white",
        className
      )}
    >
      MH
    </span>
  );
}

/** Wordmark: Lora Semibold name with an optional tracked Space Grotesk descriptor. */
export function Wordmark({
  descriptor = true,
  tone = "default",
  className,
}: {
  descriptor?: boolean;
  tone?: "default" | "light";
  className?: string;
}) {
  return (
    <Link
      href="/#home"
      aria-label="Mahdi Hasan, home"
      className={cn("inline-flex items-center gap-3", className)}
    >
      <Monogram className={tone === "light" ? "bg-white text-brand" : undefined} />
      <span className="flex flex-col leading-none">
        <span
          className={cn(
            "font-serif text-xl font-semibold tracking-tight",
            tone === "light" ? "text-white" : "text-brand dark:text-foreground"
          )}
        >
          Mahdi Hasan
        </span>
        {descriptor && (
          <span
            className={cn(
              "mt-1.5 hidden font-heading text-[10px] font-medium uppercase tracking-[0.18em] sm:block",
              tone === "light" ? "text-white/70" : "text-muted-foreground"
            )}
          >
            Media Buyer &amp; Paid Ads
          </span>
        )}
      </span>
    </Link>
  );
}
