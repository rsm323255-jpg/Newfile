import { getStatistics, getStatisticsSection } from "@/services";
import { StatisticsContent } from "@/components/sections/statistics-content";

export async function StatisticsSection() {
  const [statistics, section] = await Promise.all([getStatistics(), getStatisticsSection()]);
  return <StatisticsContent statistics={statistics} eyebrow={section.eyebrow} title={section.title} subtitle={section.subtitle} />;
}
