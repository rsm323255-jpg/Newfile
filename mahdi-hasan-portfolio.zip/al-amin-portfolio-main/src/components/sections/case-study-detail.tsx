"use client";

import Link from "next/link";
import Image from "next/image";
import { motion } from "framer-motion";
import { ArrowLeft, ArrowRight, Target, Lightbulb, TrendingUp } from "lucide-react";

import { Container } from "@/components/ui/container";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { fadeUp, staggerContainer } from "@/components/common/motion";
import type { CaseStudy } from "@/types";

interface CaseStudyDetailProps {
  study: CaseStudy;
  nextStudy?: CaseStudy;
}

export function CaseStudyDetail({ study, nextStudy }: CaseStudyDetailProps) {
  return (
    <article className="relative overflow-hidden py-16 sm:py-20">
      <div className="pointer-events-none absolute inset-0">
        <div className="bg-grid absolute inset-0 [mask-image:radial-gradient(ellipse_60%_60%_at_50%_0%,black,transparent)]" />
        <div className="absolute -top-32 left-1/4 h-72 w-72 animate-aurora rounded-full bg-primary/10 blur-3xl" />
      </div>

      <Container className="relative">
        <Link
          href="/#work"
          className="inline-flex items-center gap-2 text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
        >
          <ArrowLeft className="size-4" />
          Back to Case Studies
        </Link>

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          animate="visible"
          className="mx-auto mt-8 max-w-4xl"
        >
          <motion.div variants={fadeUp} className="flex flex-wrap gap-2">
            {study.tags.map((tag) => (
              <Badge key={tag} variant="secondary">
                {tag}
              </Badge>
            ))}
          </motion.div>
          <motion.h1
            variants={fadeUp}
            className="mt-5 text-balance text-3xl font-bold tracking-tight sm:text-4xl lg:text-5xl"
          >
            {study.title}
          </motion.h1>
          <motion.p variants={fadeUp} className="mt-4 text-lg text-muted-foreground">
            Client:{" "}
            <span className="font-medium text-foreground">{study.client}</span>
          </motion.p>
        </motion.div>

        <motion.div
          variants={fadeUp}
          initial="hidden"
          animate="visible"
          className="relative mt-10 overflow-hidden rounded-3xl border border-border shadow-2xl"
        >
          <Image
            src={study.image}
            alt={study.title}
            width={1200}
            height={675}
            className="aspect-video w-full object-cover"
            sizes="(max-width: 1280px) 100vw, 1280px"
          />
        </motion.div>

        <div className="mx-auto mt-12 grid max-w-4xl grid-cols-1 gap-6 lg:grid-cols-2">
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="rounded-3xl border border-border bg-card p-8"
          >
            <div className="flex size-11 items-center justify-center rounded-xl bg-cyan/10 text-cyan">
              <Target className="size-5" />
            </div>
            <h2 className="mt-4 font-heading text-xl font-bold">The Challenge</h2>
            <p className="mt-3 text-sm leading-7 text-muted-foreground">
              {study.challenge}
            </p>
          </motion.div>

          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="rounded-3xl border border-border bg-card p-8"
          >
            <div className="flex size-11 items-center justify-center rounded-xl bg-primary/10 text-primary">
              <Lightbulb className="size-5" />
            </div>
            <h2 className="mt-4 font-heading text-xl font-bold">The Solution</h2>
            <p className="mt-3 text-sm leading-7 text-muted-foreground">
              {study.solution}
            </p>
          </motion.div>
        </div>

        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="mx-auto mt-6 max-w-4xl overflow-hidden rounded-3xl bg-primary"
        >
          <div className="relative px-8 py-10 sm:px-12 sm:py-14">
            <div className="bg-grid absolute inset-0 opacity-30 [mask-image:radial-gradient(ellipse_70%_70%_at_50%_50%,black,transparent)]" />
            <div className="relative">
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-white/70">
                <TrendingUp className="size-4" />
                Results
              </div>
              <div className="mt-8 grid grid-cols-1 gap-8 sm:grid-cols-3">
                {study.results.map((result) => (
                  <div key={result.metric} className="text-center">
                    <div className="font-heading text-3xl font-bold text-white">
                      <span className="text-white/50 line-through decoration-white/30">
                        {result.before}
                      </span>
                      <span className="mx-2 text-white/40">→</span>
                      <span className="text-cyan">{result.after}</span>
                    </div>
                    <div className="mt-2 text-sm text-white/80">{result.metric}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </motion.div>

        <div className="mx-auto mt-16 max-w-4xl">
          <div className="flex flex-col items-center justify-between gap-6 rounded-3xl border border-border bg-muted/40 p-8 sm:flex-row">
            <div>
              <h3 className="font-heading text-xl font-bold">Want results like these?</h3>
              <p className="mt-2 text-sm text-muted-foreground">
                Let&apos;s talk about what we could do for your brand.
              </p>
            </div>
            <Button asChild variant="gradient" size="lg">
              <Link href="/#contact">
                Start your project
                <ArrowRight className="size-4" />
              </Link>
            </Button>
          </div>

          {nextStudy && (
            <Link
              href={`/case-studies/${nextStudy.id}`}
              className="group mt-6 flex items-center justify-between rounded-3xl border border-border bg-card p-8 transition-all duration-500 hover:-translate-y-1 hover:border-primary/30 hover:shadow-xl"
            >
              <div>
                <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Next case study
                </div>
                <div className="mt-2 font-heading text-lg font-bold text-foreground transition-colors group-hover:text-primary">
                  {nextStudy.title}
                </div>
              </div>
              <ArrowRight className="size-6 text-primary transition-transform group-hover:translate-x-1" />
            </Link>
          )}
        </div>
      </Container>
    </article>
  );
}
