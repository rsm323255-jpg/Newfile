"use client";

import * as React from "react";
import { motion } from "framer-motion";
import {
  BarChart3,
  Eye,
  Palette,
  Headphones,
  Trophy,
  Unlock,
  type LucideIcon,
} from "lucide-react";

import { Container } from "@/components/ui/container";
import { SectionTitle } from "@/components/ui/section-title";
import { fadeUp, staggerContainer } from "@/components/common/motion";
import type { WhyChooseUsFeature } from "@/types";

const iconMap: Record<string, LucideIcon> = {
  BarChart3,
  Eye,
  Palette,
  Headphones,
  Trophy,
  Unlock,
};

export function WhyChooseUsContent({ features, eyebrow, title, subtitle }: { features: WhyChooseUsFeature[]; eyebrow: string; title: string; subtitle: string }) {
  return (
    <section className="relative py-24 sm:py-28">
      <Container>
        <SectionTitle
          eyebrow={eyebrow}
          title={title}
          subtitle={subtitle}
        />

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          className="mt-16 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3"
        >
          {features.map((feature, i) => {
            const Icon = iconMap[feature.icon] ?? BarChart3;
            return (
              <motion.div
                key={feature.id}
                variants={fadeUp}
                custom={i}
                className="group relative overflow-hidden rounded-2xl border border-border bg-card p-7 transition-all duration-500 hover:-translate-y-1.5 hover:border-primary/30 hover:shadow-2xl hover:shadow-primary/10"
              >
                <div className="flex items-start justify-between">
                  <div className="flex size-12 items-center justify-center rounded-xl bg-primary/10 text-primary transition-all duration-500 group-hover:bg-gradient-to-br group-hover:from-primary group-hover:to-primary group-hover:text-white group-hover:shadow-lg group-hover:shadow-primary/25">
                    <Icon className="size-5" />
                  </div>
                  <span className="font-heading text-4xl font-bold text-muted-foreground/10 transition-colors duration-500 group-hover:text-primary/10">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                </div>
                <h3 className="mt-5 font-heading text-lg font-bold text-foreground">
                  {feature.title}
                </h3>
                <p className="mt-2.5 text-sm leading-6 text-muted-foreground">
                  {feature.description}
                </p>
              </motion.div>
            );
          })}
        </motion.div>
      </Container>
    </section>
  );
}
