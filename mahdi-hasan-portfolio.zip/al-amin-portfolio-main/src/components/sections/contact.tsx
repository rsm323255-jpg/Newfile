import { getContact } from "@/services";
import { ContactContent } from "@/components/sections/contact-content";

export async function ContactSection() {
  const info = await getContact();
  return <ContactContent info={info} />;
}
