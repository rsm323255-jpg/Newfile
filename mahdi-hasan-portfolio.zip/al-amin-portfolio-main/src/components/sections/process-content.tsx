"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { Search, ClipboardList, Rocket, Settings2, PhoneCall, type LucideIcon } from "lucide-react";

import { Container } from "@/components/ui/container";
import { SectionTitle } from "@/components/ui/section-title";
import { fadeUp, staggerContainer } from "@/components/common/motion";
import { cn } from "@/lib/utils";
import type { ProcessStep } from "@/types";

const iconMap: Record<string, LucideIcon> = {
  "📞": PhoneCall,
  "🔍": Search,
  "📋": ClipboardList,
  "🚀": Rocket,
  "⚙️": Settings2,
};

export function ProcessContent({
  steps,
  eyebrow,
  title,
  subtitle,
}: {
  steps: ProcessStep[];
  eyebrow: string;
  title: string;
  subtitle: string;
}) {
  return (
    <section id="process" className="relative scroll-mt-20 overflow-hidden bg-navy py-20 sm:py-24">
      <div aria-hidden="true" className="bg-dots pointer-events-none absolute inset-0 opacity-60 [mask-image:radial-gradient(ellipse_70%_60%_at_50%_0%,black,transparent)]" />
      <Container className="relative">
        <SectionTitle tone="light" eyebrow={eyebrow} title={title} subtitle={subtitle} />

        <motion.ol
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          className="relative mx-auto mt-16 max-w-4xl"
        >
          <span
            aria-hidden="true"
            className="absolute bottom-4 left-6 top-4 w-px bg-gradient-to-b from-cyan/60 via-bright/40 to-transparent md:left-1/2 md:-translate-x-1/2"
          />
          {steps.map((step, i) => {
            const Icon = iconMap[step.icon] ?? ClipboardList;
            const right = i % 2 === 1;
            return (
              <motion.li
                key={step.id}
                variants={fadeUp}
                custom={i}
                className="relative pb-8 pl-16 last:pb-0 md:grid md:grid-cols-2 md:gap-14 md:pl-0"
              >
                <span className="absolute left-0 top-0 z-10 flex size-12 items-center justify-center rounded-full border border-cyan/50 bg-brand text-white shadow-lg shadow-black/20 md:left-1/2 md:-translate-x-1/2">
                  <Icon className="size-5" />
                </span>
                <div
                  className={cn(
                    "rounded-2xl border border-white/15 bg-white/[0.06] p-6 backdrop-blur-sm transition-colors hover:border-cyan/50",
                    right ? "md:col-start-2" : "md:col-start-1 md:text-right"
                  )}
                >
                  <p className="font-heading text-xs font-medium uppercase tracking-[0.18em] text-cyan">
                    Step {String(i + 1).padStart(2, "0")}
                  </p>
                  <h3 className="mt-2 font-heading text-lg font-bold text-white">{step.title}</h3>
                  <p className="mt-2 text-sm leading-7 text-white/80">{step.description}</p>
                </div>
              </motion.li>
            );
          })}
        </motion.ol>
      </Container>
    </section>
  );
}
