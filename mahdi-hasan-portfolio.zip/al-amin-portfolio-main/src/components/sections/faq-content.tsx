"use client";

import * as React from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { MessageCircleQuestion } from "lucide-react";

import { Container } from "@/components/ui/container";
import { SectionTitle } from "@/components/ui/section-title";
import { Accordion } from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import type { FAQItem } from "@/types";

export function FAQContent({ items, eyebrow, title, subtitle }: { items: FAQItem[]; eyebrow: string; title: string; subtitle: string }) {
  return (
    <section className="relative scroll-mt-20 py-20 sm:py-24" id="faq">
      <Container>
        <SectionTitle
          eyebrow={eyebrow}
          title={title}
          subtitle={subtitle}
        />

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="mx-auto mt-14 max-w-3xl"
        >
          <Accordion items={items} />
        </motion.div>

        <div className="mx-auto mt-12 flex max-w-3xl flex-col items-center gap-4 rounded-2xl border border-border bg-panel p-8 dark:bg-card text-center">
          <div className="flex size-12 items-center justify-center rounded-full bg-primary/10 text-primary">
            <MessageCircleQuestion className="size-5" />
          </div>
          <h3 className="font-heading text-lg font-bold text-foreground">
            Still have questions?
          </h3>
          <p className="text-sm text-muted-foreground">
            Send a message and let&apos;s talk about your goals.
          </p>
          <Button asChild className="mt-2 rounded-full">
            <Link href="/#contact">Get in touch</Link>
          </Button>
        </div>
      </Container>
    </section>
  );
}
