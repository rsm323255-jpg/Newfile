"use client";

import * as React from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { Mail, Send, Loader2, Sparkles } from "lucide-react";
import { motion } from "framer-motion";

import { Container } from "@/components/ui/container";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/store/toast-store";
import { newsletterSchema, type NewsletterFormData } from "@/schemas/contact";
import { subscribeNewsletter } from "@/actions/contact.action";
import { fadeUp, scaleIn } from "@/components/common/motion";
import type { NewsletterData } from "@/types";

export function NewsletterContent({ data }: { data: NewsletterData }) {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = React.useState(false);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<NewsletterFormData>({
    resolver: zodResolver(newsletterSchema),
  });

  async function onSubmit(data: NewsletterFormData) {
    setIsSubmitting(true);
    try {
      const formData = new FormData();
      formData.append("email", data.email);
      const result = await subscribeNewsletter(formData);
      if (result.success) {
        reset();
        toast({
          type: "success",
          title: "You're subscribed!",
          description: "Fresh marketing insights land in your inbox weekly.",
        });
      } else {
        toast({
          type: "error",
          title: "Subscription failed",
          description: result.message,
        });
      }
    } catch {
      toast({
        type: "error",
        title: "Subscription failed",
        description: "Please try again in a moment.",
      });
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <section className="relative overflow-hidden py-24 sm:py-28">
      <Container>
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.2 }}
          variants={scaleIn}
          className="relative overflow-hidden rounded-3xl bg-primary px-6 py-14 text-center sm:px-16 sm:py-20"
        >
          <div className="absolute inset-0">
            <div className="bg-grid absolute inset-0 opacity-30 [mask-image:radial-gradient(ellipse_70%_70%_at_50%_50%,black,transparent)]" />
            <div className="absolute -left-16 top-0 size-64 animate-aurora rounded-full bg-white/10 blur-3xl" />
            <div className="absolute -right-16 bottom-0 size-64 animate-aurora rounded-full bg-primary/20 blur-3xl [animation-delay:4s]" />
          </div>

          <div className="relative">
            <motion.span
              custom={0}
              variants={fadeUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className="inline-flex items-center gap-2 rounded-full bg-white/15 px-4 py-1.5 text-xs font-semibold uppercase tracking-widest text-white backdrop-blur"
            >
              <Sparkles className="size-3.5" />
              Free weekly insights
            </motion.span>
            <motion.h2
              custom={1}
              variants={fadeUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className="mx-auto mt-5 max-w-2xl text-balance font-heading text-3xl font-bold text-white sm:text-4xl"
            >
              {data.title}
            </motion.h2>
            <motion.p
              custom={2}
              variants={fadeUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className="mx-auto mt-4 max-w-xl text-white/80"
            >
              {data.description}
            </motion.p>

            <motion.form
              custom={3}
              variants={fadeUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              onSubmit={handleSubmit(onSubmit)}
              noValidate
              className="mx-auto mt-8 flex max-w-md flex-col gap-3 sm:flex-row"
            >
              <div className="relative flex-1">
                <Mail className="absolute left-4 top-1/2 size-4 -translate-y-1/2 text-white/60" />
                <Input
                  type="email"
                  placeholder="Enter your email"
                  aria-invalid={!!errors.email}
                  {...register("email")}
                  className="border-white/20 bg-white/10 pl-11 text-white placeholder:text-white/60 focus:border-white/40 focus:bg-white/15"
                />
              </div>
              <Button
                type="submit"
                size="lg"
                disabled={isSubmitting}
                className="bg-white text-primary shadow-lg hover:bg-white/90"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="size-4 animate-spin" />
                    Subscribing...
                  </>
                ) : (
                  <>
                    {data.button}
                    <Send className="size-4" />
                  </>
                )}
              </Button>
            </motion.form>
            {errors.email && (
              <p className="mt-3 text-sm text-white/90">
                {errors.email.message}
              </p>
            )}
          </div>
        </motion.div>
      </Container>
    </section>
  );
}
