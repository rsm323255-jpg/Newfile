import { getAbout } from "@/services";
import { AboutContent } from "@/components/sections/about-content";

export async function AboutSection() {
  const about = await getAbout();
  return <AboutContent data={about} />;
}
