import { getFAQ, getFAQSection } from "@/services";
import { FAQContent } from "@/components/sections/faq-content";

export async function FAQSection() {
  const [items, section] = await Promise.all([getFAQ(), getFAQSection()]);
  return <FAQContent items={items} eyebrow={section.eyebrow} title={section.title} subtitle={section.subtitle} />;
}
