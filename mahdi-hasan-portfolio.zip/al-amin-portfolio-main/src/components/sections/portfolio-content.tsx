"use client";

import * as React from "react";
import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowUpRight, BarChart3, Maximize2 } from "lucide-react";

import { Container } from "@/components/ui/container";
import { SectionTitle } from "@/components/ui/section-title";
import { Lightbox } from "@/components/ui/modal";
import { fadeUp, staggerContainer } from "@/components/common/motion";
import { cn } from "@/lib/utils";
import type { PortfolioItem } from "@/types";

function TileVisual({ item }: { item: PortfolioItem }) {
  if (item.image) {
    return (
      <Image
        src={item.image}
        alt={item.title}
        fill
        sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
        className="object-contain p-3 transition-transform duration-500 group-hover:scale-[1.03]"
      />
    );
  }
  return (
    <div className="flex h-full flex-col items-center justify-center gap-3 text-center">
      <span className="flex size-12 items-center justify-center rounded-xl bg-brand/8 text-brand dark:bg-primary/15 dark:text-primary">
        <BarChart3 className="size-5" />
      </span>
      <p className="max-w-[12rem] text-xs leading-5 text-muted-foreground">
        Dashboard screenshot or result visual goes here
      </p>
    </div>
  );
}

export function PortfolioContent({
  items: allItems,
  limit,
  eyebrow,
  title,
  subtitle,
}: {
  items: PortfolioItem[];
  limit?: number;
  eyebrow: string;
  title: string;
  subtitle: string;
}) {
  const items = limit ? allItems.slice(0, limit) : allItems;
  const [activeCategory, setActiveCategory] = React.useState("All");
  const [selected, setSelected] = React.useState<PortfolioItem | null>(null);

  const categories = React.useMemo(
    () => ["All", ...Array.from(new Set(items.map((item) => item.category)))],
    [items]
  );
  const filtered = activeCategory === "All" ? items : items.filter((i) => i.category === activeCategory);
  const showFilters = categories.length > 2 && !items.every((i) => i.placeholder);

  return (
    <section id="work" className="relative scroll-mt-20 py-20 sm:py-24">
      <Container>
        <SectionTitle eyebrow={eyebrow} title={title} subtitle={subtitle} />

        {showFilters && (
          <div className="mt-10 flex flex-wrap justify-center gap-2">
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setActiveCategory(cat)}
                aria-pressed={activeCategory === cat}
                className={cn(
                  "cursor-pointer rounded-full px-5 py-2 text-sm font-medium transition-colors",
                  activeCategory === cat
                    ? "bg-brand text-white dark:bg-primary dark:text-primary-foreground"
                    : "border border-border bg-card text-muted-foreground hover:border-bright/40 hover:text-foreground"
                )}
              >
                {cat}
              </button>
            ))}
          </div>
        )}

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          className="mt-12 grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3"
        >
          {filtered.map((item, i) => {
            const clickable = !!item.image;
            return (
              <motion.article
                key={item.id}
                variants={fadeUp}
                custom={i}
                className={cn(
                  "group flex flex-col overflow-hidden rounded-2xl border bg-card transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-brand/10",
                  item.placeholder ? "border-dashed border-input" : "border-border hover:border-bright/40"
                )}
              >
                <div
                  className={cn("relative aspect-[4/3] overflow-hidden bg-panel dark:bg-muted", clickable && "cursor-pointer")}
                  onClick={clickable ? () => setSelected(item) : undefined}
                >
                  <TileVisual item={item} />
                  <span className="absolute left-3 top-3 rounded-full bg-navy px-3 py-1 font-heading text-[11px] font-medium uppercase tracking-wider text-white">
                    {item.placeholder ? "Placeholder" : item.category}
                  </span>
                  {clickable && (
                    <span className="absolute right-3 top-3 flex size-9 items-center justify-center rounded-full bg-navy text-white opacity-0 transition-opacity group-hover:opacity-100">
                      <Maximize2 className="size-4" />
                    </span>
                  )}
                </div>

                <div className="flex flex-1 flex-col p-6">
                  <h3 className="font-heading text-lg font-bold leading-snug text-foreground">{item.title}</h3>
                  <p className="mt-2 text-sm leading-6 text-muted-foreground">{item.description}</p>

                  <div className="mt-4 flex flex-wrap gap-1.5">
                    {item.tags.slice(0, 3).map((tag) => (
                      <span
                        key={tag}
                        className="rounded-full bg-panel px-2.5 py-1 text-[11px] font-medium text-muted-foreground dark:bg-muted"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>

                  <dl className="mt-auto grid grid-cols-2 gap-4 border-t border-border pt-5">
                    {item.results.slice(0, 2).map((r, idx) => (
                      <div key={`${r.metric}-${idx}`}>
                        <dd className="font-heading text-xl font-bold text-brand dark:text-primary">{r.value}</dd>
                        <dt className="text-xs text-muted-foreground">{r.metric}</dt>
                      </div>
                    ))}
                  </dl>
                </div>
              </motion.article>
            );
          })}
        </motion.div>

        {filtered.length === 0 && (
          <p className="mt-12 text-center text-muted-foreground">No projects in this category yet.</p>
        )}

        {allItems.every((i) => i.placeholder) && (
          <p className="mx-auto mt-10 max-w-xl text-center text-sm text-muted-foreground">
            These are layout placeholders. Real, approved results will appear here. Want to talk about yours?{" "}
            <Link href="/#contact" className="inline-flex items-center gap-1 font-semibold text-brand hover:text-bright dark:text-primary">
              Get in touch <ArrowUpRight className="size-3.5" />
            </Link>
          </p>
        )}

        <Lightbox
          open={!!selected}
          onClose={() => setSelected(null)}
          image={selected?.image ?? ""}
          title={selected?.title ?? ""}
          description={
            selected
              ? `${selected.description} — ${selected.results.map((r) => `${r.metric}: ${r.value}`).join(" · ")}`
              : undefined
          }
        />
      </Container>
    </section>
  );
}
