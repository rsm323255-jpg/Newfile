import { getProcess, getProcessSection } from "@/services";
import { ProcessContent } from "@/components/sections/process-content";

export async function ProcessSection() {
  const [steps, section] = await Promise.all([getProcess(), getProcessSection()]);
  return <ProcessContent steps={steps} eyebrow={section.eyebrow} title={section.title} subtitle={section.subtitle} />;
}
