"use client";

import * as React from "react";
import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowUpRight, Compass, Layers } from "lucide-react";

import { Container } from "@/components/ui/container";
import { SectionTitle } from "@/components/ui/section-title";
import { Button } from "@/components/ui/button";
import { fadeLeft, fadeRight, staggerContainer } from "@/components/common/motion";
import { siteConfig } from "@/config/site";
import type { AboutData } from "@/types";

function PortraitPlaceholder() {
  return (
    <div className="relative flex aspect-[4/5] w-full items-center justify-center overflow-hidden rounded-[2rem] border border-white/10 bg-brand">
      <div aria-hidden="true" className="absolute inset-0 bg-gradient-to-br from-transparent via-transparent to-navy/80" />
      <div aria-hidden="true" className="bg-dots absolute inset-0 opacity-70" />
      <div className="relative text-center text-white">
        <span className="mx-auto flex size-28 items-center justify-center rounded-full border-2 border-white/80 font-heading text-4xl font-bold tracking-tight">
          MH
        </span>
        <p className="mt-6 font-heading text-[11px] font-medium uppercase tracking-[0.2em] text-white/90">
          Portrait placeholder
        </p>
        <p className="mx-auto mt-2 max-w-[16rem] text-xs leading-5 text-white/75">
          Add a portrait on a Primary Blue backdrop in <code className="font-mono">src/constants/images.ts</code>.
        </p>
      </div>
    </div>
  );
}

export function AboutContent({ data }: { data: AboutData }) {
  return (
    <section id="about" className="relative scroll-mt-20 bg-panel py-20 sm:py-24 dark:bg-card">
      <Container>
        <div className="grid grid-cols-1 items-center gap-14 lg:grid-cols-[0.8fr_1.2fr] lg:gap-20">
          <motion.div
            variants={fadeLeft}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            className="relative mx-auto w-full max-w-sm lg:max-w-none"
          >
            {data.image ? (
              <div className="relative aspect-[4/5] overflow-hidden rounded-[2rem] border border-border shadow-xl shadow-brand/10">
                <Image
                  src={data.image}
                  alt="Portrait of Mahdi Hasan"
                  fill
                  sizes="(max-width: 1024px) 80vw, 460px"
                  className="object-cover"
                />
              </div>
            ) : (
              <PortraitPlaceholder />
            )}
            <div className="absolute -bottom-5 left-1/2 w-[88%] -translate-x-1/2 rounded-2xl border border-border bg-card px-5 py-4 shadow-lg shadow-brand/10 sm:left-auto sm:right-[-1.5rem] sm:w-auto sm:translate-x-0">
              <p className="font-heading text-[11px] font-medium uppercase tracking-[0.18em] text-muted-foreground">
                The Creator archetype
              </p>
              <p className="mt-1 font-serif text-base font-semibold italic text-brand dark:text-primary">
                Innovation × Provide Structure
              </p>
            </div>
          </motion.div>

          <motion.div
            variants={staggerContainer}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
          >
            <motion.div variants={fadeRight}>
              <SectionTitle eyebrow="About Mahdi" title={data.title} align="left" />
            </motion.div>
            <motion.p variants={fadeRight} className="mt-6 max-w-2xl text-base leading-8 text-muted-foreground">
              {data.description}
            </motion.p>

            <motion.div variants={fadeRight} className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div className="rounded-2xl border border-border bg-card p-5">
                <span className="flex size-10 items-center justify-center rounded-xl bg-brand/8 text-brand dark:bg-primary/15 dark:text-primary">
                  <Layers className="size-5" />
                </span>
                <h3 className="mt-3 font-heading text-base font-bold">{data.mission}</h3>
                <p className="mt-2 text-sm leading-6 text-muted-foreground">{data.missionContent}</p>
              </div>
              <div className="rounded-2xl border border-border bg-card p-5">
                <span className="flex size-10 items-center justify-center rounded-xl bg-brand/8 text-brand dark:bg-primary/15 dark:text-primary">
                  <Compass className="size-5" />
                </span>
                <h3 className="mt-3 font-heading text-base font-bold">{data.vision}</h3>
                <p className="mt-2 text-sm leading-6 text-muted-foreground">{data.visionContent}</p>
              </div>
            </motion.div>

            {data.achievements.length > 0 && (
              <motion.div variants={fadeRight} className="mt-8">
                <p className="font-heading text-xs font-medium uppercase tracking-[0.2em] text-muted-foreground">
                  Four content pillars
                </p>
                <ol className="mt-4 grid grid-cols-1 gap-x-8 gap-y-3 sm:grid-cols-2">
                  {data.achievements.map((p) => (
                    <li key={p.id} className="flex items-baseline gap-3 border-b border-border pb-3">
                      <span className="font-heading text-sm font-bold text-brand dark:text-cyan">{p.value}</span>
                      <span className="text-sm font-medium text-foreground">{p.label}</span>
                    </li>
                  ))}
                </ol>
              </motion.div>
            )}

            <motion.div variants={fadeRight} className="mt-9 flex flex-col gap-3 sm:flex-row">
              <Button asChild size="lg" className="rounded-full">
                <Link href="/#contact">Work with me</Link>
              </Button>
              {siteConfig.social.linkedin && (
                <Button asChild size="lg" variant="outline" className="rounded-full">
                  <a href={siteConfig.social.linkedin} target="_blank" rel="noopener noreferrer">
                    LinkedIn
                    <ArrowUpRight className="size-4" />
                  </a>
                </Button>
              )}
            </motion.div>
          </motion.div>
        </div>
      </Container>
    </section>
  );
}
