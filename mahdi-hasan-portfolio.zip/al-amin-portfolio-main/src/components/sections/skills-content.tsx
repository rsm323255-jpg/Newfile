"use client";

import * as React from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  Target,
  LineChart,
  Mic,
  Users,
  BarChart3,
  Palette,
  ArrowUpRight,
  type LucideIcon,
} from "lucide-react";

import { Container } from "@/components/ui/container";
import { SectionTitle } from "@/components/ui/section-title";
import { fadeUp, staggerContainer } from "@/components/common/motion";
import type { Skill } from "@/types";

const iconMap: Record<string, LucideIcon> = {
  "🎯": Target,
  "📊": LineChart,
  "📱": Mic,
  "🎪": Users,
  "📈": BarChart3,
  "🎨": Palette,
};

export function SkillsContent({ items, eyebrow, title, subtitle }: { items: Skill[]; eyebrow: string; title: string; subtitle: string }) {
  return (
    <section id="services" className="relative scroll-mt-20 py-20 sm:py-24">
      <Container>
        <SectionTitle
          eyebrow={eyebrow}
          title={title}
          subtitle={subtitle}
        />

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          className="mt-14 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3"
        >
          {items.map((skill, i) => {
            const Icon = iconMap[skill.icon] ?? Target;
            return (
              <motion.article
                key={skill.id}
                variants={fadeUp}
                custom={i}
                className="group relative flex flex-col rounded-2xl border border-border bg-card p-7 transition-all duration-300 hover:-translate-y-1 hover:border-bright/40 hover:shadow-xl hover:shadow-brand/10"
              >
                <span className="flex size-12 items-center justify-center rounded-xl bg-brand text-white transition-transform duration-300 group-hover:scale-105 dark:bg-primary dark:text-primary-foreground">
                  <Icon className="size-5" />
                </span>
                <h3 className="mt-5 font-heading text-lg font-bold leading-snug text-foreground">
                  {skill.title}
                </h3>
                <p className="mt-2.5 text-sm leading-7 text-muted-foreground">
                  {skill.description}
                </p>
                <ul className="mt-5 space-y-2 border-t border-border pt-5">
                  {skill.features.slice(0, 3).map((feature) => (
                    <li key={feature} className="flex items-center gap-2.5 text-sm text-foreground/80">
                      <span className="size-1.5 shrink-0 rounded-full bg-cyan" aria-hidden="true" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <Link
                  href="/#contact"
                  className="mt-6 inline-flex items-center gap-1.5 text-sm font-semibold text-brand transition-colors hover:text-bright dark:text-primary"
                >
                  Discuss this
                  <ArrowUpRight className="size-4 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
                </Link>
              </motion.article>
            );
          })}
        </motion.div>
      </Container>
    </section>
  );
}
