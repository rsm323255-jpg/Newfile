"use client";

import * as React from "react";
import Image from "next/image";
import { Star, Quote } from "lucide-react";
import { motion } from "framer-motion";

import { Container } from "@/components/ui/container";
import { SectionTitle } from "@/components/ui/section-title";
import { Carousel } from "@/components/ui/carousel";
import { scaleIn } from "@/components/common/motion";
import type { Testimonial } from "@/types";

function TestimonialCard({ testimonial }: { testimonial: Testimonial }) {
  return (
    <figure className="flex h-full flex-col rounded-2xl border border-border bg-card p-7 transition-all duration-500 hover:border-primary/30 hover:shadow-xl hover:shadow-primary/5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1">
          {Array.from({ length: 5 }).map((_, i) => (
            <Star
              key={i}
              className={
                i < testimonial.rating
                  ? "size-4 fill-cyan text-cyan"
                  : "size-4 text-muted-foreground/30"
              }
            />
          ))}
        </div>
        <Quote className="size-6 text-bright/30" />
      </div>
      <blockquote className="mt-5 flex-1 text-sm leading-7 text-muted-foreground">
        &ldquo;{testimonial.content}&rdquo;
      </blockquote>
      <figcaption className="mt-6 flex items-center gap-3 border-t border-border pt-5">
        <div className="relative size-11 overflow-hidden rounded-full">
          <Image
            src={testimonial.avatar}
            alt={testimonial.name}
            fill
            sizes="44px"
            className="object-cover"
          />
        </div>
        <div>
          <div className="font-heading text-sm font-bold text-foreground">
            {testimonial.name}
          </div>
          <div className="text-xs text-muted-foreground">
            {testimonial.role} · {testimonial.company}
          </div>
        </div>
      </figcaption>
    </figure>
  );
}

export function TestimonialsContent({
  items: allItems,
  limit,
  eyebrow,
  title,
  subtitle,
}: {
  items: Testimonial[];
  limit?: number;
  eyebrow: string;
  title: string;
  subtitle: string;
}) {
  const items = limit ? allItems.slice(0, limit) : allItems;

  return (
    <section id="testimonials" className="relative scroll-mt-20 overflow-hidden bg-panel py-20 sm:py-24 dark:bg-card">
      <Container>
        <SectionTitle
          eyebrow={eyebrow}
          title={title}
          subtitle={subtitle}
        />

        {items.length > 0 ? (
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.1 }}
            variants={scaleIn}
            className="mx-auto mt-16 max-w-5xl"
          >
            <Carousel
              items={items}
              renderItem={(t) => <TestimonialCard testimonial={t} />}
              itemsPerView={items.length >= 3 ? 2 : 1}
              responsive={[
                { minWidth: 0, items: 1 },
                { minWidth: 768, items: 2 },
              ]}
              className="[mask-image:linear-gradient(to_right,transparent,black_4%,black_96%,transparent)]"
            />
          </motion.div>
        ) : (
          <p className="mt-16 text-center text-muted-foreground">
            Testimonials coming soon.
          </p>
        )}
      </Container>
    </section>
  );
}
