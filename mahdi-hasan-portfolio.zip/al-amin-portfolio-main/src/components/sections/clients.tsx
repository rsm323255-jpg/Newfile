import { getClients, getClientsSection } from "@/services";
import { ClientsContent } from "@/components/sections/clients-content";

export async function ClientsSection() {
  const [clients, section] = await Promise.all([getClients(), getClientsSection()]);

  return <ClientsContent clients={clients} section={section} />;
}
