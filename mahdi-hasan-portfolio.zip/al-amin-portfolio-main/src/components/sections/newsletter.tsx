import { getNewsletter } from "@/services";
import { NewsletterContent } from "@/components/sections/newsletter-content";

export async function NewsletterSection() {
  const data = await getNewsletter();
  return <NewsletterContent data={data} />;
}
