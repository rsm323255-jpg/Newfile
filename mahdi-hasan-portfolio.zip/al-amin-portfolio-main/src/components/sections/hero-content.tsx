"use client";

import * as React from "react";
import Link from "next/link";
import { motion, useReducedMotion } from "framer-motion";
import { ArrowRight, Layers, LineChart, ListChecks } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Container } from "@/components/ui/container";
import { fadeUp, staggerContainer } from "@/components/common/motion";
import type { HeroData } from "@/types";

const principleIcons = [Layers, ListChecks, LineChart];

const stages = [
  { label: "Awareness", width: "100%" },
  { label: "Consideration", width: "78%" },
  { label: "Conversion", width: "56%" },
  { label: "Retention", width: "38%" },
];

function FrameworkCard() {
  const reduce = useReducedMotion();
  return (
    <div className="relative mx-auto w-full max-w-md lg:max-w-none">
      <div
        aria-hidden="true"
        className="absolute -inset-4 rounded-[2rem] bg-gradient-to-br from-bright/15 via-transparent to-cyan/15 blur-2xl"
      />
      <div className="relative overflow-hidden rounded-3xl border border-border bg-card p-6 shadow-xl shadow-brand/10 sm:p-8">
        <div className="flex items-center justify-between">
          <div>
            <p className="font-heading text-[11px] font-medium uppercase tracking-[0.18em] text-muted-foreground">
              The framework
            </p>
            <h2 className="mt-1 font-heading text-lg font-bold text-foreground">
              Structured growth system
            </h2>
          </div>
          <span className="rounded-full border border-cyan/40 bg-cyan/10 px-3 py-1 font-heading text-[11px] font-medium uppercase tracking-wider text-brand dark:text-cyan">
            Illustrative
          </span>
        </div>

        <ul className="mt-7 space-y-3.5" aria-label="Funnel stages">
          {stages.map((stage, i) => (
            <li key={stage.label}>
              <div className="mb-1.5 flex items-center justify-between text-xs">
                <span className="font-heading font-medium text-foreground">
                  {String(i + 1).padStart(2, "0")} · {stage.label}
                </span>
              </div>
              <div className="h-2.5 overflow-hidden rounded-full bg-muted">
                <motion.div
                  initial={reduce ? false : { width: 0 }}
                  animate={{ width: stage.width }}
                  transition={{ duration: 1, delay: 0.4 + i * 0.12, ease: [0.16, 1, 0.3, 1] }}
                  className={i === 0 ? "h-full rounded-full bg-brand dark:bg-primary" : i === 3 ? "h-full rounded-full bg-cyan" : "h-full rounded-full bg-brand/80 dark:bg-primary/80"}
                />
              </div>
            </li>
          ))}
        </ul>

        <div className="mt-7 rounded-2xl bg-muted p-4">
          <svg viewBox="0 0 320 90" className="h-20 w-full" role="img" aria-label="Illustrative upward trend line">
            <defs>
              <linearGradient id="hero-area" x1="0" x2="0" y1="0" y2="1">
                <stop offset="0%" stopColor="var(--brand-bright)" stopOpacity="0.28" />
                <stop offset="100%" stopColor="var(--brand-bright)" stopOpacity="0" />
              </linearGradient>
            </defs>
            <path d="M0 74 C 40 70, 60 60, 95 58 S 150 46, 185 34 S 260 22, 320 8 L320 90 L0 90 Z" fill="url(#hero-area)" />
            <motion.path
              d="M0 74 C 40 70, 60 60, 95 58 S 150 46, 185 34 S 260 22, 320 8"
              fill="none"
              stroke="var(--brand-bright)"
              strokeWidth="3"
              strokeLinecap="round"
              initial={reduce ? false : { pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{ duration: 1.4, delay: 0.5, ease: "easeOut" }}
            />
          </svg>
          <p className="mt-2 text-xs text-muted-foreground">
            Illustrative framework, not client data. Real results are added in the Work section.
          </p>
        </div>
      </div>

      <motion.div
        animate={reduce ? undefined : { y: [0, -8, 0] }}
        transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
        className="absolute -left-3 -top-5 hidden rounded-2xl border border-border bg-card px-4 py-3 shadow-lg shadow-brand/10 sm:block lg:-left-8"
      >
        <p className="font-serif text-base font-semibold italic text-brand dark:text-primary">
          Structure first.
        </p>
      </motion.div>
    </div>
  );
}

export function HeroContent({ data }: { data: HeroData }) {
  // Highlight the closing phrase of the headline in the display serif (Brand Kit: italic Lora for standout lines).
  const marker = "structured, repeatable growth system";
  const idx = data.title.toLowerCase().indexOf(marker);
  const headline =
    idx >= 0 ? (
      <>
        {data.title.slice(0, idx)}
        <span className="font-serif font-semibold italic text-brand dark:text-primary">
          {data.title.slice(idx, idx + marker.length)}
        </span>
        {data.title.slice(idx + marker.length)}
      </>
    ) : (
      data.title
    );

  return (
    <section id="home" className="relative overflow-hidden scroll-mt-20">
      <div aria-hidden="true" className="bg-glow pointer-events-none absolute inset-0" />

      <Container className="relative pb-16 pt-14 sm:pb-20 sm:pt-20 lg:pb-24 lg:pt-24">
        <motion.div
          variants={staggerContainer}
          initial="hidden"
          animate="visible"
          className="grid grid-cols-1 items-center gap-14 lg:grid-cols-[1.1fr_0.9fr] lg:gap-16"
        >
          <motion.div variants={fadeUp} className="flex flex-col items-start">
            <span className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-4 py-1.5 font-heading text-[11px] font-medium uppercase tracking-[0.16em] text-brand dark:text-cyan">
              <span className="size-1.5 rounded-full bg-cyan" aria-hidden="true" />
              {data.subtitle}
            </span>

            <h1 className="mt-6 text-balance font-heading text-4xl font-bold leading-[1.08] tracking-tight text-foreground sm:text-5xl lg:text-[3.5rem]">
              {headline}
            </h1>

            <p className="mt-6 max-w-xl text-base leading-8 text-muted-foreground sm:text-lg">
              {data.description}
            </p>

            <div className="mt-9 flex w-full flex-col gap-3 sm:w-auto sm:flex-row">
              <Button asChild size="xl" className="w-full rounded-full sm:w-auto">
                <Link href="/#contact">
                  {data.ctaPrimary}
                  <ArrowRight className="size-4" />
                </Link>
              </Button>
              <Button asChild size="xl" variant="outline" className="w-full rounded-full sm:w-auto">
                <Link href="/#process">{data.ctaSecondary}</Link>
              </Button>
            </div>

            <ul className="mt-12 grid w-full max-w-xl grid-cols-1 gap-5 border-t border-border pt-8 sm:grid-cols-3">
              {data.stats.map((stat, i) => {
                const Icon = principleIcons[i % principleIcons.length];
                return (
                  <li key={stat.id} className="flex items-start gap-3 sm:block">
                    <span className="flex size-9 shrink-0 items-center justify-center rounded-xl bg-brand/8 text-brand dark:bg-primary/15 dark:text-primary">
                      <Icon className="size-4" />
                    </span>
                    <div>
                      <p className="font-heading text-sm font-bold text-foreground sm:mt-3">
                        {stat.value}
                      </p>
                      <p className="mt-1 text-xs leading-5 text-muted-foreground">{stat.label}</p>
                    </div>
                  </li>
                );
              })}
            </ul>
          </motion.div>

          <motion.div variants={fadeUp} custom={2}>
            <FrameworkCard />
          </motion.div>
        </motion.div>
      </Container>
    </section>
  );
}
