import { getWhyChooseUs, getWhyChooseUsSection } from "@/services";
import { WhyChooseUsContent } from "@/components/sections/why-choose-us-content";

export async function WhyChooseUsSection() {
  const [features, section] = await Promise.all([getWhyChooseUs(), getWhyChooseUsSection()]);
  return <WhyChooseUsContent features={features} eyebrow={section.eyebrow} title={section.title} subtitle={section.subtitle} />;
}
