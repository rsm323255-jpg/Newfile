"use client";

import * as React from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { Mail, MapPin, Phone, Clock, Send, Loader2, CheckCircle2, type LucideIcon } from "lucide-react";
import { motion } from "framer-motion";
import toast from "react-hot-toast";

import { Container } from "@/components/ui/container";
import { SectionTitle } from "@/components/ui/section-title";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { contactSchema, type ContactFormData } from "@/schemas/contact";
import { submitContact } from "@/actions/contact.action";
import { fadeUp, fadeLeft, fadeRight, staggerContainer } from "@/components/common/motion";
import { LinkedInIcon } from "@/components/ui/brand-icons";
import { siteConfig } from "@/config/site";
import type { ContactInfo } from "@/types";

export function ContactContent({ info }: { info: ContactInfo }) {
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [success, setSuccess] = React.useState(false);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<ContactFormData>({
    resolver: zodResolver(contactSchema),
  });

  async function onSubmit(data: ContactFormData) {
    setIsSubmitting(true);
    try {
      const formData = new FormData();
      Object.entries(data).forEach(([key, value]) => formData.append(key, value));
      const result = await submitContact(null, formData);
      if (result.success) {
        setSuccess(true);
        reset();
        toast.success("Message sent! Thanks, I'll get back to you soon.");
      } else {
        toast.error(result.message ?? "Something went wrong.");
      }
    } catch {
      toast.error("Please try again or email me directly.");
    } finally {
      setIsSubmitting(false);
    }
  }

  type Detail = {
    icon: LucideIcon | React.ComponentType<{ className?: string }>;
    label: string;
    value: string;
    href?: string;
    external?: boolean;
  };
  const details: Detail[] = [
    { icon: Mail, label: "Email", value: info.email, href: `mailto:${info.email}` },
    ...(siteConfig.social.linkedin
      ? [{ icon: LinkedInIcon, label: "LinkedIn", value: "linkedin.com/in/mahdi-hasan100", href: siteConfig.social.linkedin, external: true } as Detail]
      : []),
    ...(info.phone ? [{ icon: Phone, label: "Phone", value: info.phone, href: `tel:${info.phone.replace(/\s/g, "")}` } as Detail] : []),
    ...(info.address ? [{ icon: MapPin, label: "Location", value: info.address } as Detail] : []),
    ...(info.workingHours ? [{ icon: Clock, label: "Working hours", value: info.workingHours } as Detail] : []),
  ].filter((d) => d.value);

  return (
    <section id="contact" className="relative scroll-mt-20 py-20 sm:py-24">
      <Container>
        <SectionTitle
          eyebrow={info.eyebrow}
          title={info.title}
          subtitle={info.subtitle}
        />

        <motion.div
          className="mx-auto mt-16 grid max-w-6xl grid-cols-1 gap-8 lg:grid-cols-5"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.1 }}
          variants={staggerContainer}
        >
          <motion.div className="space-y-4 lg:col-span-2" variants={fadeLeft}>
            {details.map((detail, i) => (
              <motion.div
                key={detail.label}
                custom={i}
                variants={fadeUp}
                className="flex items-start gap-4 rounded-2xl border border-border bg-card p-5 transition-colors hover:border-primary/30"
              >
                <div className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-brand/8 text-brand dark:bg-primary/15 dark:text-primary">
                  <detail.icon className="size-5" />
                </div>
                <div className="min-w-0">
                  <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    {detail.label}
                  </div>
                  {detail.href ? (
                    <a
                      href={detail.href}
                      {...(detail.external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
                      className="mt-1 block break-words text-sm font-medium text-foreground hover:text-bright"
                    >
                      {detail.value}
                    </a>
                  ) : (
                    <div className="mt-1 text-sm font-medium text-foreground">
                      {detail.value}
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
          </motion.div>

          <motion.div
            variants={fadeRight}
            className="rounded-3xl border border-border bg-card p-6 shadow-xl shadow-brand/5 sm:p-8 lg:col-span-3"
          >
            {success ? (
              <div className="flex h-full flex-col items-center justify-center py-16 text-center">
                <div className="flex size-16 items-center justify-center rounded-full bg-cyan/15 text-brand dark:text-cyan">
                  <CheckCircle2 className="size-8" />
                </div>
                <h3 className="mt-6 font-heading text-2xl font-bold text-foreground">
                  Message received!
                </h3>
                <p className="mt-2 max-w-sm text-sm text-muted-foreground">
                  Thanks for reaching out. I&apos;ll review your message and get back
                  to you soon.
                </p>
                <Button
                  variant="outline"
                  className="mt-8"
                  onClick={() => setSuccess(false)}
                >
                  Send another message
                </Button>
              </div>
            ) : (
              <form onSubmit={handleSubmit(onSubmit)} className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="contact-name">Full name</Label>
                  <Input
                    id="contact-name"
                    placeholder="Your name"
                    aria-invalid={!!errors.name}
                    {...register("name")}
                  />
                  {errors.name && (
                    <p className="text-xs text-destructive">{errors.name.message}</p>
                  )}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="contact-email">Email address</Label>
                  <Input
                    id="contact-email"
                    type="email"
                    placeholder="you@company.com"
                    aria-invalid={!!errors.email}
                    {...register("email")}
                  />
                  {errors.email && (
                    <p className="text-xs text-destructive">{errors.email.message}</p>
                  )}
                </div>
                <div className="space-y-2 sm:col-span-2">
                  <Label htmlFor="contact-subject">Subject</Label>
                  <Input
                    id="contact-subject"
                    placeholder="What would you like to talk about?"
                    aria-invalid={!!errors.subject}
                    {...register("subject")}
                  />
                  {errors.subject && (
                    <p className="text-xs text-destructive">{errors.subject.message}</p>
                  )}
                </div>
                <div className="space-y-2 sm:col-span-2">
                  <Label htmlFor="contact-message">Message</Label>
                  <Textarea
                    id="contact-message"
                    rows={5}
                    placeholder="Tell me about your business, goals, and timeline..."
                    aria-invalid={!!errors.message}
                    {...register("message")}
                  />
                  {errors.message && (
                    <p className="text-xs text-destructive">{errors.message.message}</p>
                  )}
                </div>
                <div className="sm:col-span-2">
                  <Button
                    type="submit"
                    size="lg"
                    className="w-full rounded-full sm:w-auto"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 className="size-4 animate-spin" />
                        Sending...
                      </>
                    ) : (
                      <>
                        Send message
                        <Send className="size-4" />
                      </>
                    )}
                  </Button>
                </div>
              </form>
            )}
          </motion.div>
        </motion.div>
      </Container>
    </section>
  );
}
