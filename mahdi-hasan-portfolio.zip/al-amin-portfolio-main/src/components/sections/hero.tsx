import { getHero } from "@/services";
import { HeroContent } from "@/components/sections/hero-content";

export async function HeroSection() {
  const hero = await getHero();
  return <HeroContent data={hero} />;
}
