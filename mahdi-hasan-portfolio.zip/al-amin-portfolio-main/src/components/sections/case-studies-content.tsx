"use client";

import * as React from "react";
import Link from "next/link";
import Image from "next/image";
import { motion } from "framer-motion";
import { ArrowRight, TrendingUp } from "lucide-react";

import { Container } from "@/components/ui/container";
import { SectionTitle } from "@/components/ui/section-title";
import { Badge } from "@/components/ui/badge";
import { fadeUp, staggerContainer } from "@/components/common/motion";
import type { CaseStudy } from "@/types";

export function CaseStudiesContent({
  studies: allStudies,
  limit,
  eyebrow,
  title,
  subtitle,
}: {
  studies: CaseStudy[];
  limit?: number;
  eyebrow: string;
  title: string;
  subtitle: string;
}) {
  const studies = limit ? allStudies.slice(0, limit) : allStudies;

  return (
    <section className="relative overflow-hidden bg-muted/30 py-24 sm:py-28">
      <div className="pointer-events-none absolute -left-24 top-24 size-80 rounded-full bg-primary/5 blur-3xl" />
      <Container>
        <SectionTitle
          eyebrow={eyebrow}
          title={title}
          subtitle={subtitle}
        />

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          className="mt-16 grid grid-cols-1 gap-6 lg:grid-cols-3"
        >
          {studies.map((study, i) => (
            <motion.div
              key={study.id}
              variants={fadeUp}
              custom={i}
              className="group flex flex-col overflow-hidden rounded-2xl border border-border bg-card transition-all duration-500 hover:-translate-y-1.5 hover:border-primary/30 hover:shadow-2xl hover:shadow-primary/10"
            >
              <div className="relative aspect-[16/10] overflow-hidden bg-muted">
                <Image
                  src={study.image}
                  alt={study.title}
                  fill
                  sizes="(max-width: 768px) 100vw, 33vw"
                  className="object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
                <Badge className="absolute left-4 top-4 bg-background/80 text-foreground backdrop-blur">
                  {study.client}
                </Badge>
              </div>

              <div className="flex flex-1 flex-col p-6">
                <div className="flex flex-wrap gap-2">
                  {study.tags.map((tag) => (
                    <Badge key={tag} variant="secondary">
                      {tag}
                    </Badge>
                  ))}
                </div>
                <h3 className="mt-4 font-heading text-lg font-bold leading-snug text-foreground transition-colors group-hover:text-primary">
                  {study.title}
                </h3>

                <div className="mt-5 grid grid-cols-3 gap-3">
                  {study.results.map((result) => (
                    <div
                      key={result.metric}
                      className="rounded-xl border border-border bg-muted/50 p-3 text-center"
                    >
                      <div className="font-heading text-sm font-bold text-gradient">
                        {result.after}
                      </div>
                      <div className="mt-0.5 line-clamp-2 text-[10px] leading-tight text-muted-foreground">
                        {result.metric}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-auto flex items-center justify-between pt-6">
                  <span className="flex items-center gap-1.5 text-xs font-medium text-emerald-600 dark:text-emerald-400">
                    <TrendingUp className="size-3.5" />
                    Measurable impact
                  </span>
                  <Link
                    href={`/case-studies/${study.slug}`}
                    className="inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:underline"
                  >
                    Read study
                    <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" />
                  </Link>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </Container>
    </section>
  );
}
