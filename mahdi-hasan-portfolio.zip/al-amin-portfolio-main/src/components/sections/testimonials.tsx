import { getTestimonials, getTestimonialsSection } from "@/services";
import { TestimonialsContent } from "@/components/sections/testimonials-content";

/** Hidden entirely until genuine testimonials exist (never show fabricated ones). */
export async function TestimonialsSection({ limit }: { limit?: number }) {
  const [items, section] = await Promise.all([getTestimonials(), getTestimonialsSection()]);
  if (items.length === 0) return null;
  return (
    <TestimonialsContent
      items={items}
      limit={limit}
      eyebrow={section.eyebrow}
      title={section.title}
      subtitle={section.subtitle}
    />
  );
}
