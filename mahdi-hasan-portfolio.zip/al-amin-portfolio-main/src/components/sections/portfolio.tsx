import { getPortfolio, getPortfolioSection } from "@/services";
import { PortfolioContent } from "@/components/sections/portfolio-content";

export async function PortfolioSection({ limit }: { limit?: number }) {
  const [items, section] = await Promise.all([getPortfolio(), getPortfolioSection()]);
  return <PortfolioContent items={items} limit={limit} eyebrow={section.eyebrow} title={section.title} subtitle={section.subtitle} />;
}
