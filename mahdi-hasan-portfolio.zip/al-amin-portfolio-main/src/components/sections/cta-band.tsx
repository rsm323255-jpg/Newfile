"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";

import { Container } from "@/components/ui/container";
import { Button } from "@/components/ui/button";
import { fadeUp } from "@/components/common/motion";

/** Closing call-to-action on Primary Blue with the dot-grid texture (one texture per composition). */
export function CtaBand() {
  return (
    <section aria-labelledby="cta-heading" className="py-6 sm:py-10">
      <Container>
        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          className="bg-dots relative overflow-hidden rounded-[2rem] bg-brand px-6 py-14 text-center text-white sm:px-12 sm:py-16"
        >
          <p className="font-heading text-xs font-medium uppercase tracking-[0.2em] text-white/90">
            Ready when you are
          </p>
          <h2
            id="cta-heading"
            className="mx-auto mt-4 max-w-2xl text-balance font-heading text-3xl font-bold tracking-tight sm:text-4xl"
          >
            Ready to turn ad spend into a{" "}
            <span className="font-serif font-semibold italic">growth system?</span>
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-base leading-7 text-white/85">
            Tell me about your business and what you want paid advertising to do. Structure first,
            creativity second.
          </p>
          <div className="mt-8 flex justify-center">
            <Button
              asChild
              size="xl"
              className="rounded-full bg-white text-brand shadow-xl shadow-black/20 hover:bg-white/90 dark:bg-white dark:text-brand"
            >
              <Link href="/#contact">
                Book a Consultation
                <ArrowRight className="size-4" />
              </Link>
            </Button>
          </div>
        </motion.div>
      </Container>
    </section>
  );
}
