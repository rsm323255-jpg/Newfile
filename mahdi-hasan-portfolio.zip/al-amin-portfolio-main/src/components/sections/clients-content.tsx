"use client";

import { Container } from "@/components/ui/container";
import type { Client } from "@/types";

/** Focus-area marquee (reference: "brands/platforms" strip). Pauses on hover and for reduced-motion users. */
export function ClientsContent({
  clients,
  section,
}: {
  clients: Client[];
  section: { eyebrow: string; title: string; subtitle: string };
}) {
  const doubled = [...clients, ...clients];

  return (
    <section
      aria-label={section.title}
      className="border-y border-border bg-panel py-10 dark:bg-card"
    >
      <Container>
        <p className="text-center font-heading text-xs font-medium uppercase tracking-[0.2em] text-muted-foreground">
          {section.title}
        </p>
      </Container>

      <div className="relative mt-6 overflow-hidden [mask-image:linear-gradient(to_right,transparent,black_10%,black_90%,transparent)]">
        <ul className="flex w-max animate-marquee items-center gap-3 hover:[animation-play-state:paused]">
          {doubled.map((client, i) => (
            <li
              key={`${client.id}-${i}`}
              aria-hidden={i >= clients.length ? true : undefined}
              className="flex items-center gap-2.5 whitespace-nowrap rounded-full border border-border bg-background px-5 py-2.5 font-heading text-sm font-medium text-foreground"
            >
              <span className="size-1.5 rounded-full bg-cyan" aria-hidden="true" />
              {client.logo}
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
