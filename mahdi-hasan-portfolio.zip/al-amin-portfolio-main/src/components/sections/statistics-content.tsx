"use client";

import * as React from "react";
import { useInView } from "framer-motion";
import { motion } from "framer-motion";

import { Container } from "@/components/ui/container";
import { staggerContainer, fadeUp } from "@/components/common/motion";
import type { Statistic } from "@/types";

function parseValue(value: string) {
  const match = value.match(/^([\d.,]+)(.*)$/);
  if (!match) return { prefix: "", number: 0, suffix: value };
  const raw = match[1].replace(/,/g, "");
  return {
    prefix: "",
    number: parseFloat(raw) || 0,
    suffix: match[2],
  };
}

function AnimatedStat({
  value,
  label,
  index,
}: {
  value: string;
  label: string;
  index: number;
}) {
  const ref = React.useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "-60px" });
  const { number, suffix } = parseValue(value);
  const [display, setDisplay] = React.useState(0);

  React.useEffect(() => {
    if (!inView) return;
    const duration = 1800;
    const start = performance.now();
    let raf: number;
    const tick = (now: number) => {
      const progress = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setDisplay(number * eased);
      if (progress < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [inView, number]);

  const formatted = display.toLocaleString("en-US", {
    maximumFractionDigits: number % 1 !== 0 ? 1 : 0,
  });

  return (
    <motion.div variants={fadeUp} custom={index} className="text-center">
      <div ref={ref} className="font-heading text-4xl font-bold text-white sm:text-5xl">
        {formatted}
        <span className="text-cyan">{suffix}</span>
      </div>
      <div className="mt-2 text-sm text-white/70">{label}</div>
    </motion.div>
  );
}

export function StatisticsContent({ statistics, eyebrow, title, subtitle }: { statistics: Statistic[]; eyebrow: string; title: string; subtitle: string }) {
  return (
    <section className="relative overflow-hidden py-24 sm:py-28">
      <div className="absolute inset-0 bg-primary" />
      <div className="absolute inset-0">
        <div className="bg-grid absolute inset-0 opacity-40 [mask-image:radial-gradient(ellipse_70%_70%_at_50%_50%,black,transparent)]" />
        <div className="absolute -top-24 left-1/4 size-72 animate-aurora rounded-full bg-white/10 blur-3xl" />
        <div className="absolute bottom-0 right-1/4 size-72 animate-aurora rounded-full bg-primary/20 blur-3xl [animation-delay:4s]" />
      </div>

      <Container className="relative">
        <div className="mb-16 text-center">
          <p className="mb-3 text-sm font-semibold uppercase tracking-widest text-white/60">{eyebrow}</p>
          <h2 className="font-heading text-3xl font-bold tracking-tight text-white sm:text-4xl">{title}</h2>
          <p className="mx-auto mt-4 max-w-2xl text-lg text-white/70">{subtitle}</p>
        </div>

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          className="grid grid-cols-2 gap-10 sm:grid-cols-3 lg:grid-cols-6"
        >
          {statistics.map((stat, i) => (
            <AnimatedStat
              key={stat.id}
              value={stat.value}
              label={stat.label}
              index={i}
            />
          ))}
        </motion.div>
      </Container>
    </section>
  );
}
