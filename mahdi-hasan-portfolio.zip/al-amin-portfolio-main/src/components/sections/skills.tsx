import { getSkills, getSkillsSection } from "@/services";
import { SkillsContent } from "@/components/sections/skills-content";

export async function SkillsSection({ limit }: { limit?: number }) {
  const [skills, section] = await Promise.all([getSkills(), getSkillsSection()]);
  const items = limit ? skills.slice(0, limit) : skills;
  return (
    <SkillsContent
      items={items}
      eyebrow={section.eyebrow}
      title={section.title}
      subtitle={section.subtitle}
    />
  );
}
