import { getCaseStudies, getCaseStudiesSection } from "@/services";
import { CaseStudiesContent } from "@/components/sections/case-studies-content";

export async function CaseStudiesSection({ limit }: { limit?: number }) {
  const [studies, section] = await Promise.all([getCaseStudies(), getCaseStudiesSection()]);
  return <CaseStudiesContent studies={studies} limit={limit} eyebrow={section.eyebrow} title={section.title} subtitle={section.subtitle} />;
}
