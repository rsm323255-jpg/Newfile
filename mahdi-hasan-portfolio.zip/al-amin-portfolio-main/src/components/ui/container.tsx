import * as React from "react";

import { cn } from "@/lib/utils";

interface ContainerProps extends React.ComponentProps<"div"> {
  size?: "sm" | "md" | "lg" | "xl" | "full";
}

function Container({ size = "lg", className, ...props }: ContainerProps) {
  const sizes = {
    sm: "max-w-3xl",
    md: "max-w-5xl",
    lg: "max-w-7xl",
    xl: "max-w-screen-2xl",
    full: "max-w-full",
  };

  return (
    <div
      className={cn("mx-auto w-full px-6 lg:px-8", sizes[size], className)}
      {...props}
    />
  );
}

export { Container };
