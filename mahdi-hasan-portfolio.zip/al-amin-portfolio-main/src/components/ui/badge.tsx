import * as React from "react";

import { cn } from "@/lib/utils";

const badgeVariants = {
  default:
    "bg-primary text-primary-foreground shadow-sm",
  secondary:
    "bg-secondary text-secondary-foreground",
  outline:
    "border border-border text-foreground",
  gradient:
    "bg-primary text-white shadow-md shadow-primary/20",
  success: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20",
  accent: "bg-accent/10 text-accent dark:text-accent border border-accent/25",
  ghost: "bg-muted text-muted-foreground",
} as const;

type BadgeVariant = keyof typeof badgeVariants;

interface BadgeProps extends React.ComponentProps<"span"> {
  variant?: BadgeVariant;
}

function Badge({ className, variant = "default", ...props }: BadgeProps) {
  return (
    <span
      data-slot="badge"
      className={cn(
        "inline-flex items-center justify-center gap-1.5 rounded-full border border-transparent px-3 py-1 text-xs font-medium whitespace-nowrap transition-colors",
        badgeVariants[variant],
        className
      )}
      {...props}
    />
  );
}

export { Badge, badgeVariants };
