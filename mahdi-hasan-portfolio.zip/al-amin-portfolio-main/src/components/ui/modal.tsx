"use client";

import * as React from "react";
import { createPortal } from "react-dom";
import { AnimatePresence, motion } from "framer-motion";
import { X } from "lucide-react";

import { cn } from "@/lib/utils";

interface ModalProps {
  open: boolean;
  onClose: () => void;
  children: React.ReactNode;
  className?: string;
  ariaLabel?: string;
}

export function Modal({
  open,
  onClose,
  children,
  className,
  ariaLabel = "Dialog",
}: ModalProps) {
  const [mounted, setMounted] = React.useState(false);

  React.useEffect(() => {
    setMounted(true);
  }, []);

  React.useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);

  if (!mounted) return null;

  return createPortal(
    <AnimatePresence>
      {open && (
        <div className="relative z-[100]" role="dialog" aria-modal="true" aria-label={ariaLabel}>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.94, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 10 }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
            className={cn(
              "fixed inset-0 z-10 flex items-center justify-center p-4 sm:p-8",
              className
            )}
          >
            <div className="relative max-h-full w-full max-w-3xl overflow-y-auto rounded-3xl border border-border bg-card shadow-2xl">
              <button
                onClick={onClose}
                aria-label="Close dialog"
                className="absolute right-4 top-4 z-20 flex size-9 items-center justify-center rounded-full bg-background/80 text-muted-foreground backdrop-blur transition-colors hover:bg-background hover:text-foreground"
              >
                <X className="size-4" />
              </button>
              {children}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>,
    document.body
  );
}

export function Lightbox({
  open,
  onClose,
  image,
  title,
  description,
}: {
  open: boolean;
  onClose: () => void;
  image: string;
  title: string;
  description?: string;
}) {
  return (
    <Modal open={open} onClose={onClose} ariaLabel={title} className="p-2 sm:p-4">
      <div className="overflow-hidden rounded-3xl bg-card">
        <div className="flex items-center justify-center bg-muted/40 p-2">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={image}
            alt={title}
            className="max-h-[75vh] w-auto max-w-full object-contain"
          />
        </div>
        <div className="p-6 sm:p-8">
          <h3 className="font-heading text-xl font-bold text-foreground sm:text-2xl">
            {title}
          </h3>
          {description && (
            <p className="mt-3 text-sm leading-7 text-muted-foreground">
              {description}
            </p>
          )}
        </div>
      </div>
    </Modal>
  );
}
