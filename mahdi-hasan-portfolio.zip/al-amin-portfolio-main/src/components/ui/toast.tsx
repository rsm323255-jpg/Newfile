"use client";

import { AnimatePresence, motion } from "framer-motion";
import { CheckCircle2, XCircle, Info, X } from "lucide-react";

import { useToastStore, type ToastType } from "@/store/toast-store";

const toastConfig: Record<
  ToastType,
  { icon: React.ReactNode; accent: string }
> = {
  success: {
    icon: <CheckCircle2 className="size-5 text-cyan" />,
    accent: "border-emerald-500/30",
  },
  error: {
    icon: <XCircle className="size-5 text-red-500" />,
    accent: "border-red-500/30",
  },
  info: {
    icon: <Info className="size-5 text-primary" />,
    accent: "border-primary/30",
  },
};

export function Toaster() {
  const toasts = useToastStore((state) => state.toasts);
  const dismiss = useToastStore((state) => state.dismiss);

  return (
    <div
      className="pointer-events-none fixed inset-x-0 top-20 z-[200] flex flex-col items-center gap-3 px-4"
      aria-live="polite"
    >
      <AnimatePresence>
        {toasts.map((toast) => {
          const config = toastConfig[toast.type];
          return (
            <motion.div
              key={toast.id}
              layout
              initial={{ opacity: 0, y: -16, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -10, scale: 0.95 }}
              transition={{ duration: 0.25, ease: "easeOut" }}
              className={`pointer-events-auto flex w-full max-w-md items-start gap-3 rounded-2xl border ${config.accent} bg-card/95 p-4 shadow-2xl backdrop-blur`}
            >
              <span className="mt-0.5 shrink-0">{config.icon}</span>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-semibold text-foreground">
                  {toast.title}
                </p>
                {toast.description && (
                  <p className="mt-0.5 text-sm text-muted-foreground">
                    {toast.description}
                  </p>
                )}
              </div>
              <button
                onClick={() => dismiss(toast.id)}
                aria-label="Dismiss notification"
                className="shrink-0 rounded-lg p-1 text-muted-foreground transition-colors hover:text-foreground"
              >
                <X className="size-4" />
              </button>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}
