"use client";

import * as React from "react";
import { motion, type PanInfo } from "framer-motion";
import { ChevronLeft, ChevronRight } from "lucide-react";

import { cn } from "@/lib/utils";

interface ResponsiveConfig {
  minWidth: number;
  items: number;
}

interface CarouselProps<T> extends React.ComponentProps<"div"> {
  items: T[];
  renderItem: (item: T, index: number) => React.ReactNode;
  itemsPerView?: number;
  responsive?: ResponsiveConfig[];
  showControls?: boolean;
  showDots?: boolean;
  className?: string;
  itemClassName?: string;
}

export function Carousel<T>({
  items,
  renderItem,
  itemsPerView = 3,
  responsive,
  showControls = true,
  showDots = true,
  className,
  itemClassName,
}: CarouselProps<T>) {
  const [current, setCurrent] = React.useState(0);
  const [containerWidth, setContainerWidth] = React.useState(0);
  const ref = React.useRef<HTMLDivElement>(null);

  const effectiveItemsPerView = React.useMemo(() => {
    if (!responsive || containerWidth === 0) return itemsPerView;
    const matched = responsive.filter((r) => containerWidth >= r.minWidth);
    if (matched.length === 0) return itemsPerView;
    return matched[matched.length - 1].items;
  }, [responsive, containerWidth, itemsPerView]);

  const maxIndex = Math.max(0, items.length - effectiveItemsPerView);

  React.useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new ResizeObserver((entries) => {
      setContainerWidth(entries[0].contentRect.width);
    });
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  React.useEffect(() => {
    setCurrent((c) => Math.min(c, maxIndex));
  }, [maxIndex]);

  const goTo = (index: number) => {
    setCurrent(Math.max(0, Math.min(index, maxIndex)));
  };

  const handleDragEnd = (_: unknown, info: PanInfo) => {
    if (info.offset.x < -50) goTo(current + 1);
    else if (info.offset.x > 50) goTo(current - 1);
  };

  return (
    <div className={className}>
      <div className="relative overflow-hidden" ref={ref}>
        <motion.div
          className="flex gap-6"
          animate={{ x: `-${current * (containerWidth + 24)}px` }}
          transition={{ type: "spring", stiffness: 220, damping: 30 }}
          drag="x"
          dragConstraints={{ left: 0, right: 0 }}
          dragElastic={0.08}
          onDragEnd={handleDragEnd}
        >
          {items.map((item, i) => (
            <div
              key={i}
              className={cn("w-full shrink-0", itemClassName)}
              style={{
                width:
                  containerWidth > 0
                    ? `calc((100% - ${(effectiveItemsPerView - 1) * 24}px) / ${effectiveItemsPerView})`
                    : `${100 / effectiveItemsPerView}%`,
              }}
            >
              {renderItem(item, i)}
            </div>
          ))}
        </motion.div>
      </div>

      {(showControls || showDots) && (
        <div className="mt-8 flex items-center justify-center gap-6">
          {showDots && (
            <div className="flex items-center gap-2">
              {Array.from({ length: maxIndex + 1 }).map((_, i) => (
                <button
                  key={i}
                  onClick={() => goTo(i)}
                  aria-label={`Go to slide ${i + 1}`}
                  className={cn(
                    "h-2 rounded-full transition-all duration-300",
                    i === current
                      ? "w-7 bg-primary"
                      : "w-2 bg-muted-foreground/30 hover:bg-muted-foreground/50"
                  )}
                />
              ))}
            </div>
          )}
          {showControls && (
            <div className="flex items-center gap-2">
              <button
                onClick={() => goTo(current - 1)}
                disabled={current === 0}
                aria-label="Previous slide"
                className="flex size-10 items-center justify-center rounded-full border border-border bg-background text-foreground transition-all hover:border-primary/40 hover:text-primary disabled:pointer-events-none disabled:opacity-40"
              >
                <ChevronLeft className="size-4" />
              </button>
              <button
                onClick={() => goTo(current + 1)}
                disabled={current >= maxIndex}
                aria-label="Next slide"
                className="flex size-10 items-center justify-center rounded-full border border-border bg-background text-foreground transition-all hover:border-primary/40 hover:text-primary disabled:pointer-events-none disabled:opacity-40"
              >
                <ChevronRight className="size-4" />
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
