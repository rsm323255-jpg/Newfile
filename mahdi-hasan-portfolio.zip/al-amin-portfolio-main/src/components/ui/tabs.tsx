"use client";

import * as React from "react";
import { AnimatePresence, motion } from "framer-motion";

import { cn } from "@/lib/utils";

interface TabsProps extends React.ComponentProps<"div"> {
  tabs: { value: string; label: string; content: React.ReactNode }[];
  defaultValue?: string;
}

function Tabs({ tabs, defaultValue, className, ...props }: TabsProps) {
  const [active, setActive] = React.useState(
    defaultValue ?? tabs[0]?.value ?? ""
  );
  const activeTab = tabs.find((t) => t.value === active) ?? tabs[0];

  return (
    <div className={className} {...props}>
      <div
        role="tablist"
        className="inline-flex w-full max-w-full items-center gap-1 overflow-x-auto rounded-full border border-border bg-muted/60 p-1 sm:w-auto"
        aria-label="Tabs"
      >
        {tabs.map((tab) => {
          const isActive = tab.value === active;
          return (
            <button
              key={tab.value}
              role="tab"
              aria-selected={isActive}
              aria-controls={`panel-${tab.value}`}
              onClick={() => setActive(tab.value)}
              className={cn(
                "relative flex-1 cursor-pointer rounded-full px-5 py-2.5 text-sm font-medium whitespace-nowrap transition-colors sm:flex-none",
                isActive
                  ? "text-white"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {isActive && (
                <motion.span
                  layoutId="tab-pill"
                  className="absolute inset-0 rounded-full bg-primary shadow-lg shadow-primary/25"
                  transition={{ type: "spring", bounce: 0.25, duration: 0.5 }}
                />
              )}
              <span className="relative z-10">{tab.label}</span>
            </button>
          );
        })}
      </div>
      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab?.value}
          role="tabpanel"
          id={`panel-${activeTab?.value}`}
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.3, ease: "easeOut" }}
          className="mt-8"
        >
          {activeTab?.content}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

export { Tabs };
