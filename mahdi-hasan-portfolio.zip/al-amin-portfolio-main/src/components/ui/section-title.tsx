import * as React from "react";

import { cn } from "@/lib/utils";

interface SectionTitleProps extends Omit<React.ComponentProps<"div">, "title"> {
  eyebrow?: string;
  title: React.ReactNode;
  subtitle?: React.ReactNode;
  align?: "left" | "center" | "right";
  /** Use on Primary Blue / Navy surfaces. */
  tone?: "default" | "light";
}

function SectionTitle({
  eyebrow,
  title,
  subtitle,
  align = "center",
  tone = "default",
  className,
  ...props
}: SectionTitleProps) {
  const light = tone === "light";
  return (
    <div
      className={cn(
        "flex flex-col gap-4",
        align === "center" && "items-center text-center",
        align === "right" && "items-end text-right",
        className
      )}
      {...props}
    >
      {eyebrow && (
        <span
          className={cn(
            "font-heading text-xs font-medium uppercase tracking-[0.2em]",
            light ? "text-cyan" : "text-brand dark:text-cyan"
          )}
        >
          {eyebrow}
        </span>
      )}
      <h2
        className={cn(
          "max-w-3xl text-balance font-heading text-3xl font-bold tracking-tight sm:text-4xl lg:text-[2.75rem] lg:leading-[1.1]",
          light ? "text-white" : "text-foreground"
        )}
      >
        {title}
      </h2>
      {/* Accent rule: the single graphic accent allowed on light surfaces (Brand Kit p.11) */}
      <span aria-hidden="true" className="h-0.5 w-12 rounded-full bg-cyan" />
      {subtitle && (
        <p
          className={cn(
            "max-w-2xl text-base leading-7 sm:text-lg",
            light ? "text-white/80" : "text-muted-foreground"
          )}
        >
          {subtitle}
        </p>
      )}
    </div>
  );
}

export { SectionTitle };
