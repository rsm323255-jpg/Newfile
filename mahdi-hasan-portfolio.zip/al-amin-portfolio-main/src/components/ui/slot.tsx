import * as React from "react";
import { cn } from "@/lib/utils";

interface SlotProps extends React.HTMLAttributes<HTMLElement> {
  children?: React.ReactNode;
}

export function Slot({ children, className, style, ...props }: SlotProps) {
  if (!React.isValidElement(children)) {
    return null;
  }

  const child = children as React.ReactElement<{
    className?: string;
    style?: React.CSSProperties;
  }>;

  return React.cloneElement(child, {
    className: cn(child.props.className, className),
    style: style ? { ...child.props.style, ...style } : child.props.style,
    ...props,
  });
}
