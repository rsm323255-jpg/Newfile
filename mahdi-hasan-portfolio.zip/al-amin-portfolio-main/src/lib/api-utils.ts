import { NextRequest, NextResponse } from "next/server";
import { jwtVerify, type JWTPayload } from "jose";
import { rateLimit, rateLimitHeaders } from "@/lib/rate-limit";

const JWT_SECRET = new TextEncoder().encode(
  process.env.JWT_SECRET ?? "jwt-secret-key-for-dev-only-change-in-production"
);

export type AuthPayload = JWTPayload & {
  userId: string;
  email: string;
  name: string;
  role: "admin" | "editor" | "viewer";
  type: "access" | "refresh";
};

export async function verifyAdminAuth(
  request: NextRequest
): Promise<{ payload: AuthPayload } | { error: NextResponse }> {
  const token = request.cookies.get("admin_access_token")?.value;
  if (!token) {
    return {
      error: NextResponse.json(
        { success: false, error: "Unauthorized" },
        { status: 401 }
      ),
    };
  }
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET);
    const typedPayload = payload as AuthPayload;
    if (typedPayload.type !== "access") {
      return {
        error: NextResponse.json(
          { success: false, error: "Invalid token type" },
          { status: 401 }
        ),
      };
    }
    return { payload: typedPayload };
  } catch {
    return {
      error: NextResponse.json(
        { success: false, error: "Invalid token" },
        { status: 401 }
      ),
    };
  }
}

export function requireRole(
  auth: { payload: AuthPayload } | { error: NextResponse },
  ...roles: AuthPayload["role"][]
): { payload: AuthPayload } | { error: NextResponse } {
  if ("error" in auth) return auth;
  if (!roles.includes(auth.payload.role)) {
    return {
      error: NextResponse.json(
        { success: false, error: "Forbidden: insufficient permissions" },
        { status: 403 }
      ),
    };
  }
  return auth;
}

export function successResponse<T>(data: T, status = 200) {
  return NextResponse.json(
    { success: true, data } as { success: true; data: T },
    { status }
  );
}

export function errorResponse(error: string, status = 400) {
  return NextResponse.json(
    { success: false, error } as { success: false; error: string },
    { status }
  );
}

export function generateId(prefix: string) {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

/**
 * Combined auth + rate limit for admin CRUD endpoints.
 * Rate limits: 60 writes/min, 120 reads/min per IP.
 */
export async function verifyAdminWithRateLimit(
  request: NextRequest,
  options: { limit?: number; windowMs?: number; method?: string } = {}
): Promise<{ payload: AuthPayload } | { error: NextResponse }> {
  const { limit = 60, windowMs = 60_000, method = request.method } = options;

  // Read operations get higher limits
  const isRead = method === "GET";
  const actualLimit = isRead ? 120 : limit;

  const rl = await rateLimit(request, `admin-crud`, actualLimit, windowMs);
  if (!rl.allowed) {
    return {
      error: NextResponse.json(
        { success: false, error: "Too many requests. Please slow down." },
        {
          status: 429,
          headers: rateLimitHeaders(rl.remaining, rl.resetAt, actualLimit),
        }
      ),
    };
  }

  return verifyAdminAuth(request);
}
