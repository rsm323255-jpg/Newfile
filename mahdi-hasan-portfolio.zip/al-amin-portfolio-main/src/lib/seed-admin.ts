import "dotenv/config";
import { connectToDatabase } from "@/lib/mongodb";
import { UserModel } from "@/models";

async function seedAdmin() {
  const email = process.env.ADMIN_EMAIL;
  const password = process.env.ADMIN_PASSWORD;

  if (!email || !password) {
    console.error("Missing ADMIN_EMAIL or ADMIN_PASSWORD in .env");
    process.exit(1);
  }

  console.log("Connecting to database...");
  await connectToDatabase();
  console.log("Connected!\n");

  const existing = await UserModel.findOne({ email });
  if (existing) {
    console.log(`Admin user "${email}" already exists. Updating password...`);
    existing.password = password;
    existing.isActive = true;
    existing.role = "admin";
    await existing.save();
    console.log("Updated!\n");
  } else {
    console.log(`Creating admin user "${email}"...`);
    await UserModel.create({
      name: "Mahdi Hasan",
      email,
      password,
      role: "admin",
      isActive: true,
    });
    console.log("Created!\n");
  }

  console.log("Done!");
  process.exit(0);
}

seedAdmin().catch((err) => {
  console.error("Failed:", err);
  process.exit(1);
});
