import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";
import { connectToDatabase } from "@/lib/mongodb";
import { UserModel } from "@/models";

const JWT_SECRET = new TextEncoder().encode(
  process.env.JWT_SECRET ?? "jwt-secret-key-for-dev-only-change-in-production"
);

const ACCESS_TOKEN_EXPIRY = "15m";
const REFRESH_TOKEN_EXPIRY = "7d";

const ACCESS_TOKEN_COOKIE = "admin_access_token";
const REFRESH_TOKEN_COOKIE = "admin_refresh_token";

export interface TokenPayload {
  userId: string;
  email: string;
  name: string;
  role: "admin" | "editor" | "viewer";
  type: "access" | "refresh";
}

export async function createAccessToken(payload: Omit<TokenPayload, "type">): Promise<string> {
  return new SignJWT({ ...payload, type: "access" })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(ACCESS_TOKEN_EXPIRY)
    .sign(JWT_SECRET);
}

export async function createRefreshToken(payload: Omit<TokenPayload, "type">): Promise<string> {
  return new SignJWT({ ...payload, type: "refresh" })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(REFRESH_TOKEN_EXPIRY)
    .sign(JWT_SECRET);
}

export async function verifyToken(token: string): Promise<TokenPayload | null> {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET);
    return payload as unknown as TokenPayload;
  } catch {
    return null;
  }
}

export async function setTokenCookies(accessToken: string, refreshToken: string) {
  const cookieStore = await cookies();

  cookieStore.set(ACCESS_TOKEN_COOKIE, accessToken, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 15 * 60, // 15 minutes
  });

  cookieStore.set(REFRESH_TOKEN_COOKIE, refreshToken, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 7 * 24 * 60 * 60, // 7 days
  });
}

export async function removeTokenCookies() {
  const cookieStore = await cookies();
  cookieStore.delete(ACCESS_TOKEN_COOKIE);
  cookieStore.delete(REFRESH_TOKEN_COOKIE);
}

export async function getAccessToken(): Promise<string | null> {
  const cookieStore = await cookies();
  return cookieStore.get(ACCESS_TOKEN_COOKIE)?.value ?? null;
}

export async function getRefreshToken(): Promise<string | null> {
  const cookieStore = await cookies();
  return cookieStore.get(REFRESH_TOKEN_COOKIE)?.value ?? null;
}

export async function generateTokenPair(
  payload: Omit<TokenPayload, "type">
): Promise<{ accessToken: string; refreshToken: string }> {
  const [accessToken, refreshToken] = await Promise.all([
    createAccessToken(payload),
    createRefreshToken(payload),
  ]);
  return { accessToken, refreshToken };
}

export async function authenticateUser(
  email: string,
  password: string
): Promise<{ user: Omit<TokenPayload, "type">; accessToken: string; refreshToken: string } | { error: string }> {
  await connectToDatabase();

  const user = await UserModel.findOne({
    email: email.toLowerCase(),
    isActive: true,
  }).select("+password");

  if (!user) {
    return { error: "Invalid email or password." };
  }

  const isPasswordValid = await user.comparePassword(password);
  if (!isPasswordValid) {
    return { error: "Invalid email or password." };
  }

  user.lastLogin = new Date();
  await user.save();

  const payload = {
    userId: user._id.toString(),
    email: user.email,
    name: user.name,
    role: user.role,
  };

  const tokens = await generateTokenPair(payload);

  return { user: payload, ...tokens };
}

export async function refreshAccessToken(
  refreshToken: string
): Promise<{ accessToken: string; refreshToken: string } | { error: string }> {
  const payload = await verifyToken(refreshToken);

  if (!payload || payload.type !== "refresh") {
    return { error: "Invalid refresh token." };
  }

  await connectToDatabase();
  const user = await UserModel.findOne({
    _id: payload.userId,
    isActive: true,
  });

  if (!user) {
    return { error: "User not found or inactive." };
  }

  const newPayload = {
    userId: user._id.toString(),
    email: user.email,
    name: user.name,
    role: user.role,
  };

  return generateTokenPair(newPayload);
}

export async function getCurrentUser(): Promise<Omit<TokenPayload, "type"> | null> {
  const accessToken = await getAccessToken();
  if (!accessToken) return null;

  const payload = await verifyToken(accessToken);
  if (!payload || payload.type !== "access") return null;

  return {
    userId: payload.userId,
    email: payload.email,
    name: payload.name,
    role: payload.role,
  };
}
