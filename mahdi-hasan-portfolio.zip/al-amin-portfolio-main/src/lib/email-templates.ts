const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? "https://mahdihasan.co";
const BRAND_COLOR = "#002e9f";
const BRAND_COLOR_DARK = "#001a5e";

export function adminNotificationEmail({
  name,
  email,
  subject,
  message,
}: {
  name: string;
  email: string;
  subject: string;
  message: string;
}) {
  return `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>
<body style="margin:0;padding:0;background-color:#f1f5f9;font-family:'Segoe UI',Roboto,Helvetica,Arial,sans-serif;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:#f1f5f9;padding:40px 20px;">
    <tr>
      <td align="center">
        <table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;">

          <!-- Header -->
          <tr>
            <td style="background:linear-gradient(135deg,${BRAND_COLOR},${BRAND_COLOR_DARK});border-radius:16px 16px 0 0;padding:32px 40px;text-align:center;">
              <div style="font-size:28px;font-weight:800;color:#ffffff;letter-spacing:-0.5px;">MH</div>
              <div style="font-size:12px;color:rgba(255,255,255,0.7);margin-top:4px;text-transform:uppercase;letter-spacing:2px;">New Contact Submission</div>
            </td>
          </tr>

          <!-- Body -->
          <tr>
            <td style="background-color:#ffffff;padding:40px;">
              <p style="margin:0 0 8px;font-size:14px;color:#64748b;">You received a new message from your portfolio contact form</p>

              <!-- Sender Card -->
              <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin-top:24px;background-color:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;overflow:hidden;">
                <tr>
                  <td style="padding:24px;">
                    <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
                      <tr>
                        <td style="padding-bottom:16px;">
                          <table role="presentation" cellpadding="0" cellspacing="0">
                            <tr>
                              <td style="width:40px;height:40px;background:linear-gradient(135deg,${BRAND_COLOR},${BRAND_COLOR_DARK});border-radius:10px;text-align:center;vertical-align:middle;font-size:16px;font-weight:700;color:#ffffff;">${name.charAt(0).toUpperCase()}</td>
                              <td style="padding-left:12px;">
                                <div style="font-size:16px;font-weight:600;color:#0f172a;">${name}</div>
                                <div style="font-size:13px;color:#64748b;">${email}</div>
                              </td>
                            </tr>
                          </table>
                        </td>
                      </tr>
                      <tr>
                        <td style="border-top:1px solid #e2e8f0;padding-top:16px;">
                          <div style="font-size:11px;font-weight:600;color:#94a3b8;text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">Subject</div>
                          <div style="font-size:14px;color:#0f172a;font-weight:500;">${subject}</div>
                        </td>
                      </tr>
                      <tr>
                        <td style="padding-top:16px;">
                          <div style="font-size:11px;font-weight:600;color:#94a3b8;text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">Message</div>
                          <div style="font-size:14px;color:#334155;line-height:1.7;background-color:#ffffff;padding:16px;border:1px solid #e2e8f0;border-radius:8px;">${message.replace(/\n/g, "<br/>")}</div>
                        </td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>

              <!-- Reply Button -->
              <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin-top:24px;">
                <tr>
                  <td align="center">
                    <a href="mailto:${email}?subject=Re: ${encodeURIComponent(subject)}" style="display:inline-block;background:linear-gradient(135deg,${BRAND_COLOR},${BRAND_COLOR_DARK});color:#ffffff;font-size:14px;font-weight:600;text-decoration:none;padding:12px 32px;border-radius:10px;">Reply to ${name.split(" ")[0]}</a>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="background-color:#f8fafc;border-top:1px solid #e2e8f0;border-radius:0 0 16px 16px;padding:24px 40px;text-align:center;">
              <p style="margin:0;font-size:12px;color:#94a3b8;">
                Sent from <a href="${SITE_URL}" style="color:${BRAND_COLOR};text-decoration:none;font-weight:500;">${SITE_URL}</a> contact form
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;
}

export function userConfirmationEmail({
  name,
  subject,
  message,
}: {
  name: string;
  subject: string;
  message: string;
}) {
  return `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>
<body style="margin:0;padding:0;background-color:#f1f5f9;font-family:'Segoe UI',Roboto,Helvetica,Arial,sans-serif;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:#f1f5f9;padding:40px 20px;">
    <tr>
      <td align="center">
        <table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;">

          <!-- Header -->
          <tr>
            <td style="background:linear-gradient(135deg,${BRAND_COLOR},${BRAND_COLOR_DARK});border-radius:16px 16px 0 0;padding:40px;text-align:center;">
              <div style="font-size:28px;font-weight:800;color:#ffffff;letter-spacing:-0.5px;">MH</div>
              <div style="font-size:12px;color:rgba(255,255,255,0.7);margin-top:4px;text-transform:uppercase;letter-spacing:2px;">Media Buyer & Paid Advertising Consultant</div>
            </td>
          </tr>

          <!-- Body -->
          <tr>
            <td style="background-color:#ffffff;padding:40px;">

              <!-- Success Icon -->
              <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td align="center" style="padding-bottom:24px;">
                    <div style="width:64px;height:64px;background:linear-gradient(135deg,#10b981,#059669);border-radius:50%;text-align:center;line-height:64px;font-size:28px;color:#ffffff;">&#10003;</div>
                  </td>
                </tr>
              </table>

              <h1 style="margin:0 0 8px;font-size:24px;font-weight:700;color:#0f172a;text-align:center;">Thank you, ${name}!</h1>
              <p style="margin:0 0 32px;font-size:15px;color:#64748b;text-align:center;line-height:1.6;">
                I've received your message and will review it shortly.<br/>You can expect a response within <strong style="color:#0f172a;">24 hours</strong>.
              </p>

              <!-- Message Summary Card -->
              <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;overflow:hidden;">
                <tr>
                  <td style="padding:24px;">
                    <div style="font-size:11px;font-weight:600;color:#94a3b8;text-transform:uppercase;letter-spacing:1px;margin-bottom:12px;">Your Message Summary</div>
                    <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
                      <tr>
                        <td style="padding-bottom:12px;">
                          <span style="font-size:12px;color:#94a3b8;display:inline-block;width:70px;">Subject</span>
                          <span style="font-size:14px;color:#0f172a;font-weight:500;">${subject}</span>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <div style="font-size:12px;color:#94a3b8;margin-bottom:4px;">Message</div>
                          <div style="font-size:14px;color:#334155;line-height:1.7;background-color:#ffffff;padding:14px;border:1px solid #e2e8f0;border-radius:8px;">${message.replace(/\n/g, "<br/>")}</div>
                        </td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>

              <!-- Divider -->
              <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin-top:32px;">
                <tr>
                  <td style="border-top:1px solid #e2e8f0;padding-top:32px;text-align:center;">
                    <p style="margin:0 0 4px;font-size:14px;color:#0f172a;font-weight:600;">Mahdi Hasan</p>
                    <p style="margin:0 0 16px;font-size:13px;color:#64748b;">Media Buyer & Paid Advertising Consultant</p>
                    <table role="presentation" cellpadding="0" cellspacing="0" style="margin:0 auto;">
                      <tr>
                        <td style="padding:0 8px;">
                          <a href="${SITE_URL}" style="display:inline-block;background-color:${BRAND_COLOR};color:#ffffff;font-size:12px;font-weight:600;text-decoration:none;padding:8px 20px;border-radius:8px;">Visit Portfolio</a>
                        </td>
                        <td style="padding:0 8px;">
                          <a href="mailto:hello@mahdihasan.co" style="display:inline-block;background-color:#f1f5f9;color:#475569;font-size:12px;font-weight:600;text-decoration:none;padding:8px 20px;border-radius:8px;border:1px solid #e2e8f0;">Email Me Directly</a>
                        </td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="background-color:#f8fafc;border-top:1px solid #e2e8f0;border-radius:0 0 16px 16px;padding:24px 40px;text-align:center;">
              <p style="margin:0;font-size:12px;color:#94a3b8;">
                This is an automated confirmation. Please do not reply to this email.
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;
}
