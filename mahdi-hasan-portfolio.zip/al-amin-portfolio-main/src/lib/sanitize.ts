/**
 * Input sanitization and validation utilities.
 * Prevents XSS, injection, and oversized payloads.
 */

// ─── HTML Sanitization ─────────────────────────────────────────

const HTML_ESCAPE_MAP: Record<string, string> = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#x27;",
  "/": "&#x2F;",
};

/**
 * Escape HTML special characters to prevent XSS.
 */
export function escapeHtml(input: string): string {
  return input.replace(/[&<>"'/]/g, (char) => HTML_ESCAPE_MAP[char] || char);
}

/**
 * Strip all HTML tags from a string.
 */
export function stripHtml(input: string): string {
  return input.replace(/<[^>]*>/g, "");
}

// ─── String Sanitization ──────────────────────────────────────

/**
 * Sanitize a string: trim, limit length, strip dangerous characters.
 */
export function sanitizeString(
  input: string,
  options: { maxLength?: number; allowHtml?: boolean } = {}
): string {
  const { maxLength = 1000, allowHtml = false } = options;
  let sanitized = input.trim().slice(0, maxLength);

  if (!allowHtml) {
    sanitized = stripHtml(sanitized);
  }

  return sanitized;
}

/**
 * Sanitize a slug string — only allow aphanumeric, hyphens.
 */
export function sanitizeSlug(input: string): string {
  return input
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9-]/g, "")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 100);
}

// ─── Input Validation ─────────────────────────────────────────

/**
 * Validate email format.
 */
export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email) && email.length <= 254;
}

/**
 * Validate that a string is not empty after trimming.
 */
export function isNonEmpty(input: string): boolean {
  return input.trim().length > 0;
}

/**
 * Validate URL format.
 */
export function isValidUrl(url: string): boolean {
  try {
    const parsed = new URL(url);
    return ["http:", "https:"].includes(parsed.protocol);
  } catch {
    return false;
  }
}

// ─── Object Sanitization ─────────────────────────────────────

/**
 * Sanitize all string values in an object recursively.
 */
export function sanitizeObject<T extends Record<string, unknown>>(
  obj: T,
  options: { maxLength?: number; allowHtml?: boolean } = {}
): T {
  const sanitized = { ...obj };

  for (const [key, value] of Object.entries(sanitized)) {
    if (typeof value === "string") {
      (sanitized as Record<string, unknown>)[key] = sanitizeString(value, options);
    } else if (typeof value === "object" && value !== null && !Array.isArray(value)) {
      (sanitized as Record<string, unknown>)[key] = sanitizeObject(
        value as Record<string, unknown>,
        options
      );
    } else if (Array.isArray(value)) {
      (sanitized as Record<string, unknown>)[key] = value.map((item) =>
        typeof item === "string"
          ? sanitizeString(item, options)
          : typeof item === "object" && item !== null
            ? sanitizeObject(item as Record<string, unknown>, options)
            : item
      );
    }
  }

  return sanitized;
}

// ─── Request Body Size Check ──────────────────────────────────

const MAX_BODY_SIZE = 1 * 1024 * 1024; // 1MB

/**
 * Check if request body is within size limits.
 * Call before request.json() to prevent memory exhaustion.
 */
export async function checkBodySize(
  request: Request,
  maxSize = MAX_BODY_SIZE
): Promise<{ ok: boolean; error?: string }> {
  const contentLength = request.headers.get("content-length");
  if (contentLength && parseInt(contentLength, 10) > maxSize) {
    return { ok: false, error: "Request body too large" };
  }
  return { ok: true };
}
