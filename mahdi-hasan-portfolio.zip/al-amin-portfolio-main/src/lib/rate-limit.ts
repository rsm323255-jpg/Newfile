import { Ratelimit } from "@upstash/ratelimit";
import { Redis } from "@upstash/redis";

// ─── Redis (production) / In-Memory (local dev) ────────────────

function createRedis() {
  const url = process.env.UPSTASH_REDIS_REST_URL;
  const token = process.env.UPSTASH_REDIS_REST_TOKEN;
  if (!url || !token) return null;
  return new Redis({ url, token });
}

let _redis: Redis | null = null;
function getRedis(): Redis | null {
  if (_redis === null) _redis = createRedis();
  return _redis;
}

const limiterCache = new Map<string, Ratelimit>();

function getLimiter(key: string, limit: number, windowSec: number): Ratelimit | null {
  const redis = getRedis();
  if (!redis) return null;
  const cacheKey = `${limit}:${windowSec}`;
  let limiter = limiterCache.get(cacheKey);
  if (!limiter) {
    limiter = new Ratelimit({
      redis,
      limiter: Ratelimit.slidingWindow(limit, `${windowSec} s`),
      analytics: false,
    });
    limiterCache.set(cacheKey, limiter);
  }
  return limiter;
}

// ─── In-Memory Fallback (local dev only) ──────────────────────

interface MemoryEntry { count: number; resetAt: number }

const memoryStore = new Map<string, MemoryEntry>();
const memoryBlockStore = new Map<string, number>(); // key → unblock timestamp

function memoryCheck(key: string, limit: number, windowMs: number): { allowed: boolean; remaining: number; resetAt: number } {
  const now = Date.now();
  const resetAt = now + windowMs;
  const entry = memoryStore.get(key);

  if (!entry || now > entry.resetAt) {
    memoryStore.set(key, { count: 1, resetAt });
    return { allowed: true, remaining: limit - 1, resetAt };
  }

  entry.count++;
  return {
    allowed: entry.count <= limit,
    remaining: Math.max(0, limit - entry.count),
    resetAt: entry.resetAt,
  };
}

function memoryIncrement(key: string, windowMs: number): number {
  const now = Date.now();
  const resetAt = now + windowMs;
  const entry = memoryStore.get(key);

  if (!entry || now > entry.resetAt) {
    memoryStore.set(key, { count: 1, resetAt });
    return 1;
  }

  entry.count++;
  return entry.count;
}

function memoryGet(key: string): number | null {
  const entry = memoryStore.get(key);
  if (!entry) return null;
  if (Date.now() > entry.resetAt) {
    memoryStore.delete(key);
    return null;
  }
  return entry.count;
}

function memoryBlock(key: string, durationMs: number) {
  memoryBlockStore.set(key, Date.now() + durationMs);
}

function memoryIsBlocked(key: string): { blocked: boolean; ttl: number } {
  const unblockAt = memoryBlockStore.get(key);
  if (!unblockAt) return { blocked: false, ttl: 0 };
  if (Date.now() > unblockAt) {
    memoryBlockStore.delete(key);
    return { blocked: false, ttl: 0 };
  }
  return { blocked: true, ttl: Math.ceil((unblockAt - Date.now()) / 1000) };
}

function memoryDelete(key: string) {
  memoryStore.delete(key);
  memoryBlockStore.delete(key);
}

// ─── General Rate Limiter ─────────────────────────────────────

export async function checkRateLimit(
  key: string,
  limit: number,
  windowMs: number
): Promise<{ allowed: boolean; remaining: number; resetAt: number }> {
  // Try Redis first
  const redis = getRedis();
  if (redis) {
    const windowSec = Math.ceil(windowMs / 1000);
    const limiter = getLimiter(key, limit, windowSec);
    if (limiter) {
      const result = await limiter.limit(key);
      return {
        allowed: result.success,
        remaining: result.remaining,
        resetAt: result.reset,
      };
    }
  }

  // In-memory fallback
  return memoryCheck(key, limit, windowMs);
}

export async function rateLimit(
  request: Request,
  endpoint: string,
  limit = 100,
  windowMs = 60_000
) {
  const ip = getClientIp(request);
  return checkRateLimit(`${endpoint}:${ip}`, limit, windowMs);
}

// ─── Login Brute Force Protection ──────────────────────────────

const LOGIN_MAX_ATTEMPTS = 5;
const LOGIN_BLOCK_DURATION_MS = 15 * 60 * 1000; // 15 minutes
const LOGIN_WINDOW_MS = 15 * 60 * 1000;

export async function checkLoginAllowed(
  ip: string
): Promise<{ allowed: boolean; retryAfter?: number }> {
  const redis = getRedis();
  if (redis) {
    const blockKey = `login_block:${ip}`;
    const blocked = await redis.get(blockKey);
    if (blocked) {
      const ttl = await redis.ttl(blockKey);
      return { allowed: false, retryAfter: ttl > 0 ? ttl : 900 };
    }
    return { allowed: true };
  }

  // In-memory fallback
  const result = memoryIsBlocked(`login_block:${ip}`);
  if (result.blocked) {
    return { allowed: false, retryAfter: result.ttl };
  }
  return { allowed: true };
}

export async function recordLoginAttempt(ip: string, success: boolean) {
  const redis = getRedis();
  if (redis) {
    if (success) {
      await redis.del(`login_block:${ip}`);
      await redis.del(`login_attempts:${ip}`);
      return;
    }
    const key = `login_attempts:${ip}`;
    const attempts = await redis.incr(key);
    if (attempts === 1) {
      await redis.expire(key, Math.ceil(LOGIN_WINDOW_MS / 1000));
    }
    if (attempts >= LOGIN_MAX_ATTEMPTS) {
      await redis.set(`login_block:${ip}`, 1, { ex: Math.ceil(LOGIN_BLOCK_DURATION_MS / 1000) });
    }
    return;
  }

  // In-memory fallback
  if (success) {
    memoryDelete(`login_block:${ip}`);
    memoryDelete(`login_attempts:${ip}`);
    return;
  }
  const attempts = memoryIncrement(`login_attempts:${ip}`, LOGIN_WINDOW_MS);
  if (attempts >= LOGIN_MAX_ATTEMPTS) {
    memoryBlock(`login_block:${ip}`, LOGIN_BLOCK_DURATION_MS);
  }
}

// ─── DDoS / Burst Protection ──────────────────────────────────

const DDoS_THRESHOLD = 200;
const DDoS_HARD_BLOCK = 400;
const DDoS_WINDOW_MS = 60_000;

export async function checkDdos(
  request: Request
): Promise<{ safe: boolean; blocked: boolean }> {
  const ip = getClientIp(request);

  const redis = getRedis();
  if (redis) {
    const key = `ddos:${ip}`;
    const count = await redis.incr(key);
    if (count === 1) {
      await redis.expire(key, 60);
    }
    if (count > DDoS_HARD_BLOCK) return { safe: false, blocked: true };
    if (count > DDoS_THRESHOLD) return { safe: false, blocked: false };
    return { safe: true, blocked: false };
  }

  // In-memory fallback
  const count = memoryIncrement(`ddos:${ip}`, DDoS_WINDOW_MS);
  if (count > DDoS_HARD_BLOCK) return { safe: false, blocked: true };
  if (count > DDoS_THRESHOLD) return { safe: false, blocked: false };
  return { safe: true, blocked: false };
}

export async function isBlocked(ip: string): Promise<boolean> {
  const redis = getRedis();
  if (redis) {
    const key = `ddos:${ip}`;
    const count = await redis.get<number>(key);
    return !!count && count > DDoS_HARD_BLOCK;
  }

  // In-memory fallback
  const count = memoryGet(`ddos:${ip}`);
  return !!count && count > DDoS_HARD_BLOCK;
}

// ─── Utility ──────────────────────────────────────────────────

function getClientIp(request: Request): string {
  const forwarded = request.headers.get("x-forwarded-for");
  if (forwarded) {
    const first = forwarded.split(",")[0]?.trim();
    if (first) return first;
  }
  const real = request.headers.get("x-real-ip");
  if (real) return real;
  return "127.0.0.1";
}

export function rateLimitHeaders(
  remaining: number,
  resetAt: number,
  limit: number
): Record<string, string> {
  return {
    "X-RateLimit-Limit": String(limit),
    "X-RateLimit-Remaining": String(Math.max(0, remaining)),
    "X-RateLimit-Reset": String(Math.floor(resetAt / 1000)),
  };
}
