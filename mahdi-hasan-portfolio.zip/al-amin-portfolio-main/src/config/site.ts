import { images } from "@/constants/images";

export const siteConfig = {
  name: "Mahdi Hasan",
  shortName: "Mahdi",
  title: "Mahdi Hasan | Media Buyer & Paid Advertising Consultant",
  description:
    "Independent media buyer and paid advertising consultant helping businesses turn ad spend into a structured, repeatable growth system.",
  url: process.env.NEXT_PUBLIC_SITE_URL ?? "https://mahdihasan.co",
  ogImage: images.ogImage,
  locale: "en_US",
  keywords: [
    "Mahdi Hasan",
    "Media Buyer",
    "Paid Advertising Consultant",
    "Media Buying",
    "Paid Advertising",
    "Campaign Strategy",
    "Performance Marketing",
    "Growth Strategy",
  ],
  author: {
    name: "Mahdi Hasan",
    email: "hello@mahdihasan.co",
    role: "Media Buyer & Paid Advertising Consultant",
  },
  // Only verified profiles. Add more here (and in src/data/social.ts) when confirmed.
  social: {
    linkedin: "https://www.linkedin.com/in/mahdi-hasan100",
  },
  contact: {
    email: "hello@mahdihasan.co",
  },
};

/** Single-page sections. `id` matches the section anchor on the home page. */
export const navLinks = [
  { href: "/#home", label: "Home", id: "home" },
  { href: "/#about", label: "About", id: "about" },
  { href: "/#services", label: "Services", id: "services" },
  { href: "/#work", label: "Work", id: "work" },
  { href: "/#process", label: "Process", id: "process" },
  { href: "/#faq", label: "FAQ", id: "faq" },
  { href: "/#contact", label: "Contact", id: "contact" },
];

export const footerLinks = {
  explore: [
    { label: "Home", href: "/#home" },
    { label: "About", href: "/#about" },
    { label: "Services", href: "/#services" },
    { label: "Work", href: "/#work" },
  ],
  resources: [
    { label: "Process", href: "/#process" },
    { label: "FAQ", href: "/#faq" },
    { label: "Contact", href: "/#contact" },
  ],
  legal: [
    { label: "Privacy Policy", href: "/privacy-policy" },
    { label: "Terms & Conditions", href: "/terms" },
  ],
};
