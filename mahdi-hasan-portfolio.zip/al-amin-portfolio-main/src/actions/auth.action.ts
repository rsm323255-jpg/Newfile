"use server";

import {
  getCurrentUser as _getCurrentUser,
  removeTokenCookies,
  type TokenPayload,
} from "@/lib/auth";

export interface AuthState {
  error?: string;
  success?: boolean;
  user?: {
    name: string;
    email: string;
    role: string;
  };
}

export async function getAdminSession(): Promise<Omit<TokenPayload, "type"> | null> {
  return _getCurrentUser();
}

export async function getCurrentUser(): Promise<Omit<TokenPayload, "type"> | null> {
  return _getCurrentUser();
}

export async function logoutAction() {
  await removeTokenCookies();
}
