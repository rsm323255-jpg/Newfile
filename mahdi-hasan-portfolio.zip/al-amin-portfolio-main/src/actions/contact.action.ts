"use server";

import { contactSchema, newsletterSchema } from "@/schemas/contact";
import { connectToDatabase } from "@/lib/mongodb";
import { MessageModel } from "@/models";
import { sendEmail } from "@/lib/smtp";
import { adminNotificationEmail, userConfirmationEmail } from "@/lib/email-templates";

export type ContactActionResult = {
  success: boolean;
  message?: string;
};

const ADMIN_EMAIL = process.env.SMTP_USER ?? "hello@mahdihasan.co";

export async function submitContact(
  _prevState: ContactActionResult | null,
  formData: FormData
): Promise<ContactActionResult> {
  const parsed = contactSchema.safeParse({
    name: formData.get("name"),
    email: formData.get("email"),
    subject: formData.get("subject"),
    message: formData.get("message"),
  });

  if (!parsed.success) {
    return {
      success: false,
      message: parsed.error.issues[0]?.message ?? "Please check your input.",
    };
  }

  const { name, email, subject, message } = parsed.data;

  try {
    // 1. Save to database
    await connectToDatabase();
    await MessageModel.create({ name, email, subject, message });

    // 2. Send notification email to admin
    await sendEmail({
      to: ADMIN_EMAIL,
      subject: `New Contact: ${subject}`,
      replyTo: email,
      html: adminNotificationEmail({ name, email, subject, message }),
    });

    // 3. Send confirmation email to user
    await sendEmail({
      to: email,
      subject: "We received your message - Mahdi Hasan",
      html: userConfirmationEmail({ name, subject, message }),
    });

    return { success: true };
  } catch {
    return {
      success: false,
      message: "Something went wrong sending your message. Please try again.",
    };
  }
}

export async function subscribeNewsletter(
  formData: FormData
): Promise<ContactActionResult> {
  const parsed = newsletterSchema.safeParse({ email: formData.get("email") });

  if (!parsed.success) {
    return {
      success: false,
      message: "Please enter a valid email address.",
    };
  }

  try {
    await new Promise((resolve) => setTimeout(resolve, 500));
    return { success: true };
  } catch {
    return {
      success: false,
      message: "Unable to subscribe right now. Please try again.",
    };
  }
}
