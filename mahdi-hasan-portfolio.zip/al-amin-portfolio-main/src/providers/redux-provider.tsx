"use client";

import { useState } from "react";
import { Provider } from "react-redux";
import { makeStore } from "@/store";

export function ReduxProvider({ children }: { children: React.ReactNode }) {
  // Lazy initializer creates the store exactly once per client (no ref access during render).
  const [store] = useState(() => makeStore());
  return <Provider store={store}>{children}</Provider>;
}
